﻿export const json = {
EnterKeyValues: {
},
Label:{
},
LabelHeader: {
},
Property: {
}
}

