﻿export const English = {
    "PMSBuildingRegistry" : 'Building Registry',
}

export const Arabic = {
    "PMSBuildingRegistry" : 'Building Registry',
}
const obj = {
       English : English,
       Arabic: Arabic,
       //Chinese: Chinese,
       // Turkish: Turkish
}

export default function formmultilingual(){
   let lag = localStorage.getItem('Language');
   return obj[lag]
}
export const English = {
    "PMSBuildingRegistry" : 'Building Registry',
}

export const Arabic = {
    "PMSBuildingRegistry" : 'Building Registry',
}
const obj = {
       English : English,
       Arabic: Arabic,
       //Chinese: Chinese,
       // Turkish: Turkish
}

export default function formmultilingual(){
   let lag = localStorage.getItem('Language');
   return obj[lag]
}
export const English = {
    "PMSBuildingRegistry" : 'Building Registry',
}

export const Arabic = {
    "PMSBuildingRegistry" : 'Building Registry',
}
const obj = {
       English : English,
       Arabic: Arabic,
       //Chinese: Chinese,
       // Turkish: Turkish
}

export default function formmultilingual(){
   let lag = localStorage.getItem('Language');
   return obj[lag]
}
