﻿

// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023
// Import Declaration for View 
import React,{useEffect, useState,forwardRef, useImperativeHandle,useContext,useRef} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { useDispatch, useSelector } from "react-redux";
import Tooltip from '@material-ui/core/Tooltip'
import FileCopyIcon from '@material-ui/icons/FileCopyOutlined';
import MUICheckbox from '@material-ui/core/Checkbox';
import AddBtn from '../../../components/Buttons/AddButton';
import EditBtn from '../../../components/Buttons/EditButton';
import GridContainer from "../../../components/Grid/GridContainer";
import GridItem from "../../../components/Grid/GridItem";
import Checkbox from '../../../components/_helperComponents/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import CheckboxNew from '@material-ui/core/Checkbox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import ExpandLessIcon from '@material-ui/icons/ExpandLess';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import KeyboardBackspaceIcon from '@material-ui/icons/KeyboardBackspace';
import Document from './MainComponent';
import ViewPreview from '../../../components/_helperComponents/viewPagePrev'
import CommonAPISelect from '../../../CommonAPISelect';
import {config} from '../../../config.js';
import GridList from '@material-ui/core/GridList';
import GridListTile from '@material-ui/core/GridListTile'
import { PMSBuildingRegistryContext,ContextApi } from './MainComponent'
import AdminImageRegistryAPI from '../../../AdminImageRegistryAPI';
import Token from "../../../Token";
import SaveBtn from '../../../components/Buttons/SaveButton';
import ApprDialog from '../../../components/_helperComponents/ApprDialog';
import NoImage from '../../../assets/img/noImage.jpg'
import EditIcon from '@material-ui/icons/Edit';
import CreateNewFolderIcon from '@material-ui/icons/Add';
import { json } from './ej';
import multilingual from '../../../components/_helperComponents/tjson/multilingual';
import { MdOutlineArrowBackIosNew } from 'react-icons/md';
import SendIcon from '@material-ui/icons/Send';
import DescriptionOutlinedIcon from '@material-ui/icons/DescriptionOutlined';
import PublishIcon from '@material-ui/icons/Publish';
import { Icon  } from '@material-ui/core';
import MoreVertIcon from '@material-ui/icons/MoreVert';
import Menu from '@material-ui/core/Menu';
import CloseBtn from '../../../components/Buttons/CloseButton';


// Import_Process_ModulesComponents
import PMSBuildingRegistryTable from '../PMSBuildingRegistry/TableComponent';
import PMSBuildFacilityDetailsMain from'../../L1Bee/PMSBuildFacilityDetails/MainComponent';

import PMSBuildResponsePersonDetailsMain from'../../L1Bee/PMSBuildResponsePersonDetails/MainComponent';

import PMSBuildContPerDetailsMain from'../../L1Bee/PMSBuildContPerDetails/MainComponent';

import PMSBuildDefaultChargesDetailsMain from'../../L1Bee/PMSBuildDefaultChargesDetails/MainComponent';

import PMSBuildNotesDetailsMain from'../../L1Bee/PMSBuildNotesDetails/MainComponent';


// vOpenSlideImportsForView

// glbImportContextApiForms

// glbAddOnImportComponentStr

import ViewCardGrid from '../../../components/_helperComponents/ViewCardGridL4';
import { BiExpandAlt } from 'react-icons/bi';


// ViewMainFunction 
const PMSBuildingRegistryView = forwardRef((props, ref) => {
const content = useSelector(state => state.form);
const dispatch = useDispatch(); 
const Level1CompRef=useRef();

const [PMSBuildingRegistryData,setPMSBuildingRegistryData]=useState([]);
const [ExpandView,setExpandView]=useState(false);
const [expanded, setExpanded] = useState(true);
const [showDetail,setShowDetail]=useState(props.showDetail);
const [AttachmentData,setAttachmentData] = useState(false)
const context = useContext(PMSBuildingRegistryContext);
const {cstate , cdispatch} = ContextApi();
const [viewmore,setviewmore]=useState(false);
const [InboxApproval, setInboxApproval] = useState(false);
const [openAppr, setopenAppr ] =useState(false);
const [PMSBuildingID, setPMSBuildingID] = useState('')
const [selectReport, setSelectReport] = useState("");
const [menuPosition, setMenuPosition] = useState(null);
const [cardName, setcardName] = useState('');
const [SubCardData, setSubCardData] = useState([]);
const [AccessRights, setAccessRights] = useState({ IsAdd: true,IsEdit: true,IsView: true,IsDelete: false,IsPrint: true,IsExport: true })

let lang = multilingual();
const t = (e) =>  lang?.[e] ? lang[e] : e ;
const tf = (e) =>  cstate.language?.[e] ? cstate.language[e] : e ;

   useEffect(() =>{
       if(props.l4viewonly){
            setPMSBuildingRegistryData(props.data); 
       }else if(props.viewonly){
             Viewdata(cstate.PrimaryId,null,'PMSBuildingID');
       }else{
            setPMSBuildingRegistryData(cstate.PrimaryData); 
            dispatch({ type :'PMSBuildingRegistry1394',PMSBuildingRegistryPMSBuildingID: cstate.PrimaryData.PMSBuildingIDPK});
       }
},[props.data]);
useEffect(() => {
   if (cstate.PrimaryData.length >0){ 
       Viewdata(cstate.PrimaryId,null,'PMSBuildingID');
       return false;
   }
if(cstate.PrimaryId){
   Viewdata(cstate.PrimaryId,null,'PMSBuildingID');
       return false;
}
},[cstate.PrimaryData,cstate.PrimaryId]);

function OpenDetailComponent(){
    props.DetailComponent(true);
}
useEffect(() => {
       setExpanded(props.ExpandDetailValue);
},[props.ExpandDetailValue]);
useEffect(() => {
   if(props.inboxdata){
     if(Object.keys(props.inboxdata).length > 0){
        setExpanded(true);
        Viewdata(props.inboxdata.id,props.inboxdata.token,'PMSBuildingID');
        setInboxApproval(true);
     }
   }
},[props.inboxdata]);

useImperativeHandle(ref, () => ({
  getAlert: (val) => {
   setExpanded(true);
   setExpandView(false);
 },
 inboxprops : (val) => {
      if([val].length > 0){
              setExpanded(true);
              Viewdata(val.id,val.token,'PMSBuildingID');
              cdispatch({ type: 'PrimaryId',payload: val.id});
              setInboxApproval(true);
           }
  }
   }));

function OpenSlideComponent(type,id){

}


async function Viewdata(id,token,ParamType){
  if (PMSBuildingID){setPMSBuildingID(id)}
  context.loading(true);
  let url = config.Api + "FPN1394S3/";
  let params = {
  "data": {
              "p1": id ? id :cstate.PrimaryId
               ,"p2": null
               ,"p3": null
               ,"p4": null
               ,"p5": null
               ,"p6": null
               ,"p7": null
               ,"p8": null
               ,"p9": null
               ,"p10": null
               ,"p11": null
               ,"p12": null
               ,"p13": null
               ,"p14": null
               ,"p15": null
               ,"p16": null
               ,"p17": null
               ,"p18": null
               ,"p19": null
               ,"p20": null
               ,"p21": null
               ,"p22": null
               ,"p23": null
               ,"p24": null
               ,"p25": null
               ,"p26": null
               ,"p27": null
               ,"p28": null
               ,"p29": null
               ,"p30": null
               ,"p31": null
               ,"p32": null
               ,"p33": null
               ,"p34": null
               ,"p35": null
               ,"p36": null
               ,"p37": null
               ,"p38": null
               ,"p39": null
               ,"p40": null
               ,"p41": null
               ,"p42": null
               ,"p43": null
               ,"p44": props.Dialogview ? "1" : null
               ,"p45": null
               ,"p46": null
               ,"p47": null
               ,"p48": null
               ,"p49": null
               ,"p50": null
               ,"p51": null
               ,"p52": null
               ,"p53": null
               ,"p54": null
               ,"p55": null
               ,"p56": null
               ,"p57": null
               ,"p58": null
               ,"p59": null
               ,"p60": null
               ,"p61": null
               ,"p62": null
               ,"p63": null
               ,"p64": null
               ,"p65": null
               ,"p66": null
               ,"p67": null
               ,"p68": null
               ,"p69": null
               ,"p70": null
               ,"p71": null
               ,"p72": null
               ,"p73": null
               ,"p74": null
               ,"p75": null
               ,"p76": null
               ,"p77": null
               ,"p78": null
               ,"p79": null
               ,"p80": null
               ,"p81": null
               ,"p82": null
               ,"p83": null
               ,"p84": null
               ,"p85": null
               ,"p86": null
               ,"p87": null
               ,"p88": null
               ,"p89": null
               ,"p90": null
               ,"p91": null
               ,"p92": null
               ,"p93": null
               ,"p94": null
               ,"p95": null
               ,"p96": null
               ,"p97": null
               ,"p98": null
               ,"p99": null
               ,"p100": null
               ,"p101": null
               ,"p102": null
               ,"p103": null
               ,"p104": null
               ,"p105": null
               ,"p106": null
               ,"p107": null
               ,"p108": null
               ,"p109": null
             ,"p110": 1
             ,"p111": 10
             ,"p112": ParamType
               ,"p113": null
               ,"p114": null
               ,"p115": localStorage.getItem('UserGroupID')
               ,"p116": localStorage.getItem('userid')
    }
   }
   var newToken ={};
    if(cstate.token.length == 0){
       await Token(0).then(token => {
        newToken = token;
   });
   }
   await CommonAPISelect(url,params, cstate.token.length == 0 ? newToken : cstate.token[0])
   .then(res => {
   if(res.Output.status.code == "200"){
if(res.Output.data.length > 0 ) {
         let parentData = res.Output.data[0][1394][0];
         setPMSBuildingRegistryData(parentData);
         setSentAppr(res.Output.data[0][1394][0].ViewCancelCheck);
         let cData =  res.Output.data[0];
         delete cData['1394'];
         let cCardAr = Object.values(cData).flat();
         const SubCardData = cCardAr.sort((a, b) =>  a.orderno - b.orderno )
         setSubCardData(SubCardData);
         context.loading(false);
       }else{
           context.loading(false);
           context.alert({ open:true,color:'warning',message:['No record found']});
        }
     } 
   });
  }

const ApprConfirmation = () =>{
        setopenAppr(true)
} 

function SubformsLink(item){
     setcardName(item.name);
     setAccessRights(prev => ({...prev,IsAdd: item.isNestAdd, IsEdit: item.isNestEdit }))
}

   const CommonLogsSelect = (id,type,title) => {
        context.loading(true)
        let url = config.Api + "CommonSelect_API/";
        let params =  {
                    "data": {
                    "p1_int": id ? id : cstate.PrimaryId,
                    "p2_int": 0,
                    "p3_varchar": null,
                    "p4_int": 1,
                    "p5_int": 10,
                    "p6_varchar": type,
                    "p7_int": null,
                    "p8_int": null
                }
            }
            CommonAPISelect(url, params, cstate.token[0])
            .then((res) => {
                if (res.Output.status.code == "200") {
                        if(res.Output.data.length > 0){
                                context.loading(false);
                                setCommonLogTitle(title);
                                setCommonLogsData(res.Output.data);
                        }else{
                               context.loading(false)
                             context.alert({ open:true,color:'warning',message:['No record found']});
                        } 
                }else{
                        context.loading(false);
                }
        })
}


const handleRightClick = (event) => {
  if (menuPosition) {
    return;
  }
  event.preventDefault();

  setMenuPosition({
    top: event.pageY,
    left: event.pageX - 10
  });
};

const handleItemClick = (event) => {
  setMenuPosition(null);
};

  return (
    <div>
       <GridContainer>
        <GridItem xs={cardName ? 3: 12} md={cardName ? 3: 12} lg={cardName ? 3: 12}>
           <div className='gridcardl41A' id='PMSBuildingRegistryDiv'>
                        <GridContainer>
                        <GridItem sm={12} md={12} lg={12} xs={12}>
                               <GridContainer style={{marginBottom:'1%'}}>
                               <GridItem sm={12} md={12} lg={12} xs={12}> 
                               <div className='ViewHeadingTitle2'>
                               <span style={{ cursor: 'pointer' }}>
                                   <div id='fld1394L4VCMdOutlineArrowBackIosNew'>
                                           <MdOutlineArrowBackIosNew className="BackBtnIcon" onClick={() => { context.ShowTableDiv(false); context.add() }} />
                                             Primary Details
                                   </div>
                               </span>
                               <div className='iconstyle displayFlex'>
                        {InboxApproval &&  
                        <SaveBtn  
                        className = 'ApprBtnCommon'
                        name = {'Approve'}
                        disabled = {false}
                        onClick={() => {ApprConfirmation('1')}}
                        />}
                        {InboxApproval &&
                        <SaveBtn  
                        className = 'RejBtnCommon'
                        name = {'Reject'}
                        disabled = {false}
                        onClick={() => {ApprConfirmation('2')}}
                        />}
  {cstate.AccessRights.IsEdit &&  
 <div id='fld1394L4VCEditIcon' onClick={() => {context.editview(PMSBuildingRegistryData) }}>
         <Tooltip title ='Edit'> 
                 <span><EditIcon style={{width:'20px',marginRight:'10px'}}/></span>
         </Tooltip>
 </div>}
 {cstate.AccessRights.IsAdd &&  
 <div id='fld1394L4VCCreateNewFolderIcon' onClick={()=> {context.add()}}>
         <Tooltip title ='Add'>
                 <span > <CreateNewFolderIcon/> </span>
         </Tooltip>
 </div>}

 {cardName &&
 <div id='fld1394L4VCFullscreen' onClick={()=>cardName && setcardName('')}>
         <Tooltip title ='Expand'> 
         <span><BiExpandAlt style={{width:'18px',height:'18px',marginTop:'3px'}}/></span>
         </Tooltip>
 </div>} 

                                   </div>
                                   </div>
                                   </GridItem>
                                   </GridContainer>
                   <ViewCardGrid
                           tableName={"PMSBuildingRegistry"}
                           tableID={1394}
                           parentID={cstate.PrimaryId}
                           fldid={"fld1394L4VCContainer"}
                           OpenSlideComponent={OpenSlideComponent}
                           index={0}
                           val={PMSBuildingRegistryData}
                           tf={tf}
                           t={t}
                           cardName={cardName}
                           SubCardData={SubCardData}
                           SubformsLink={SubformsLink}
                           alertmsg={(e) => context.alert(e)}
                           title ={'8.0.0.46-12:46:59-21-3'}
                   />
                                   </GridItem>
                                   </GridContainer>
                   </div> 
                            </GridItem>
                   {  cardName &&
                       <GridItem sm={9} md={9} xs={9} className ='lstscroll' style={{height:'auto'}}>

         {cardName == 'PMSBuildFacilityDetails' &&
         <PMSBuildFacilityDetailsMain AccessRights={AccessRights} 
                                                 loading={(e) => context.loading(e)} 
                                                 parentDatas={PMSBuildingRegistryData}
                                                 alertmsg={(e) => context.alert(e)} 
                                                 ConfirmAlert= {(val)=>{context.ConfirmAlert(val)}} 
                                                 ref={Level1CompRef} 
                                                 PrimaryView={false} 
                                                 parentId={cstate.PrimaryId} 
                                                 SlideComponentType = {(e,val) => context.SlideComponentType(e,val)} 
                                                 openNav = {(e) => context.openNav(e)} 
                                                 openDialog= {(e) => context.openDialog(e)} 
                                                 DialogComponentType={ (e) => context.DialogComponentType(e)}
                                                 cardRefresh={() => Viewdata(cstate.PrimaryId,null,'PMSBuildingID')}
                                                 />
      }

         {cardName == 'PMSBuildResponsePersonDetails' &&
         <PMSBuildResponsePersonDetailsMain AccessRights={AccessRights} 
                                                 loading={(e) => context.loading(e)} 
                                                 parentDatas={PMSBuildingRegistryData}
                                                 alertmsg={(e) => context.alert(e)} 
                                                 ConfirmAlert= {(val)=>{context.ConfirmAlert(val)}} 
                                                 ref={Level1CompRef} 
                                                 PrimaryView={false} 
                                                 parentId={cstate.PrimaryId} 
                                                 SlideComponentType = {(e,val) => context.SlideComponentType(e,val)} 
                                                 openNav = {(e) => context.openNav(e)} 
                                                 openDialog= {(e) => context.openDialog(e)} 
                                                 DialogComponentType={ (e) => context.DialogComponentType(e)}
                                                 cardRefresh={() => Viewdata(cstate.PrimaryId,null,'PMSBuildingID')}
                                                 />
      }

         {cardName == 'PMSBuildContPerDetails' &&
         <PMSBuildContPerDetailsMain AccessRights={AccessRights} 
                                                 loading={(e) => context.loading(e)} 
                                                 parentDatas={PMSBuildingRegistryData}
                                                 alertmsg={(e) => context.alert(e)} 
                                                 ConfirmAlert= {(val)=>{context.ConfirmAlert(val)}} 
                                                 ref={Level1CompRef} 
                                                 PrimaryView={false} 
                                                 parentId={cstate.PrimaryId} 
                                                 SlideComponentType = {(e,val) => context.SlideComponentType(e,val)} 
                                                 openNav = {(e) => context.openNav(e)} 
                                                 openDialog= {(e) => context.openDialog(e)} 
                                                 DialogComponentType={ (e) => context.DialogComponentType(e)}
                                                 cardRefresh={() => Viewdata(cstate.PrimaryId,null,'PMSBuildingID')}
                                                 />
      }

         {cardName == 'PMSBuildDefaultChargesDetails' &&
         <PMSBuildDefaultChargesDetailsMain AccessRights={AccessRights} 
                                                 loading={(e) => context.loading(e)} 
                                                 parentDatas={PMSBuildingRegistryData}
                                                 alertmsg={(e) => context.alert(e)} 
                                                 ConfirmAlert= {(val)=>{context.ConfirmAlert(val)}} 
                                                 ref={Level1CompRef} 
                                                 PrimaryView={false} 
                                                 parentId={cstate.PrimaryId} 
                                                 SlideComponentType = {(e,val) => context.SlideComponentType(e,val)} 
                                                 openNav = {(e) => context.openNav(e)} 
                                                 openDialog= {(e) => context.openDialog(e)} 
                                                 DialogComponentType={ (e) => context.DialogComponentType(e)}
                                                 cardRefresh={() => Viewdata(cstate.PrimaryId,null,'PMSBuildingID')}
                                                 />
      }

         {cardName == 'PMSBuildNotesDetails' &&
         <PMSBuildNotesDetailsMain AccessRights={AccessRights} 
                                                 loading={(e) => context.loading(e)} 
                                                 parentDatas={PMSBuildingRegistryData}
                                                 alertmsg={(e) => context.alert(e)} 
                                                 ConfirmAlert= {(val)=>{context.ConfirmAlert(val)}} 
                                                 ref={Level1CompRef} 
                                                 PrimaryView={false} 
                                                 parentId={cstate.PrimaryId} 
                                                 SlideComponentType = {(e,val) => context.SlideComponentType(e,val)} 
                                                 openNav = {(e) => context.openNav(e)} 
                                                 openDialog= {(e) => context.openDialog(e)} 
                                                 DialogComponentType={ (e) => context.DialogComponentType(e)}
                                                 cardRefresh={() => Viewdata(cstate.PrimaryId,null,'PMSBuildingID')}
                                                 />
      }


                   </GridItem>}
       </GridContainer>
     </div>
    )
});
export default PMSBuildingRegistryView;


// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023
