﻿



// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023
// Main Export Entry(L3-Sweet)
import React,{forwardRef, useEffect, useImperativeHandle, useRef, useState, useReducer, useCallback,useContext} from "react";
import { useDispatch, useSelector } from "react-redux";
import Accordion from '@material-ui/core/Accordion';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import Attachment from '../../../components/_helperComponents/Attachment'
import AttachmentIcon from '@material-ui/icons/Attachment';
import Checkbox from '../../../components/_helperComponents/Checkbox'
import FormControlLabel from '@material-ui/core/FormControlLabel';
import CheckboxNew from '@material-ui/core/Checkbox';
import CheckBoxOutlineBlankIcon from '@material-ui/icons/CheckBoxOutlineBlank';
import CheckBoxIcon from '@material-ui/icons/CheckBox';
import ClearBtn from '../../../components/Buttons/ClearButton';
import CommonAPISave from '../../../CommonAPISave';
import CommonAPISelect from '../../../CommonAPISelect';
import L2TextField from '../../../components/_helperComponents/L2TextField'
import DraftBtn from '../../../components/Buttons/DraftButton';
import GridContainer from "../../../components/Grid/GridContainer";
import GridItem from "../../../components/Grid/GridItem";
import IconButton from '@material-ui/core/IconButton';
import Mat_DatePicker from '../../../components/_helperComponents/Mat_DatePicker';
import Mat_TimePicker from '../../../components/_helperComponents/Mat_TimePicker';
import Mat_DateTimePicker from '../../../components/_helperComponents/Mat_DateTimePicker';
import SaveBtn from '../../../components/Buttons/SaveButton';
import SetDefaultBtn from '../../../components/Buttons/SetDefaultButton';
import SweetAlert from "react-bootstrap-sweetalert";
import Token from "../../../Token";
import Tooltip from "@material-ui/core/Tooltip";
import {config} from '../../../config.js';
import { makeStyles } from '@material-ui/core/styles';
import moment from "moment";
import withStyles from "@material-ui/core/styles/withStyles";
import L2DropDown from '../../../components/_helperComponents/L2DropDown';
import TopAccordian from '../../../components/_helperComponents/TopAccordian';
import Card from '../../../components/Card/Card';
import CardBody from '../../../components/Card/CardBody';
import CardHeader from '../../../components/Card/CardHeader';
import CloseBtn from '../../../components/Buttons/CloseButton';
import KeyboardBackspaceIcon from '@material-ui/icons/ArrowBack'
import AccessRightsAPI from "../../../AccessRightsAPI";
import Reducer from '../../../Reducer';
import { format,differenceInMinutes } from 'date-fns'
import ExpandLessIcon from '@material-ui/icons/ExpandLess';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import ViewComponent from './ViewComponent';
import { PMSBuildingRegistryContext,ContextApi } from './MainComponent'
import {json} from './ej';
import multilingual from '../../../components/_helperComponents/tjson/multilingual';
import ToggleSwitch from '../../../components/_helperComponents/ToggleSwitch';
import Home from '@material-ui/icons/Home';
import { FormGroup } from '@material-ui/core';
import { MdOutlineArrowBackIosNew } from 'react-icons/md';
import { BsFileEarmarkCode } from 'react-icons/bs';
import { GrPowerReset } from 'react-icons/gr';
import { RiFileEditLine } from 'react-icons/ri';
import { GrAttachment } from 'react-icons/gr';
import { TbFilePencil } from 'react-icons/tb';


// Import_Process_ModulesComponents
import PMSBuildingRegistryTable from '../PMSBuildingRegistry/TableComponent';
import PMSBuildFacilityDetailsMain from'../../L1Bee/PMSBuildFacilityDetails/MainComponent';

import PMSBuildResponsePersonDetailsMain from'../../L1Bee/PMSBuildResponsePersonDetails/MainComponent';

import PMSBuildContPerDetailsMain from'../../L1Bee/PMSBuildContPerDetails/MainComponent';

import PMSBuildDefaultChargesDetailsMain from'../../L1Bee/PMSBuildDefaultChargesDetails/MainComponent';

import PMSBuildNotesDetailsMain from'../../L1Bee/PMSBuildNotesDetails/MainComponent';


// glbImportCreateEasyForms

// vOpenSlideImportsForView

// glbImportContextApiForms

// glbImportDialogOpenForms

// glbAddOnImportComponentStr



const initialState = {
            PMSBuildingIDPK: ""
             ,PMSBuilCode: ""
             ,PMSBuilName: ""
             ,PMSBuilNo: ""
             ,PMSBuilArInSqFet: ""
             ,PMSBuilLatitude: ""
             ,PMSBuilLongitude: ""
             ,PMSBuilCostGroup: ""
             ,PMSBuilPermitNo: ""
             ,PMSBuilConfig: ""
             ,PMSBuilMakaniNo: ""
             ,PMSBuilDMNo: ""
             ,PMSBuilNoOfFlor: ""
             ,PMSBuilNoOfPark: ""
             ,PMSBuilNoOfUnit: ""
             ,PMSBuilBUPArea: ""
             ,PMSBuilLeasArea: ""
             ,PMSBuilConsDateTime: ""
             ,PMSBuilConsDateTimeType: ""
             ,PMSBuilConsDateTimeBetween: ""
             ,PMSBuilHODateTime: ""
             ,PMSBuilHODateTimeType: ""
             ,PMSBuilHODateTimeBetween: ""
             ,PMSBuilTenanDateTime: ""
             ,PMSBuilTenanDateTimeType: ""
             ,PMSBuilTenanDateTimeBetween: ""
             ,PMSBuilGraPeriInMons: ""
             ,PMSBuilLeasDateTime: ""
             ,PMSBuilLeasDateTimeType: ""
             ,PMSBuilLeasDateTimeBetween: ""
             ,PMSBuilDescription: ""
             ,BuildingKey: ""
             ,IsDraft: false
             ,Remarks: ""
             ,LocalityID: null
             ,OrganisationID: null
             ,CountryID: null
             ,RegionID: null
             ,PMSBuildingComID: null
             ,AssBuildingTypeID: null
             ,PMSLandLordID: null
             ,EmployeeID: null
             ,EmployeeID1: ""
             ,IsActive: true
             ,DeleStat: false
             ,CreatedUserID: null
             ,CreatedTtm: ""
             ,CreatedTtmType: ""
             ,CreatedTtmBetween: ""
             ,UpdatedTtm: ""
             ,LocalityGroupID: null
             ,LocalityGroupCode: ""
             ,LocalityGroupName: ""
             ,CityID: null
             ,CityCode: ""
             ,CityName: ""
             ,AdminLocalityTypeID: null
             ,AdminLocalityTypeCode: ""
             ,AdminLocalityTypeName: ""
             ,LocalityCode: ""
             ,LocalityName: ""
             ,OrganisationCode: ""
             ,OrganisationName: ""
             ,CountryCode: ""
             ,CountryName: ""
             ,RegionCode: ""
             ,RegionName: ""
             ,PMSBuildingComCode: ""
             ,PMSBuildingComName: ""
             ,AssBuildingTypeCode: ""
             ,AssBuildingTypeName: ""
             ,ShiftID: null
             ,ShiftCode: ""
             ,ShiftName: ""
             ,ClassificationID: null
             ,ClassificationCode: ""
             ,ClassificationName: ""
             ,DepartmentID: null
             ,DepartmentCode: ""
             ,DepartmentName: ""
             ,DesignationID: null
             ,DesignationCode: ""
             ,DesignationName: ""
             ,NationalityID: null
             ,NationalityCode: ""
             ,NationalityName: ""
             ,EmpWorkNatureID: null
             ,NatureOfWorkCode: ""
             ,NatureOfWorkName: ""
             ,EmployeeTypeID: null
             ,EmployeeTypeCode: ""
             ,EmployeeTypeName: ""
             ,EmploymentTypeID: null
             ,EmploymentTypCode: ""
             ,EmploymentTypeName: ""
             ,EmployeeGroupID: null
             ,EmployeeGroupCode: ""
             ,EmployeeGroupName: ""
             ,EmpGradeID: null
             ,EmpGradeCode: ""
             ,EmpGradeName: ""
             ,EmpGenderID: null
             ,EmpGenderName: ""
             ,EmpTitleID: null
             ,EmpTitleName: ""
             ,EmployeeCode: ""
             ,FirstName: ""
             ,EmpContactNo1: ""
             ,EmpEmailOfficial: ""
             
             
             ,Type: "PMSBuildingID"
             
             
             ,UserGroupKey: localStorage.getItem('UserGroupID')
             ,UserAccessKey: localStorage.getItem('userid')
};






 // Main Function 
const PMSBuildingRegistry= forwardRef ((props,ref) =>{
const content = useSelector(state => state.form);
const [createEasy, setcreateEasy] = useState(false);

const [active,setActive]=useState(true);

const [ExpandView,setExpandView]=useState(false);
const [IsDraft,setIsDraft] = useState(false);
const [Tokenval,setTokenval]=useState(0);
const [Showtable,setShowtable]=useState(true);
const [AccessRights,setAccessRights] = useState({})

const [PMSBuildingRegistryComponent,setPMSBuildingRegistryComponent]=useState(true);
const [PMSBuildFacilityDetailsComponent,setPMSBuildFacilityDetailsComponent]=useState(false);
// --- Clear Code ----  const [PMSBuildFacilityDetailsCount,setPMSBuildFacilityDetailsCount]=useState(0);
const [PMSBuildResponsePersonDetailsComponent,setPMSBuildResponsePersonDetailsComponent]=useState(false);
// --- Clear Code ----  const [PMSBuildResponsePersonDetailsCount,setPMSBuildResponsePersonDetailsCount]=useState(0);
const [PMSBuildContPerDetailsComponent,setPMSBuildContPerDetailsComponent]=useState(false);
// --- Clear Code ----  const [PMSBuildContPerDetailsCount,setPMSBuildContPerDetailsCount]=useState(0);
const [PMSBuildDefaultChargesDetailsComponent,setPMSBuildDefaultChargesDetailsComponent]=useState(false);
// --- Clear Code ----  const [PMSBuildDefaultChargesDetailsCount,setPMSBuildDefaultChargesDetailsCount]=useState(0);
const [PMSBuildNotesDetailsComponent,setPMSBuildNotesDetailsComponent]=useState(false);
// --- Clear Code ----  const [PMSBuildNotesDetailsCount,setPMSBuildNotesDetailsCount]=useState(0);


const [PrimaryData,setPrimaryData]=useState([]);
const [ShowView,setShowView]=useState(false);
const AttRef=useRef();
const [ShowSlide,setShowSlide]=useState(false);
const [SlideComponentType,setSlideComponentType]=useState(null); 
const Level1CompRef=useRef(); 
const [PrimaryView,setPrimaryView]=useState(true);
const [PrimaryViewShow,setPrimaryViewShow]=useState(true);
const [TableCount,setTableCount]=useState(0);
const [ViewID,setViewID]=useState(0);
const [AccordianDetailData,setAccordianDetailData] = useState([]);
const [ShareData,setShareData] = useState([]);
const [state, dispatch] = useReducer(Reducer, initialState);
const [loading,setLoading]=useState(false);
const [Data,setData]=useState([]);
const [EnqDate,setEnqDate]=useState(null);
const context = useContext(PMSBuildingRegistryContext);
const {cstate , cdispatch} = ContextApi();
const [isSideMenu,setSideMenu] = useState(true);
const [openedMenu,setOpenedMenu] = useState("");
const[L1menu,setL1menu] = useState(false);
const [DefaultPrimaryId,setDefaultPrimaryId] =useState('')

const [ShowListPMSBuilCode ,setShowListPMSBuilCode] = useState(true);
const [ShowListPMSBuilName ,setShowListPMSBuilName] = useState(true);
const [ShowListPMSBuilNo ,setShowListPMSBuilNo] = useState(true);
const [ShowListPMSBuilCostGroup ,setShowListPMSBuilCostGroup] = useState(true);
const [DateErrPMSBuilConsDateTime ,setDateErrPMSBuilConsDateTime] = useState('');
const [DateErrPMSBuilHODateTime ,setDateErrPMSBuilHODateTime] = useState('');
const [DateErrPMSBuilTenanDateTime ,setDateErrPMSBuilTenanDateTime] = useState('');
const [DateErrPMSBuilLeasDateTime ,setDateErrPMSBuilLeasDateTime] = useState('');
const [ShowListBuildingKey ,setShowListBuildingKey] = useState(true);

const [PrimID, setPrimID] = useState(0);
const [Lang] = useState(localStorage.getItem('Language'));
const [FormLang] = useState(localStorage.getItem('Language'));
const [Expanded,setExpanded]=useState(false);
const [openCase, setopenCase] = useState(false);
const createEasyRef =useRef(null)
const [GridViewInboxApproval,setGridViewInboxApproval]=useState(false);

const [IsDefaultEntry,setIsDefaultEntry]=useState(false);
// QB-IsDefaultEntryForm = false
const [expandedPanel,setExpandedPanel] = useState(false);
const [defaultEditData, setDefaultEditData] =useState([]);
// QB-DesignVersion = D2



let lang = multilingual();
const t = (e) =>  lang?.[e] ? lang[e] : e ;
const tf = (e) =>  cstate.language?.[e] ? cstate.language[e] : e ;

useEffect(()=>{
       if(cstate.PrimaryId){ 
           setPrimID(Number(cstate.PrimaryId));
       } 
       },[cstate.PrimaryId]);

useEffect(()=>{
       if(cstate.editData.length < 0){
            Token(1).then(val => {PMSBuildingRegistry_Select(1,null,'SetDefaultPMSBuildingID',val); });
       }
},[]);

useEffect(()=>{
       if([defaultEditData].length > 0){ 
               editRecord(defaultEditData,'SetDefaultPMSBuildingID');
           } 
       },[defaultEditData]);

   useImperativeHandle(ref, () => ({
           getAlert : (val) => {
           cdispatch({ type: 'expandDetail',payload: true})
           setExpandView(false);
           },
           getPreview: (val) => {
           },
           clear: () => {
                   clear()
          PMSBuildingRegistry_Select(1,null,'SetDefaultPMSBuildingID',cstate.token[0]);
           },
           formlink: (e) => {
                   formlink(e)
           },
           editRecord: (row,draft,show) => {
               editRecord(row,'');
               setShowView(show);
           },
           Add: () => {
               clear();
               setShowView(false);
               cdispatch({ type: 'expandDetail',payload: 'mainpanel'})
           },
           Editview: (row,draft,show) => {
               editRecord(row,'');
               setShowView(show);
               setPrimaryViewShow(false);
           },
               IsInboxApproval:(e)=>{
               setGridViewInboxApproval(e)
           },
         CreateEasyProps: (v=true,CEP) => {
          if (CEP){
             SetAllValues(CEP);
             setExpanded(v);
          }else{
           clear();
           setExpanded(v);
          }
      }
   }));

   const handleChange = (panel,val) => (event, isExpanded) => {
       cdispatch({ type: 'expandDetail',payload: isExpanded ? panel : false})
       };

const convertDigitIn  = (str) => {
   if(!str){
return null;
  }
return str.split('-').reverse().join('-');
}

const convertDateTimeDigitIn  = (str) => {
   if(!str){
       return str;
   }else{
       if(str){
      let datetime = str.split(' ');
      let date = datetime[0].split('-').reverse().join('-');
      if(datetime.length == 2){
          return date+' '+datetime[1]
      }else{
          return date
      }
      }
  }
 }

const editRecord = (data,ParamType) =>{  
       cdispatch({type: 'ViewID', payload: data.PMSBuildingIDPK})

       if (ParamType == 'SetDefaultPMSBuildingID'){
               setDefaultPrimaryId(data.PMSBuildingIDPK)
       }else{
               setPrimID(props.primid ? Number(props.primid) : data.PMSBuildingIDPK);
               cdispatch({ type: 'PrimaryId',payload: data.PMSBuildingIDPK});
       }
         dispatch({ type: 'text',name: 'PMSBuilCode',value:data.PMSBuilCode ? data.PMSBuilCode: ''});
         dispatch({ type: 'text',name: 'PMSBuilName',value:data.PMSBuilName ? data.PMSBuilName: ''});
         dispatch({ type: 'text',name: 'PMSBuilNo',value:data.PMSBuilNo ? data.PMSBuilNo: ''});
         dispatch({ type: 'text',name: 'PMSBuilArInSqFet',value:data.PMSBuilArInSqFet ? data.PMSBuilArInSqFet: ''});
         dispatch({ type: 'number',name: 'LocalityID',number:data.LocalityID ? Number(data.LocalityID): 0});

         dispatch({ type: 'text',name: 'LocalityName',value:data.LocalityName});
         dispatch({ type: 'number',name: 'CountryID',number:data.CountryID ? Number(data.CountryID): 0});

         dispatch({ type: 'text',name: 'CountryName',value:data.CountryName});
         dispatch({ type: 'number',name: 'RegionID',number:data.RegionID ? Number(data.RegionID): 0});

         dispatch({ type: 'text',name: 'RegionName',value:data.RegionName});
         dispatch({ type: 'text',name: 'PMSBuilLatitude',value:data.PMSBuilLatitude ? data.PMSBuilLatitude: ''});
         dispatch({ type: 'text',name: 'PMSBuilLongitude',value:data.PMSBuilLongitude ? data.PMSBuilLongitude: ''});
         dispatch({ type: 'number',name: 'OrganisationID',number:data.OrganisationID ? Number(data.OrganisationID): 0});

         dispatch({ type: 'text',name: 'OrganisationName',value:data.OrganisationName});
         dispatch({ type: 'number',name: 'AssBuildingTypeID',number:data.AssBuildingTypeID ? Number(data.AssBuildingTypeID): 0});

         dispatch({ type: 'text',name: 'AssBuildingTypeName',value:data.AssBuildingTypeName});
         dispatch({ type: 'number',name: 'PMSBuildingComID',number:data.PMSBuildingComID ? Number(data.PMSBuildingComID): 0});

         dispatch({ type: 'text',name: 'PMSBuildingComName',value:data.PMSBuildingComName});
         dispatch({ type: 'number',name: 'PMSLandLordID',number:data.PMSLandLordID ? Number(data.PMSLandLordID): 0});

         dispatch({ type: 'text',name: 'PMSLLdName',value:data.PMSLLdName});
         dispatch({ type: 'text',name: 'PMSBuilCostGroup',value:data.PMSBuilCostGroup ? data.PMSBuilCostGroup: ''});
         dispatch({ type: 'text',name: 'PMSBuilPermitNo',value:data.PMSBuilPermitNo ? data.PMSBuilPermitNo: ''});
         dispatch({ type: 'number',name: 'EmployeeID',number:data.EmployeeID ? Number(data.EmployeeID): 0});

         dispatch({ type: 'text',name: 'FirstName',value:data.FirstName});
         dispatch({ type: 'number',name: 'EmployeeID1',number:data.EmployeeID1 ? Number(data.EmployeeID1): 0});

         dispatch({ type: 'text',name: 'FirstName1',value:data.FirstName1});
         dispatch({ type: 'text',name: 'PMSBuilConfig',value:data.PMSBuilConfig ? data.PMSBuilConfig: ''});
         dispatch({ type: 'text',name: 'PMSBuilMakaniNo',value:data.PMSBuilMakaniNo ? data.PMSBuilMakaniNo: ''});
         dispatch({ type: 'text',name: 'PMSBuilDMNo',value:data.PMSBuilDMNo ? data.PMSBuilDMNo: ''});
         dispatch({ type: 'text',name: 'PMSBuilNoOfFlor',value:data.PMSBuilNoOfFlor ? data.PMSBuilNoOfFlor: ''});
         dispatch({ type: 'text',name: 'PMSBuilNoOfPark',value:data.PMSBuilNoOfPark ? data.PMSBuilNoOfPark: ''});
         dispatch({ type: 'text',name: 'PMSBuilNoOfUnit',value:data.PMSBuilNoOfUnit ? data.PMSBuilNoOfUnit: ''});
         dispatch({ type: 'text',name: 'PMSBuilBUPArea',value:data.PMSBuilBUPArea ? data.PMSBuilBUPArea: ''});
         dispatch({ type: 'text',name: 'PMSBuilLeasArea',value:data.PMSBuilLeasArea ? data.PMSBuilLeasArea: ''});
         dispatch({ type: 'text',name: 'PMSBuilConsDateTime',value:data.PMSBuilConsDateTime ? convertDateTimeDigitIn(data.PMSBuilConsDateTime): null});
         dispatch({ type: 'text',name: 'PMSBuilHODateTime',value:data.PMSBuilHODateTime ? convertDateTimeDigitIn(data.PMSBuilHODateTime): null});
         dispatch({ type: 'text',name: 'PMSBuilTenanDateTime',value:data.PMSBuilTenanDateTime ? convertDateTimeDigitIn(data.PMSBuilTenanDateTime): null});
         dispatch({ type: 'text',name: 'PMSBuilLeasDateTime',value:data.PMSBuilLeasDateTime ? convertDateTimeDigitIn(data.PMSBuilLeasDateTime): null});
         dispatch({ type: 'text',name: 'PMSBuilGraPeriInMons',value:data.PMSBuilGraPeriInMons ? data.PMSBuilGraPeriInMons: ''});
         dispatch({ type: 'text',name: 'PMSBuilDescription',value:data.PMSBuilDescription ? data.PMSBuilDescription: ''});
         dispatch({ type: 'number',name: 'BuildingKey',number:data.BuildingKey});
if(data.IsActive){
          setActive(data.IsActive == '1' ? true : false )
}

dispatch({ type: 'PMSBuildFacilityDetails_Edit',PMSBuildFacilityDetailsPMSBuildingID: data.PMSBuildingIDPK,PMSBuilName:data.PMSBuilName});

dispatch({ type: 'PMSBuildResponsePersonDetails_Edit',PMSBuildResponsePersonDetailsPMSBuildingID: data.PMSBuildingIDPK,PMSBuilName:data.PMSBuilName});

dispatch({ type: 'PMSBuildContPerDetails_Edit',PMSBuildContPerDetailsPMSBuildingID: data.PMSBuildingIDPK,PMSBuilName:data.PMSBuilName});

dispatch({ type: 'PMSBuildDefaultChargesDetails_Edit',PMSBuildDefaultChargesDetailsPMSBuildingID: data.PMSBuildingIDPK,PMSBuilName:data.PMSBuilName});

dispatch({ type: 'PMSBuildNotesDetails_Edit',PMSBuildNotesDetailsPMSBuildingID: data.PMSBuildingIDPK,PMSBuilName:data.PMSBuilName});

//DetailShareCount(data.PMSBuildingIDPK);
}

function DetailShareCount(ID){
let url = config.Api + 'FP1394S6/';
let params = {
"data":
{
            "p1": ID
               ,"p2": null
               ,"p3": null
               ,"p4": null
               ,"p5": null
               ,"p6": null
               ,"p7": null
               ,"p8": null
               ,"p9": null
               ,"p10": null
               ,"p11": null
               ,"p12": null
               ,"p13": null
               ,"p14": null
               ,"p15": null
               ,"p16": null
               ,"p17": null
               ,"p18": null
               ,"p19": null
               ,"p20": null
               ,"p21": null
               ,"p22": null
               ,"p23": null
               ,"p24": null
               ,"p25": null
               ,"p26": null
               ,"p27": null
               ,"p28": null
               ,"p29": null
               ,"p30": null
               ,"p31": null
               ,"p32": null
               ,"p33": null
               ,"p34": null
               ,"p35": null
               ,"p36": null
               ,"p37": null
               ,"p38": null
               ,"p39": null
               ,"p40": null
               ,"p41": null
               ,"p42": null
               ,"p43": null
               ,"p44": props.Dialogview ? "1" : null
               ,"p45": null
               ,"p46": null
               ,"p47": null
               ,"p48": null
               ,"p49": null
               ,"p50": null
               ,"p51": null
               ,"p52": null
               ,"p53": null
               ,"p54": null
               ,"p55": null
               ,"p56": null
               ,"p57": null
               ,"p58": null
               ,"p59": null
               ,"p60": null
               ,"p61": null
               ,"p62": null
               ,"p63": null
               ,"p64": null
               ,"p65": null
               ,"p66": null
               ,"p67": null
               ,"p68": null
               ,"p69": null
               ,"p70": null
               ,"p71": null
               ,"p72": null
               ,"p73": null
               ,"p74": null
               ,"p75": null
               ,"p76": null
               ,"p77": null
               ,"p78": null
               ,"p79": null
               ,"p80": null
               ,"p81": null
               ,"p82": null
               ,"p83": null
               ,"p84": null
               ,"p85": null
               ,"p86": null
               ,"p87": null
               ,"p88": null
               ,"p89": null
               ,"p90": null
               ,"p91": null
               ,"p92": null
               ,"p93": null
               ,"p94": null
               ,"p95": null
               ,"p96": null
               ,"p97": null
               ,"p98": null
               ,"p99": null
               ,"p100": null
               ,"p101": null
               ,"p102": null
               ,"p103": null
               ,"p104": null
               ,"p105": null
               ,"p106": null
               ,"p107": null
               ,"p108": null
               ,"p109": null
             ,"p110": 1
             ,"p111": 10
             ,"p112": "PMSBuildingIDPK"
               ,"p113": null
               ,"p114": null
               ,"p115": null
               ,"p116": null
   }
   }
   CommonAPISelect(url,params,cstate.token[0])
      .then(res => { 
           if(res.Output.status.code == '200'){
               if(res.Output.data){
                   let result = res.Output.data.length;
                   let data = res.Output.data;
                  if(result > 0){
                           setShareData(data);
                   }
               }
           }
       });
   }
const clear = () => {
 setAccordianDetailData([]);
 setPrimID(0);
 setDefaultPrimaryId('')

cdispatch({ type: 'PrimaryId',payload: ''});
         dispatch({ type: 'text',name: 'PMSBuilCode',value:""});
         dispatch({ type: 'text',name: 'PMSBuilName',value:""});
         dispatch({ type: 'text',name: 'PMSBuilNo',value:""});
         dispatch({ type: 'text',name: 'PMSBuilArInSqFet',value:""});
  dispatch({ type: 'text',name: 'LocalityID',value:null});

     dispatch({ type: 'text',name: 'LocalityName',value:""});
         if(document.getElementById("PMSBuildingRegistryLocalityNameClear")){
             document.getElementById("PMSBuildingRegistryLocalityNameClear").click()
         }
  dispatch({ type: 'text',name: 'CountryID',value:null});

     dispatch({ type: 'text',name: 'CountryName',value:""});
         if(document.getElementById("PMSBuildingRegistryCountryNameClear")){
             document.getElementById("PMSBuildingRegistryCountryNameClear").click()
         }
  dispatch({ type: 'text',name: 'RegionID',value:null});

     dispatch({ type: 'text',name: 'RegionName',value:""});
         if(document.getElementById("PMSBuildingRegistryRegionNameClear")){
             document.getElementById("PMSBuildingRegistryRegionNameClear").click()
         }
         dispatch({ type: 'text',name: 'PMSBuilLatitude',value:""});
         dispatch({ type: 'text',name: 'PMSBuilLongitude',value:""});
  dispatch({ type: 'text',name: 'OrganisationID',value:null});

     dispatch({ type: 'text',name: 'OrganisationName',value:""});
         if(document.getElementById("PMSBuildingRegistryOrganisationNameClear")){
             document.getElementById("PMSBuildingRegistryOrganisationNameClear").click()
         }
  dispatch({ type: 'text',name: 'AssBuildingTypeID',value:null});

     dispatch({ type: 'text',name: 'AssBuildingTypeName',value:""});
         if(document.getElementById("PMSBuildingRegistryAssBuildingTypeNameClear")){
             document.getElementById("PMSBuildingRegistryAssBuildingTypeNameClear").click()
         }
  dispatch({ type: 'text',name: 'PMSBuildingComID',value:null});

     dispatch({ type: 'text',name: 'PMSBuildingComName',value:""});
         if(document.getElementById("PMSBuildingRegistryPMSBuildingComNameClear")){
             document.getElementById("PMSBuildingRegistryPMSBuildingComNameClear").click()
         }
  dispatch({ type: 'text',name: 'PMSLandLordID',value:null});

     dispatch({ type: 'text',name: 'PMSLLdName',value:""});
         if(document.getElementById("PMSBuildingRegistryPMSLLdNameClear")){
             document.getElementById("PMSBuildingRegistryPMSLLdNameClear").click()
         }
         dispatch({ type: 'text',name: 'PMSBuilCostGroup',value:""});
         dispatch({ type: 'text',name: 'PMSBuilPermitNo',value:""});
  dispatch({ type: 'text',name: 'EmployeeID',value:null});

     dispatch({ type: 'text',name: 'FirstName',value:""});
         if(document.getElementById("PMSBuildingRegistryFirstNameClear")){
             document.getElementById("PMSBuildingRegistryFirstNameClear").click()
         }
  dispatch({ type: 'text',name: 'EmployeeID1',value:null});

     dispatch({ type: 'text',name: 'FirstName1',value:""});
         if(document.getElementById("PMSBuildingRegistryFirstName1Clear")){
             document.getElementById("PMSBuildingRegistryFirstName1Clear").click()
         }
         dispatch({ type: 'text',name: 'PMSBuilConfig',value:""});
         dispatch({ type: 'text',name: 'PMSBuilMakaniNo',value:""});
         dispatch({ type: 'text',name: 'PMSBuilDMNo',value:""});
         dispatch({ type: 'text',name: 'PMSBuilNoOfFlor',value:""});
         dispatch({ type: 'text',name: 'PMSBuilNoOfPark',value:""});
         dispatch({ type: 'text',name: 'PMSBuilNoOfUnit',value:""});
         dispatch({ type: 'text',name: 'PMSBuilBUPArea',value:""});
         dispatch({ type: 'text',name: 'PMSBuilLeasArea',value:""});
         dispatch({ type: 'text',name: 'PMSBuilConsDateTime',value: null});
         dispatch({ type: 'text',name: 'PMSBuilHODateTime',value: null});
         dispatch({ type: 'text',name: 'PMSBuilTenanDateTime',value: null});
         dispatch({ type: 'text',name: 'PMSBuilLeasDateTime',value: null});
         dispatch({ type: 'text',name: 'PMSBuilGraPeriInMons',value:""});
         dispatch({ type: 'text',name: 'PMSBuilDescription',value:""});
         dispatch({ type: 'number',name: 'BuildingKey',number:0 });

      setShowListPMSBuilCode(true);
      setShowListPMSBuilName(true);
      setShowListPMSBuilNo(true);
      setShowListPMSBuilCostGroup(true);
      setShowListBuildingKey(true);
 setActive(true);

}

const submitConfirmation = (type) => {

if(!trimFunc(state.PMSBuilName)){
           context.alert({ open:true,color:'warning',message:[t('Please enter the') + '' + tf('PMSBuilName')]});
          return false;
}
if(!trimFunc(state.PMSBuilNo)){
           context.alert({ open:true,color:'warning',message:[t('Please enter the') + '' + tf('PMSBuilNo')]});
          return false;
}
if(!state.LocalityID || (state.LocalityID == 0)){
           context.alert({ open:true,color:'warning',message:[t('Please select the ')+ ' ' + tf('LocalityID')]});
          return false;
}
if(!state.AssBuildingTypeID || (state.AssBuildingTypeID == 0)){
           context.alert({ open:true,color:'warning',message:[t('Please select the ')+ ' ' + tf('AssBuildingTypeID')]});
          return false;
}
if(!state.PMSLandLordID || (state.PMSLandLordID == 0)){
           context.alert({ open:true,color:'warning',message:[t('Please select the ')+ ' ' + tf('PMSLandLordID')]});
          return false;
}


saveAlert(type)
}
const CheckValues = () =>{
     let removeitem=['IsActive','IsDefault','UserGroupKey','UserAccessKey','DeleStat','Type']
     const Duplicate = {...state}
     removeitem.map(v => {
     delete Duplicate[v];
    })
       return Object.keys(Duplicate).filter(key => Duplicate[key])
}
// Save Alert
    const saveAlert = () =>{
    context.ConfirmAlert(
        <SweetAlert
           warning
           Size = "sm"
           style={{ display: "block", marginTop: "100px" }}
           title = {t("Are you sure?")}               onConfirm={() => AlreadyExistsFunction()}
               onCancel={() => context.ConfirmAlert(null)}

           confirmBtnCssClass = 'swalokbtn'
           cancelBtnCssClass = 'swalcancelbtn'

           confirmBtnText = {t("Yes")}
           cancelBtnText = {t("Cancel")}
           showCancel
           >
           {t("Do you want to Save?")}
       </SweetAlert>
   );
   } //   Record Already Exists Function
 const AlreadyExistsFunction = (ParamType) => {
      context.loading(true)
      context.ConfirmAlert(null);
      const url = config.Api + "FP1394S2/";
      const SubmitParam = {
"data": [          {
            "p1": ParamType =='SetDefaultPMSBuildingID' ? ((DefaultPrimaryId == "NORECORDS"|| !DefaultPrimaryId) ? 0 : DefaultPrimaryId) : PrimID
            ,"p2": trimFunc(state.PMSBuilCode)
            ,"p3": trimFunc(state.PMSBuilName)
            ,"p4": trimFunc(state.PMSBuilNo)
            ,"p5": trimFunc(state.PMSBuilArInSqFet)
            ,"p6": trimFunc(state.PMSBuilLatitude)
            ,"p7": trimFunc(state.PMSBuilLongitude)
            ,"p8": trimFunc(state.PMSBuilCostGroup)
            ,"p9": trimFunc(state.PMSBuilPermitNo)
            ,"p10": trimFunc(state.PMSBuilConfig)
            ,"p11": trimFunc(state.PMSBuilMakaniNo)
            ,"p12": trimFunc(state.PMSBuilDMNo)
            ,"p13": trimFunc(state.PMSBuilNoOfFlor)
            ,"p14": trimFunc(state.PMSBuilNoOfPark)
            ,"p15": trimFunc(state.PMSBuilNoOfUnit)
            ,"p16": trimFunc(state.PMSBuilBUPArea)
            ,"p17": trimFunc(state.PMSBuilLeasArea)
            ,"p18": state.PMSBuilConsDateTime ? state.PMSBuilConsDateTime: null
            ,"p19": state.PMSBuilHODateTime ? state.PMSBuilHODateTime: null
            ,"p20": state.PMSBuilTenanDateTime ? state.PMSBuilTenanDateTime: null
            ,"p21": trimFunc(state.PMSBuilGraPeriInMons)
            ,"p22": state.PMSBuilLeasDateTime ? state.PMSBuilLeasDateTime: null
            ,"p23": trimFunc(state.PMSBuilDescription)
            ,"p24": state.BuildingKey ? Number(state.BuildingKey) : 0
            ,"p25":false
            ,"p26": ParamType =='SetDefaultPMSBuildingID' ? "SetDefault" : null
            ,"p27": state.LocalityID ? state.LocalityID : 0
            ,"p28": state.OrganisationID ? state.OrganisationID : 0
            ,"p29": state.CountryID ? state.CountryID : 0
            ,"p30": state.RegionID ? state.RegionID : 0
            ,"p31": state.PMSBuildingComID ? state.PMSBuildingComID : 0
            ,"p32": state.AssBuildingTypeID ? state.AssBuildingTypeID : 0
            ,"p33": state.PMSLandLordID ? state.PMSLandLordID : 0
            ,"p34": state.EmployeeID ? state.EmployeeID : 0
            ,"p35": state.EmployeeID1 ? state.EmployeeID1 : 0
            ,"p36": active
            ,"p37": ParamType =='SetDefaultPMSBuildingID' ? true : false
            ,"p38":localStorage.getItem('userid')
            ,"p39":moment().format("YYYY-MM-DD hh:mm:ss")
            ,"p40":localStorage.getItem('userid')
            ,"p41":moment().format("YYYY-MM-DD hh:mm:ss")
          }
      ]
  }


  Token(0).then(token=>{  
       CommonAPISelect(url,SubmitParam,token)
       .then((res)=>{
             const status = res.Output[0].status;
        let result = res.Output[0].Data;
         let msgCodeArr=new Array();
            let msgArr=new Array();
   if(status.code === "200"){
    var msg="";
    result.map((val) => {
     if(val){
        msgCodeArr.push(val.IsAlert);
        msgArr.push(val.AlertMessage);
        msg+=val.AlertMessage+"\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0\xa0";
     }
    });
    if(msgCodeArr.some(e => e == "1")){ 
        context.alert({ open:true,color:'warning',message: msgArr});
        context.loading(false);
    }else{
        saveSubmit(ParamType);
      }
     }else{
         context.alert({ open:true,color:'warning',message: [res.Output[0].status.message]});
         context.loading(false);
     }
   })
  })
 }
 //   Record Save or Edit Submit Function
      const saveSubmit = (ParamType) => {

      setShowListPMSBuilCode(true);
      setShowListPMSBuilName(true);
      setShowListPMSBuilNo(true);
      setShowListPMSBuilCostGroup(true);
      setShowListBuildingKey(true);
      context.ConfirmAlert(null);
      const url = config.Api + "FP1394S1/";

      const SubmitParam = {
"data": [          {
            "p1": ParamType =='SetDefaultPMSBuildingID' ? ((DefaultPrimaryId == "NORECORDS"|| !DefaultPrimaryId) ? 0 : DefaultPrimaryId) : PrimID
            ,"p2": trimFunc(state.PMSBuilCode)
            ,"p3": trimFunc(state.PMSBuilName)
            ,"p4": trimFunc(state.PMSBuilNo)
            ,"p5": trimFunc(state.PMSBuilArInSqFet)
            ,"p6": trimFunc(state.PMSBuilLatitude)
            ,"p7": trimFunc(state.PMSBuilLongitude)
            ,"p8": trimFunc(state.PMSBuilCostGroup)
            ,"p9": trimFunc(state.PMSBuilPermitNo)
            ,"p10": trimFunc(state.PMSBuilConfig)
            ,"p11": trimFunc(state.PMSBuilMakaniNo)
            ,"p12": trimFunc(state.PMSBuilDMNo)
            ,"p13": trimFunc(state.PMSBuilNoOfFlor)
            ,"p14": trimFunc(state.PMSBuilNoOfPark)
            ,"p15": trimFunc(state.PMSBuilNoOfUnit)
            ,"p16": trimFunc(state.PMSBuilBUPArea)
            ,"p17": trimFunc(state.PMSBuilLeasArea)
            ,"p18": state.PMSBuilConsDateTime ? state.PMSBuilConsDateTime: null
            ,"p19": state.PMSBuilHODateTime ? state.PMSBuilHODateTime: null
            ,"p20": state.PMSBuilTenanDateTime ? state.PMSBuilTenanDateTime: null
            ,"p21": trimFunc(state.PMSBuilGraPeriInMons)
            ,"p22": state.PMSBuilLeasDateTime ? state.PMSBuilLeasDateTime: null
            ,"p23": trimFunc(state.PMSBuilDescription)
            ,"p24": state.BuildingKey ? Number(state.BuildingKey) : 0
            ,"p25":false
            ,"p26": ParamType =='SetDefaultPMSBuildingID' ? "SetDefault" : null
            ,"p27": state.LocalityID ? state.LocalityID : 0
            ,"p28": state.OrganisationID ? state.OrganisationID : 0
            ,"p29": state.CountryID ? state.CountryID : 0
            ,"p30": state.RegionID ? state.RegionID : 0
            ,"p31": state.PMSBuildingComID ? state.PMSBuildingComID : 0
            ,"p32": state.AssBuildingTypeID ? state.AssBuildingTypeID : 0
            ,"p33": state.PMSLandLordID ? state.PMSLandLordID : 0
            ,"p34": state.EmployeeID ? state.EmployeeID : 0
            ,"p35": state.EmployeeID1 ? state.EmployeeID1 : 0
            ,"p36": active
            ,"p37": ParamType =='SetDefaultPMSBuildingID' ? true : false
            ,"p38":localStorage.getItem('userid')
            ,"p39":moment().format("YYYY-MM-DD hh:mm:ss")
            ,"p40":localStorage.getItem('userid')
            ,"p41":moment().format("YYYY-MM-DD hh:mm:ss")
          }
      ]
  }


  Token(0).then(token=>{  
        CommonAPISave(url,SubmitParam,token)
       .then((res)=>{
            const status = res[0].status;
            if(status.code == 200){
                if (ParamType=='SetDefaultPMSBuildingID'){
                       context.alert({ open:true,color:'success',message: ['Default Record Configured']});
                }else{
                       context.alert({ open:true,color:'success',message: [status.message]});
                       cdispatch({type: 'ViewID', payload: res[0].Data.IDPK})
                       cdispatch({ type :'PrimaryId', payload: res[0].Data.IDPK});

                }
                context.attachmentSave(res[0].Data.IDPK)
                context.loading(false);                context.Approval(GridViewInboxApproval)

            var attachid = document.getElementById("overlayimgAttPMSBuildingRegistry");
            if(attachid){
               document.getElementById("overlayimgAttPMSBuildingRegistry").style.width="0%";
               document.getElementById("overlayimgAttPMSBuildingRegistry").style.display="none";
            }
            }else{
                context.alert({ open:true,color:'warning',message: [status.message]})
                context.loading(false);
            } 
                if (ParamType=='SetDefaultPMSBuildingID'){
                       setExpanded(true);
                       PMSBuildingRegistry_Select(1,null,'SetDefaultPMSBuildingID',cstate.token[0]);
               }else{
               setShowView(true)
    }
        })
      })
    }


function OpenSlideViewComponent(type,id){ 
 }

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
function DraftSave(draftdel,vRemarks,vDeleStat,ParamType){
 if(cstate.count > 0){ 
if(CheckValues().length > 0){

      setShowListPMSBuilCode(true);
      setShowListPMSBuilName(true);
      setShowListPMSBuilNo(true);
      setShowListPMSBuilCostGroup(true);
      setShowListBuildingKey(true);
      context.loading(true)
      context.ConfirmAlert(null);
      const url = config.Api + "FP1394S1/";
      const SubmitParam = {
"data": [          {
            "p1": ParamType =='SetDefaultPMSBuildingID' ? ((DefaultPrimaryId == "NORECORDS"|| !DefaultPrimaryId) ? 0 : DefaultPrimaryId) : PrimID
            ,"p2": trimFunc(state.PMSBuilCode)
            ,"p3": trimFunc(state.PMSBuilName)
            ,"p4": trimFunc(state.PMSBuilNo)
            ,"p5": trimFunc(state.PMSBuilArInSqFet)
            ,"p6": trimFunc(state.PMSBuilLatitude)
            ,"p7": trimFunc(state.PMSBuilLongitude)
            ,"p8": trimFunc(state.PMSBuilCostGroup)
            ,"p9": trimFunc(state.PMSBuilPermitNo)
            ,"p10": trimFunc(state.PMSBuilConfig)
            ,"p11": trimFunc(state.PMSBuilMakaniNo)
            ,"p12": trimFunc(state.PMSBuilDMNo)
            ,"p13": trimFunc(state.PMSBuilNoOfFlor)
            ,"p14": trimFunc(state.PMSBuilNoOfPark)
            ,"p15": trimFunc(state.PMSBuilNoOfUnit)
            ,"p16": trimFunc(state.PMSBuilBUPArea)
            ,"p17": trimFunc(state.PMSBuilLeasArea)
            ,"p18": state.PMSBuilConsDateTime ? state.PMSBuilConsDateTime: null
            ,"p19": state.PMSBuilHODateTime ? state.PMSBuilHODateTime: null
            ,"p20": state.PMSBuilTenanDateTime ? state.PMSBuilTenanDateTime: null
            ,"p21": trimFunc(state.PMSBuilGraPeriInMons)
            ,"p22": state.PMSBuilLeasDateTime ? state.PMSBuilLeasDateTime: null
            ,"p23": trimFunc(state.PMSBuilDescription)
            ,"p24": state.BuildingKey ? Number(state.BuildingKey) : 0
            ,"p25": true
            ,"p26": ParamType =='SetDefaultPMSBuildingID' ? "SetDefault" : null
            ,"p27": state.LocalityID ? state.LocalityID : 0
            ,"p28": state.OrganisationID ? state.OrganisationID : 0
            ,"p29": state.CountryID ? state.CountryID : 0
            ,"p30": state.RegionID ? state.RegionID : 0
            ,"p31": state.PMSBuildingComID ? state.PMSBuildingComID : 0
            ,"p32": state.AssBuildingTypeID ? state.AssBuildingTypeID : 0
            ,"p33": state.PMSLandLordID ? state.PMSLandLordID : 0
            ,"p34": state.EmployeeID ? state.EmployeeID : 0
            ,"p35": state.EmployeeID1 ? state.EmployeeID1 : 0
            ,"p36":false
            ,"p37": ParamType =='SetDefaultPMSBuildingID' ? true : false
            ,"p38":localStorage.getItem('userid')
            ,"p39":moment().format("YYYY-MM-DD hh:mm:ss")
            ,"p40":localStorage.getItem('userid')
            ,"p41":moment().format("YYYY-MM-DD hh:mm:ss")
          }
      ]
  }


Token(0).then(token=>{  
     CommonAPISave(url,SubmitParam,token)
     .then((res)=>{
          const status = res[0].status;
          if(status.code == 200){
              if(draftdel){
                   context.alert({ open:true,color:'warning',message: ['Deleted Successfully']});
               }else{
                   context.alert({ open:true,color:'success',message: ['Saved to Draft']});
               }
              clear();
              props.clrImgstate(true); 
              ShowTableDiv(true);
              context.loading(false)
                var attachid = document.getElementById("overlayimgAttPMSBuildingRegistry");
                    if(attachid){
                        document.getElementById("overlayimgAttPMSBuildingRegistry").style.width="0%";
                        document.getElementById("overlayimgAttPMSBuildingRegistry").style.display="none";
                       // document.getElementById("divPMSBuildingRegistry").style.width = "100%";
                    }
          }else{
              context.alert({ open:true,color:'warning',message: [status.message]})
              context.loading(false)
          } 
      })
  })
}else {
   context.alert({ open:true,color:'warning',message:['Please enter the primary fields']});
}
}else {
   context.alert({ open:true,color:'warning',message:['Please save atleast one record']});
return false;
}
}


function closeNav() {
    document.getElementById('PMSBuildingRegistrySideBar').style.width = '0';
    setShowSlide(false);
}

function OpenSlideComponent(formId){

         CreateEasy(formId,PMSBuildingRegistryContext, {cstate,cdispatch},context,createEasyRef);
         return false;
}

function OpenDialogComponent(formId,field){
         AdvanceSearch(formId,field,PMSBuildingRegistryContext, ContextApi(),storeDispatch,ref);
         return false;
}

function AddAccordianDetails(e){
        let arr = [];
        AccordianDetailData.map((val,i) => {
            if(Object.keys(e)[0] !== Object.keys(val)[0]){
                arr.push(val);
            }
        })
        setAccordianDetailData([e,...arr]);
    }
function ShowTableDiv(val){ 
    if(val){
         document.getElementById("PMSBuildingRegistry-MainTable").style.width = "0%";
         document.getElementById("PMSBuildingRegistry-MainEntry").style.width = "100%";
         document.getElementById("PMSBuildingRegistry-MainEntry").style.display="flex";
         document.getElementById("PMSBuildingRegistry-MainTable").style.display="none";
         setShowtable(false);
         }else{
         document.getElementById("PMSBuildingRegistry-MainTable").style.width = "100%";
         document.getElementById("PMSBuildingRegistry-MainTable").style.display = "block";
         document.getElementById("PMSBuildingRegistry-MainEntry").style.width = "0%";
         document.getElementById("PMSBuildingRegistry-MainEntry").style.display="none";
         context.ShowTableDiv(false);
         setShowtable(true);
         setPrimaryViewShow(true);
    }
}

function formlink(id){
        return false 
}

const handleChangePanel = (panel) => (e, isExpanded) => {
       setExpandedPanel(isExpanded ? panel : false);
}


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++







const PMSBuildingRegistry_Select = (index,val,ParamType,token,auto) => {
<<<InstantInsert_Select_CheckStr>>>

const url = config.Api +"FP1394S3/";
const params = {
"data":{
            "p1": null
             ,"p2": null
             ,"p3": null
             ,"p4": null
             ,"p5": null
             ,"p6": null
             ,"p7": null
             ,"p8": null
             ,"p9": null
             ,"p10": null
             ,"p11": null
             ,"p12": null
             ,"p13": null
             ,"p14": null
             ,"p15": null
             ,"p16": null
             ,"p17": null
             ,"p18": state.PMSBuilConsDateTime ? state.PMSBuilConsDateTime : null
             ,"p19": null
             ,"p20": null
             ,"p21": state.PMSBuilHODateTime ? state.PMSBuilHODateTime : null
             ,"p22": null
             ,"p23": null
             ,"p24": state.PMSBuilTenanDateTime ? state.PMSBuilTenanDateTime : null
             ,"p25": null
             ,"p26": null
             ,"p27": null
             ,"p28": state.PMSBuilLeasDateTime ? state.PMSBuilLeasDateTime : null
             ,"p29": null
             ,"p30": null
             ,"p31": null
             ,"p32": null
             ,"p33": null
             ,"p34": null
             ,"p35": state.LocalityID == '0' ? null : state.LocalityID
             ,"p36": state.OrganisationID == '0' ? null : state.OrganisationID
             ,"p37": state.CountryID == '0' ? null : state.CountryID
             ,"p38": state.RegionID == '0' ? null : state.RegionID
             ,"p39": state.PMSBuildingComID == '0' ? null : state.PMSBuildingComID
             ,"p40": state.AssBuildingTypeID == '0' ? null : state.AssBuildingTypeID
             ,"p41": state.PMSLandLordID == '0' ? null : state.PMSLandLordID
             ,"p42": state.EmployeeID == '0' ? null : state.EmployeeID
             ,"p43": state.EmployeeID1 == '0' ? null : state.EmployeeID1
             ,"p44": props.Dialogview ? "1" : null
             ,"p45": null
             ,"p46": null
             ,"p47": null
             ,"p48": null
             ,"p49": null
             ,"p50": null
             ,"p51": state.LocalityGroupID == '0' ? null : state.LocalityGroupID
             ,"p52": val ? '%' + val + '%' : null
             ,"p53": val ? '%' + val + '%' : null
             ,"p54": state.CityID == '0' ? null : state.CityID
             ,"p55": val ? '%' + val + '%' : null
             ,"p56": val ? '%' + val + '%' : null
             ,"p57": state.AdminLocalityTypeID == '0' ? null : state.AdminLocalityTypeID
             ,"p58": val ? '%' + val + '%' : null
             ,"p59": val ? '%' + val + '%' : null
             ,"p60": val ? '%' + val + '%' : null
             ,"p61": val ? '%' + val + '%' : null
             ,"p62": val ? '%' + val + '%' : null
             ,"p63": val ? '%' + val + '%' : null
             ,"p64": val ? '%' + val + '%' : null
             ,"p65": val ? '%' + val + '%' : null
             ,"p66": val ? '%' + val + '%' : null
             ,"p67": val ? '%' + val + '%' : null
             ,"p68": val ? '%' + val + '%' : null
             ,"p69": val ? '%' + val + '%' : null
             ,"p70": val ? '%' + val + '%' : null
             ,"p71": val ? '%' + val + '%' : null
             ,"p72": state.ShiftID == '0' ? null : state.ShiftID
             ,"p73": val ? '%' + val + '%' : null
             ,"p74": val ? '%' + val + '%' : null
             ,"p75": state.ClassificationID == '0' ? null : state.ClassificationID
             ,"p76": val ? '%' + val + '%' : null
             ,"p77": val ? '%' + val + '%' : null
             ,"p78": state.DepartmentID == '0' ? null : state.DepartmentID
             ,"p79": val ? '%' + val + '%' : null
             ,"p80": val ? '%' + val + '%' : null
             ,"p81": state.DesignationID == '0' ? null : state.DesignationID
             ,"p82": val ? '%' + val + '%' : null
             ,"p83": val ? '%' + val + '%' : null
             ,"p84": state.NationalityID == '0' ? null : state.NationalityID
             ,"p85": val ? '%' + val + '%' : null
             ,"p86": val ? '%' + val + '%' : null
             ,"p87": state.EmpWorkNatureID == '0' ? null : state.EmpWorkNatureID
             ,"p88": val ? '%' + val + '%' : null
             ,"p89": val ? '%' + val + '%' : null
             ,"p90": state.EmployeeTypeID == '0' ? null : state.EmployeeTypeID
             ,"p91": val ? '%' + val + '%' : null
             ,"p92": val ? '%' + val + '%' : null
             ,"p93": state.EmploymentTypeID == '0' ? null : state.EmploymentTypeID
             ,"p94": val ? '%' + val + '%' : null
             ,"p95": val ? '%' + val + '%' : null
             ,"p96": state.EmployeeGroupID == '0' ? null : state.EmployeeGroupID
             ,"p97": val ? '%' + val + '%' : null
             ,"p98": val ? '%' + val + '%' : null
             ,"p99": state.EmpGradeID == '0' ? null : state.EmpGradeID
             ,"p100": val ? '%' + val + '%' : null
             ,"p101": val ? '%' + val + '%' : null
             ,"p102": state.EmpGenderID == '0' ? null : state.EmpGenderID
             ,"p103": val ? '%' + val + '%' : null
             ,"p104": state.EmpTitleID == '0' ? null : state.EmpTitleID
             ,"p105": val ? '%' + val + '%' : null
             ,"p106": val ? '%' + val + '%' : null
             ,"p107": val ? '%' + val + '%' : null
             ,"p108": val ? '%' + val + '%' : null
             ,"p109": val ? '%' + val + '%' : null
             ,"p110": index
             ,"p111": 10
             ,"p112":  ParamType
             ,"p113": null
             ,"p114": null
             ,"p115": localStorage.getItem('UserGroupID')
             ,"p116": localStorage.getItem('userid')
   }
 }
   const clearAll = Object.keys(params.data).slice(0, Object.keys(params.data).length).reduce((acc, key,i) => {
       acc[key] = (i > Object.keys(params.data).length - 8) ? params.data[key] :  null ;
       return acc;
   }, {});
   setLoading(true);
   const clearAllParams = {data:clearAll}

   return CommonAPISelect(url,(ParamType == 'ClearAll' ? clearAllParams : params),((ParamType == 'SetDefaultPMSBuildingID' && token) ? token:  cstate.token[0]))
            .then((res)=>{ 
                const result = res.Output.status.code;
                const data = res.Output.data;
                if(result == '200'){    
                  const length = data.length;
                  if(auto) return data ? data[0] : {};


                   if (index == 1) {
                        if(length > 0){
                                    setData(data);

                        }else{
                                    setData([]);
                            }
                        } else {
                                    setData(Data.concat(data));
                        }

   if (ParamType =='SetDefaultPMSBuildingID'){
                if(length > 0 ){

               setDefaultEditData(data[0]) 

                }else{
                    setDefaultPrimaryId("NORECORDS");
                }
            }
                    setLoading(false);
           }
 else{
           context.alert({open: true,color:'warning',message: [res.Output.status.message]});
           setLoading(false);
     }
  });
}

const PMSBuildingRegistry_SelectText = (index,val,ParamType) => {
const url = config.Api +"FP1394S3/";
const params = {
"data":{
            "p1": null
             ,"p2": ParamType == "PMSBuilCode" ? (val ? '%' + val + '%' : null) : null
             ,"p3": ParamType == "PMSBuilName" ? (val ? '%' + val + '%' : null) : null
             ,"p4": ParamType == "PMSBuilNo" ? (val ? '%' + val + '%' : null) : null
             ,"p5": ParamType == "PMSBuilArInSqFet" ? (val ? '%' + val + '%' : null) : null
             ,"p6": ParamType == "PMSBuilLatitude" ? (val ? '%' + val + '%' : null) : null
             ,"p7": ParamType == "PMSBuilLongitude" ? (val ? '%' + val + '%' : null) : null
             ,"p8": ParamType == "PMSBuilCostGroup" ? (val ? '%' + val + '%' : null) : null
             ,"p9": ParamType == "PMSBuilPermitNo" ? (val ? '%' + val + '%' : null) : null
             ,"p10": ParamType == "PMSBuilConfig" ? (val ? '%' + val + '%' : null) : null
             ,"p11": ParamType == "PMSBuilMakaniNo" ? (val ? '%' + val + '%' : null) : null
             ,"p12": ParamType == "PMSBuilDMNo" ? (val ? '%' + val + '%' : null) : null
             ,"p13": ParamType == "PMSBuilNoOfFlor" ? (val ? '%' + val + '%' : null) : null
             ,"p14": ParamType == "PMSBuilNoOfPark" ? (val ? '%' + val + '%' : null) : null
             ,"p15": ParamType == "PMSBuilNoOfUnit" ? (val ? '%' + val + '%' : null) : null
             ,"p16": ParamType == "PMSBuilBUPArea" ? (val ? '%' + val + '%' : null) : null
             ,"p17": ParamType == "PMSBuilLeasArea" ? (val ? '%' + val + '%' : null) : null
             ,"p18": null
             ,"p19": null
             ,"p20": null
             ,"p21": null
             ,"p22": null
             ,"p23": null
             ,"p24": null
             ,"p25": null
             ,"p26": null
             ,"p27": ParamType == "PMSBuilGraPeriInMons" ? (val ? '%' + val + '%' : null) : null
             ,"p28": null
             ,"p29": null
             ,"p30": null
             ,"p31": ParamType == "PMSBuilDescription" ? (val ? '%' + val + '%' : null) : null
             ,"p32": ParamType == "BuildingKey" ? (val ? '%' + val + '%' : null) : null
             ,"p33": null
             ,"p34": null
             ,"p35": null
             ,"p36": null
             ,"p37": null
             ,"p38": null
             ,"p39": null
             ,"p40": null
             ,"p41": null
             ,"p42": null
             ,"p43": null
             ,"p44": props.Dialogview ? "1" : null
             ,"p45": null
             ,"p46": null
             ,"p47": null
             ,"p48": null
             ,"p49": null
             ,"p50": null
             ,"p51": null
             ,"p52": null
             ,"p53": null
             ,"p54": null
             ,"p55": null
             ,"p56": null
             ,"p57": null
             ,"p58": null
             ,"p59": null
             ,"p60": null
             ,"p61": null
             ,"p62": null
             ,"p63": null
             ,"p64": null
             ,"p65": null
             ,"p66": null
             ,"p67": null
             ,"p68": null
             ,"p69": null
             ,"p70": null
             ,"p71": null
             ,"p72": null
             ,"p73": null
             ,"p74": null
             ,"p75": null
             ,"p76": null
             ,"p77": null
             ,"p78": null
             ,"p79": null
             ,"p80": null
             ,"p81": null
             ,"p82": null
             ,"p83": null
             ,"p84": null
             ,"p85": null
             ,"p86": null
             ,"p87": null
             ,"p88": null
             ,"p89": null
             ,"p90": null
             ,"p91": null
             ,"p92": null
             ,"p93": null
             ,"p94": null
             ,"p95": null
             ,"p96": null
             ,"p97": null
             ,"p98": null
             ,"p99": null
             ,"p100": null
             ,"p101": null
             ,"p102": null
             ,"p103": null
             ,"p104": null
             ,"p105": null
             ,"p106": null
             ,"p107": null
             ,"p108": null
             ,"p109": null
             ,"p110": index
             ,"p111": 10
             ,"p112": "PMSBuildingID"
             ,"p113": null
             ,"p114": null
             ,"p115": localStorage.getItem('UserGroupID')
             ,"p116": localStorage.getItem('userid')
   }
 }
   const clearAll = Object.keys(params.data).slice(0, Object.keys(params.data).length).reduce((acc, key,i) => {
       acc[key] = (i > Object.keys(params.data).length - 8) ? params.data[key] :  null ;
       return acc;
   }, {});
      const clearAllParams = {data:clearAll}
   setLoading(true);
   CommonAPISelect(url,(ParamType == 'ClearAll' ? clearAllParams : params),cstate.token[0])
            .then((res)=>{ 
                const result = res.Output.status.code;
                const data = res.Output.data;
                if(result == '200'){    
                  const length = data.length;
                   if (index == 1) {
                                                                        if(ParamType == 'PMSBuilCode'){
                                        setShowListPMSBuilCode( length > 0 ? true : false);
                                    }

                                    if(ParamType == 'PMSBuilName'){
                                        setShowListPMSBuilName( length > 0 ? true : false);
                                    }

                                    if(ParamType == 'PMSBuilNo'){
                                        setShowListPMSBuilNo( length > 0 ? true : false);
                                    }

                                    if(ParamType == 'PMSBuilCostGroup'){
                                        setShowListPMSBuilCostGroup( length > 0 ? true : false);
                                    }

                                    if(ParamType == 'BuildingKey'){
                                        setShowListBuildingKey( length > 0 ? true : false);
                                    }

                                    setData(data);
                   }else{
                                                                        if(ParamType == 'PMSBuilCode'){
                                           setShowListPMSBuilCode(true);
                                    }

                                    if(ParamType == 'PMSBuilName'){
                                           setShowListPMSBuilName(true);
                                    }

                                    if(ParamType == 'PMSBuilNo'){
                                           setShowListPMSBuilNo(true);
                                    }

                                    if(ParamType == 'PMSBuilCostGroup'){
                                           setShowListPMSBuilCostGroup(true);
                                    }

                                    if(ParamType == 'BuildingKey'){
                                           setShowListBuildingKey(true);
                                    }

                                    setData(Data.concat(data));
                   }
                                     setLoading(false);
                   }
    else{
           context.alert({open: true,color:'warning',message: [res.Output.status.message]});
           setLoading(false);
     }
   });
  }

        const storeDispatch = useCallback(async(e,name,fieldType) => {

                       if (fieldType == "text"){
                           dispatch({type:fieldType,name: name,value:e});

                       }else if (fieldType == "number"){
                           dispatch({type:fieldType,name: name,number:Number(e)});

                       }else if (fieldType == "boolean"){
                           dispatch({type:fieldType,name: name,boolean:e});

                       }else  if(fieldType == "date"){
                           dispatch({type:'text',name: name,value:e});

                       }else  if(fieldType == "select"){

                 if (name == "LocalityID"){
                        dispatch({type:'text',name: 'LocalityID',value: e.LocalityIDPK ? e.LocalityIDPK : null});
                        dispatch({type:'text',name: 'LocalityName',value:e.LocalityName ? e.LocalityName : null});
                           dispatch({type:'text',name: 'RegionID',value:e.RegionID ? e.RegionID : null});
                           dispatch({type:'text',name: 'RegionName',value:e.RegionName ? e.RegionName : null});
                           dispatch({type:'text',name: 'CountryID',value:e.CountryID ? e.CountryID : null});
                           dispatch({type:'text',name: 'CountryName',value:e.CountryName ? e.CountryName : null});

                 } else  if(name == "CountryID"){
                        dispatch({type:'text',name: 'CountryID',value: e.CountryIDPK ? e.CountryIDPK : null});
                        dispatch({type:'text',name: 'CountryName',value:e.CountryName ? e.CountryName : null});
                           dispatch({type:'text',name: 'LocalityID',value:e.LocalityID ? e.LocalityID : null});
                           dispatch({type:'text',name: 'LocalityName',value:e.LocalityName ? e.LocalityName : null});
                           dispatch({type:'text',name: 'RegionID',value:e.RegionID ? e.RegionID : null});
                           dispatch({type:'text',name: 'RegionName',value:e.RegionName ? e.RegionName : null});

                 } else  if(name == "RegionID"){
                        dispatch({type:'text',name: 'RegionID',value: e.RegionIDPK ? e.RegionIDPK : null});
                        dispatch({type:'text',name: 'RegionName',value:e.RegionName ? e.RegionName : null});
                           dispatch({type:'text',name: 'CountryID',value:e.CountryID ? e.CountryID : null});
                           dispatch({type:'text',name: 'CountryName',value:e.CountryName ? e.CountryName : null});
                           dispatch({type:'text',name: 'LocalityID',value:e.LocalityID ? e.LocalityID : null});
                           dispatch({type:'text',name: 'LocalityName',value:e.LocalityName ? e.LocalityName : null});

                 } else  if(name == "OrganisationID"){
                        dispatch({type:'text',name: 'OrganisationID',value: e.OrganisationIDPK ? e.OrganisationIDPK : null});
                        dispatch({type:'text',name: 'OrganisationName',value:e.OrganisationName ? e.OrganisationName : null});

                 } else  if(name == "AssBuildingTypeID"){
                        dispatch({type:'text',name: 'AssBuildingTypeID',value: e.AssBuildingTypeIDPK ? e.AssBuildingTypeIDPK : null});
                        dispatch({type:'text',name: 'AssBuildingTypeName',value:e.AssBuildingTypeName ? e.AssBuildingTypeName : null});

                 } else  if(name == "PMSBuildingComID"){
                        dispatch({type:'text',name: 'PMSBuildingComID',value: e.PMSBuildingComIDPK ? e.PMSBuildingComIDPK : null});
                        dispatch({type:'text',name: 'PMSBuildingComName',value:e.PMSBuildingComName ? e.PMSBuildingComName : null});

                 } else  if(name == "PMSLandLordID"){
                        dispatch({type:'text',name: 'PMSLandLordID',value: e.PMSLandLordIDPK ? e.PMSLandLordIDPK : null});
                        dispatch({type:'text',name: 'PMSLLdName',value:e.PMSLLdName ? e.PMSLLdName : null});

                 } else  if(name == "EmployeeID"){
                        dispatch({type:'text',name: 'EmployeeID',value: e.EmployeeIDPK ? e.EmployeeIDPK : null});
                        dispatch({type:'text',name: 'FirstName',value:e.FirstName ? e.FirstName : null});

                 } else  if(name == "EmployeeID1"){
                        dispatch({type:'text',name: 'EmployeeID1',value: e.EmployeeIDPK ? e.EmployeeIDPK : null});
                        dispatch({type:'text',name: 'FirstName1',value:e.FirstName ? e.FirstName : null});

                      }

                       }
                      }, [state]);

  function storeDispatch_HumanClear(type){

               if(type == "LocalityID"){
                        dispatch({type:'text',name: 'LocalityID',value: null});
                        dispatch({type:'text',name: 'LocalityName',value:""});

            if (document.getElementById("PMSBuildingRegistryLocalityNameClear")){
                       document.getElementById("PMSBuildingRegistryLocalityNameClear").click();
               }                           dispatch({type:'text',name: 'RegionID',value: null});
                           dispatch({type:'text',name: 'RegionName',value:""});

            if (document.getElementById("PMSBuildingRegistryRegionNameClear")){
                       document.getElementById("PMSBuildingRegistryRegionNameClear").click();
               }                           dispatch({type:'text',name: 'CountryID',value: null});
                           dispatch({type:'text',name: 'CountryName',value:""});

            if (document.getElementById("PMSBuildingRegistryCountryNameClear")){
                       document.getElementById("PMSBuildingRegistryCountryNameClear").click();
               }
               } else  if(type == "CountryID"){
                        dispatch({type:'text',name: 'CountryID',value: null});
                        dispatch({type:'text',name: 'CountryName',value:""});

            if (document.getElementById("PMSBuildingRegistryCountryNameClear")){
                       document.getElementById("PMSBuildingRegistryCountryNameClear").click();
               }                           dispatch({type:'text',name: 'LocalityID',value: null});
                           dispatch({type:'text',name: 'LocalityName',value:""});

            if (document.getElementById("PMSBuildingRegistryLocalityNameClear")){
                       document.getElementById("PMSBuildingRegistryLocalityNameClear").click();
               }                           dispatch({type:'text',name: 'RegionID',value: null});
                           dispatch({type:'text',name: 'RegionName',value:""});

            if (document.getElementById("PMSBuildingRegistryRegionNameClear")){
                       document.getElementById("PMSBuildingRegistryRegionNameClear").click();
               }
               } else  if(type == "RegionID"){
                        dispatch({type:'text',name: 'RegionID',value: null});
                        dispatch({type:'text',name: 'RegionName',value:""});

            if (document.getElementById("PMSBuildingRegistryRegionNameClear")){
                       document.getElementById("PMSBuildingRegistryRegionNameClear").click();
               }                           dispatch({type:'text',name: 'CountryID',value: null});
                           dispatch({type:'text',name: 'CountryName',value:""});

            if (document.getElementById("PMSBuildingRegistryCountryNameClear")){
                       document.getElementById("PMSBuildingRegistryCountryNameClear").click();
               }                           dispatch({type:'text',name: 'LocalityID',value: null});
                           dispatch({type:'text',name: 'LocalityName',value:""});

            if (document.getElementById("PMSBuildingRegistryLocalityNameClear")){
                       document.getElementById("PMSBuildingRegistryLocalityNameClear").click();
               }
               } else  if(type == "OrganisationID"){
                        dispatch({type:'text',name: 'OrganisationID',value: null});
                        dispatch({type:'text',name: 'OrganisationName',value:""});

            if (document.getElementById("PMSBuildingRegistryOrganisationNameClear")){
                       document.getElementById("PMSBuildingRegistryOrganisationNameClear").click();
               }
               } else  if(type == "AssBuildingTypeID"){
                        dispatch({type:'text',name: 'AssBuildingTypeID',value: null});
                        dispatch({type:'text',name: 'AssBuildingTypeName',value:""});

            if (document.getElementById("PMSBuildingRegistryAssBuildingTypeNameClear")){
                       document.getElementById("PMSBuildingRegistryAssBuildingTypeNameClear").click();
               }
               } else  if(type == "PMSBuildingComID"){
                        dispatch({type:'text',name: 'PMSBuildingComID',value: null});
                        dispatch({type:'text',name: 'PMSBuildingComName',value:""});

            if (document.getElementById("PMSBuildingRegistryPMSBuildingComNameClear")){
                       document.getElementById("PMSBuildingRegistryPMSBuildingComNameClear").click();
               }
               } else  if(type == "PMSLandLordID"){
                        dispatch({type:'text',name: 'PMSLandLordID',value: null});
                        dispatch({type:'text',name: 'PMSLLdName',value:""});

            if (document.getElementById("PMSBuildingRegistryPMSLLdNameClear")){
                       document.getElementById("PMSBuildingRegistryPMSLLdNameClear").click();
               }
               } else  if(type == "EmployeeID"){
                        dispatch({type:'text',name: 'EmployeeID',value: null});
                        dispatch({type:'text',name: 'FirstName',value:""});

            if (document.getElementById("PMSBuildingRegistryFirstNameClear")){
                       document.getElementById("PMSBuildingRegistryFirstNameClear").click();
               }
               } else  if(type == "EmployeeID1"){
                        dispatch({type:'text',name: 'EmployeeID1',value: null});
                        dispatch({type:'text',name: 'FirstName1',value:""});

            if (document.getElementById("PMSBuildingRegistryFirstName1Clear")){
                       document.getElementById("PMSBuildingRegistryFirstName1Clear").click();
               }
   }
 }

  function storeDispatch_BackspaceClear(type){

               if(type == "LocalityID"){
                        dispatch({type:'text',name: 'LocalityID',value: null});
                           dispatch({type:'text',name: 'RegionID',value: null});
                           dispatch({type:'text',name: 'CountryID',value: null});

               } else  if(type == "CountryID"){
                        dispatch({type:'text',name: 'CountryID',value: null});
                           dispatch({type:'text',name: 'LocalityID',value: null});
                           dispatch({type:'text',name: 'RegionID',value: null});

               } else  if(type == "RegionID"){
                        dispatch({type:'text',name: 'RegionID',value: null});
                           dispatch({type:'text',name: 'CountryID',value: null});
                           dispatch({type:'text',name: 'LocalityID',value: null});

               } else  if(type == "OrganisationID"){
                        dispatch({type:'text',name: 'OrganisationID',value: null});

               } else  if(type == "AssBuildingTypeID"){
                        dispatch({type:'text',name: 'AssBuildingTypeID',value: null});

               } else  if(type == "PMSBuildingComID"){
                        dispatch({type:'text',name: 'PMSBuildingComID',value: null});

               } else  if(type == "PMSLandLordID"){
                        dispatch({type:'text',name: 'PMSLandLordID',value: null});

               } else  if(type == "EmployeeID"){
                        dispatch({type:'text',name: 'EmployeeID',value: null});

               } else  if(type == "EmployeeID1"){
                        dispatch({type:'text',name: 'EmployeeID1',value: null});

   }
 }

 const dateFormat = (val) => {
    if(val){
       return format(new Date(val), 'dd-MM-yyyy HH:mm' );
    }else{
        return val;
    }
}

const updateAlert = (e) =>{
context.ConfirmAlert(
    <SweetAlert
        Size = "sm"
        style={{ display: "block", marginTop: "100px" }} 
        tilte =""
        onConfirm={() => SetAllValues(e)}
        onCancel={() => context.ConfirmAlert(null)}
        confirmBtnCssClass = 'swalokbtn'
        cancelBtnCssClass = 'swalcancelbtn'
        confirmBtnText = {t("Yes")}
        cancelBtnText = {t("No")}
        showCancel
        >
        {t("Do you want to update this record?")}
    </SweetAlert>
);
}

 function SetAllValues(e){
       context.ConfirmAlert(null);
       setIsDraft(e.IsDraft)
       cdispatch({ type:'editData',payload:[e]})
       cdispatch({type:'PrimaryId',payload:e.PMSBuildingIDPK});
       setPrimID(Number(e.PMSBuildingIDPK));

                           dispatch({type:'text',name: 'PMSBuilCode',value:e.PMSBuilCode});
                           dispatch({type:'text',name: 'PMSBuilName',value:e.PMSBuilName});
                           dispatch({type:'text',name: 'PMSBuilNo',value:e.PMSBuilNo});
                           dispatch({type:'number',name: 'PMSBuilArInSqFet',number:Number(e.PMSBuilArInSqFet)});
                           dispatch({type:'number',name: 'LocalityID',number:Number(e.LocalityID)});
                           dispatch({type:'text',name: 'LocalityName',value:e.LocalityName});
                           dispatch({type:'number',name: 'CountryID',number:Number(e.CountryID)});
                           dispatch({type:'text',name: 'CountryName',value:e.CountryName});
                           dispatch({type:'number',name: 'RegionID',number:Number(e.RegionID)});
                           dispatch({type:'text',name: 'RegionName',value:e.RegionName});
                           dispatch({type:'number',name: 'PMSBuilLatitude',number:Number(e.PMSBuilLatitude)});
                           dispatch({type:'number',name: 'PMSBuilLongitude',number:Number(e.PMSBuilLongitude)});
                           dispatch({type:'number',name: 'OrganisationID',number:Number(e.OrganisationID)});
                           dispatch({type:'text',name: 'OrganisationName',value:e.OrganisationName});
                           dispatch({type:'number',name: 'AssBuildingTypeID',number:Number(e.AssBuildingTypeID)});
                           dispatch({type:'text',name: 'AssBuildingTypeName',value:e.AssBuildingTypeName});
                           dispatch({type:'number',name: 'PMSBuildingComID',number:Number(e.PMSBuildingComID)});
                           dispatch({type:'text',name: 'PMSBuildingComName',value:e.PMSBuildingComName});
                           dispatch({type:'number',name: 'PMSLandLordID',number:Number(e.PMSLandLordID)});
                           dispatch({type:'text',name: 'PMSLLdName',value:e.PMSLLdName});
                           dispatch({type:'text',name: 'PMSBuilCostGroup',value:e.PMSBuilCostGroup});
                           dispatch({type:'text',name: 'PMSBuilPermitNo',value:e.PMSBuilPermitNo});
                           dispatch({type:'number',name: 'EmployeeID',number:Number(e.EmployeeID)});
                           dispatch({type:'text',name: 'FirstName',value:e.FirstName});
                           dispatch({type:'number',name: 'EmployeeID1',number:Number(e.EmployeeID1)});
                           dispatch({type:'text',name: 'FirstName1',value:e.FirstName1});
                           dispatch({type:'text',name: 'PMSBuilConfig',value:e.PMSBuilConfig});
                           dispatch({type:'text',name: 'PMSBuilMakaniNo',value:e.PMSBuilMakaniNo});
                           dispatch({type:'text',name: 'PMSBuilDMNo',value:e.PMSBuilDMNo});
                           dispatch({type:'number',name: 'PMSBuilNoOfFlor',number:Number(e.PMSBuilNoOfFlor)});
                           dispatch({type:'number',name: 'PMSBuilNoOfPark',number:Number(e.PMSBuilNoOfPark)});
                           dispatch({type:'number',name: 'PMSBuilNoOfUnit',number:Number(e.PMSBuilNoOfUnit)});
                           dispatch({type:'number',name: 'PMSBuilBUPArea',number:Number(e.PMSBuilBUPArea)});
                           dispatch({type:'number',name: 'PMSBuilLeasArea',number:Number(e.PMSBuilLeasArea)});
                           dispatch({type:'text',name: 'PMSBuilConsDateTime',value:convertDateTimeDigitIn(e.PMSBuilConsDateTime)});
                           dispatch({type:'text',name: 'PMSBuilHODateTime',value:convertDateTimeDigitIn(e.PMSBuilHODateTime)});
                           dispatch({type:'text',name: 'PMSBuilTenanDateTime',value:convertDateTimeDigitIn(e.PMSBuilTenanDateTime)});
                           dispatch({type:'text',name: 'PMSBuilLeasDateTime',value:convertDateTimeDigitIn(e.PMSBuilLeasDateTime)});
                           dispatch({type:'number',name: 'PMSBuilGraPeriInMons',number:Number(e.PMSBuilGraPeriInMons)});
                           dispatch({type:'text',name: 'PMSBuilDescription',value:e.PMSBuilDescription});
                           dispatch({type:'text',name: 'BuildingKey',value:e.BuildingKey});
 }


        const trimFunc = (v) => {
         if(typeof v === 'string'){
                   return v.trim()
          }else{
                   return v
          }
          }



//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

return (
                    <div style={{width:'100%',display:'none'}}  id="PMSBuildingRegistry-MainEntry">
                            <div className="tabcontainer padleft5">
                               <div className="formcontent">
                                       <div className='mar0'>
                                            <div className='ascardpad'>
                                         {ShowView ?
                                          <div>
                                                   <ViewComponent ExpandDetailValue={true} EntryExp={cstate.expandDetail} inboxdata = {{}}
                                            />
                                      </div>
               :
                       <div className="displayFlex width100">
                       <div id ="divPMSBuildingRegistry-Entry" style={{width:'100%',position:'relative'}}>
                       <Accordion  expanded={cstate.expandDetail == 'mainpanel'}  >
                           <AccordionSummary aria-controls = "panel1bh-content"
                                   id = "panel1bh-header" >
                                      <div className="displayFlex backgroundLightL3 borderRadiusTop width100">
                                           <div className="displayFlex EntryHeader">
                                           <div id ='fld1394L4ECdFlexEntryHeader' onClick={()=>{context.ShowTableDiv(false);
                                                       document.getElementById('overlayimgAttPMSBuildingRegistry').style.display='none';}}>
                                           <MdOutlineArrowBackIosNew className='BackBtnIcon'/>
                                               </div>
                                                   <p className="ListP" title='8.0.0.46-12:46:59-21-3'>
                                                       {PrimID ? "Edit " : "New "}{tf('1394')}
                                                   </p>

                                                       </div>

                                               <div className="displayFlex EntryHeaderBtn">
                                                 <div className="GridAlign">
                                                  <div className='Entry-Checkbox' style={{ minWidth: "70px" }}>
                                                      {cstate.expandDetail === 'mainpanel' &&
                                                      <FormGroup row>
                                                      <FormControlLabel
                                                       labelPlacement="bottom"
                                                       id='fld1394L4ECEntryCheckbox'
                                                      control={
                                                      <ToggleSwitch 
                                                      checked={active == "1" ? true : false}
                                                      onChange={(event)=> setActive(event.target.checked)}
                                                      />
                                                      }
                                                      label={t(active == true ? "Active" : "In Active")}
                                                      />
                                                      </FormGroup>}
                                                   </div>
                                                </div>
                                   {!PrimID && !props.createEasy && cstate.AccessRights.IsAdd && (DefaultPrimaryId ||DefaultPrimaryId == 'NORECORDS') ? 
                                               <div className="GridAlignDefault"
                                               onClick={() => {saveSubmit('SetDefaultPMSBuildingID')}}
                                               id='fld1394L4ECSetDefaultBtnIsAdd'>
                                               <div className='Entry-Checkbox' >
                                                       <BsFileEarmarkCode className="Iconstyles" />
                                               </div>
                                               <div className="GridLabel">
                                                   <p>{t('SetDefault')}</p>
                                               </div>
                                           </div> 
                                   :
                                   !PrimID && !props.createEasy &&
                                           <div className="GridAlignDefault"
                                               onClick={() => {PMSBuildingRegistry_Select (1,null,'SetDefaultPMSBuildingID' ,cstate.token[0]);}}
                                               id='fld1394L4ECSetDefaultBtnIsAdd'>
                                               <div className='Entry-Checkbox' >
                                                       <BsFileEarmarkCode className="Iconstyles" />
                                               </div>
                                               <div className="GridLabel">
                                                   <p>{t('GetDefault')}</p>
                                               </div>
                                           </div>
                                    }
                                    {(PrimID && (cstate.expandDetail === 'mainpanel')) ?
                                       <div className="GridAlign"
                                        onClick={() => { context.AttachExpand(true) }} 
                                        id="fld1394L4ECIconButton">
                                        <div className='Entry-Checkbox'>
                                        <div
                                        disableRipple = {true}
                                         disabled={PrimID ? false : true}
                                        >
                                           <GrAttachment className="Iconstyles" />
                                        </div>
                                        </div>
                                        <div className="GridLabel">
                                        <p>{t('Attach')}</p>
                                        </div>
                                        </div>
                                        : null}
                                            {!PrimID &&
                                    <div
                                     className="GridAlign"
                                    disabled = {false}
                                     onClick={() => { clear(); }}
                                     id="fld1394L4ECClearBtn">
                                    <div className='Entry-Checkbox'>
                                    <GrPowerReset className="Iconstyles" />
                                    </div>
                                    <div className="GridLabel">
                                    <p>{t('Reset')}</p>
                                    </div>
                                    </div>
                                    }
                                    {!PrimID ? 
                                    <div
                                    className = 'GridAlign'
                                    onClick={() => { DraftSave() }}
                                    id = "fld1394L4ECDraftBtn"
                                     disabled={false}>
                                    <div className='Entry-Checkbox'>
                                           <RiFileEditLine className='Iconstyles' />
                                    </div>
                                    <div className='GridLabel'>
                                       <p>{t('Draft')}</p>
                                    </div>
                                    </div>
                                    : null}

                                    {cstate.expandDetail === 'mainpanel' &&
                                    <SaveBtn  
                                    name= {PrimID? "Update" : "Save"}
                                    disabled = {false}
                                    frmctrlid='fld1394L4ECSaveBtnIsAdd'
                                    onClick={() => {submitConfirmation()}}
                                    />}
                                    {PrimID && (cstate.expandDetail === 'mainpanel') ?
                                    <CloseBtn disabled ={false} className='L1AddBtnCommon'
                                       frmctrlid='fld1394L4ECCloseBtn'
                                       onClick ={() => {context.ShowTableDiv(false);clear();setShowView(true);setPrimaryViewShow(true);document.getElementById('overlayimgAttPMSBuildingRegistry').style.display='none';}}
                                    />  
                                    : null}

                                    </div> 
                                    </div> 
                                       </AccordionSummary>
                                                <AccordionDetails >
                                    <div id="PMSBuildingRegistry-Main" className="width100 displayFlex componentMainDiv cardDiv"> 
                                    <div id ="PMSBuildingRegistry-Detail" className="detailCard detailDiv" >
                                    <div id="PMSBuildingRegistry-MainBody" className="padding paddingLeft">
                                    <div className="display-inline-flex">

           <div className={"l4-side-component displayFlex"+(isSideMenu? '':"l4width")}>

       <div className ="l4-side-component">


<div className={"cardl4 "+((openedMenu == "Building Registry" || openedMenu == '')? '':'')}>
        <div color="info" className='cardheadvh'>
                <GridContainer >
                    <GridItem xs={3} md={3} lg={3} sm={3}> 
                        <div className="GrpViewHeadingTitle">
                            <p>Building Registry</p>
                        </div>
                    </GridItem>
                </GridContainer>
        </div>
         <div style={{padding: '15px'}}> 
              <GridContainer spacing={2}>
           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2DropDown
                           //id = {state.PMSBuilCode}
                           data-testid={state.PMSBuilCode}
                           json={json}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilCode"
                           tfLabel={tf("PMSBuilCode")}
                           EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                           onSelect={(e) => !props.createEasy && updateAlert(e)}
                           onClick={()=>{ if(ShowListPMSBuilCode){PMSBuildingRegistry_SelectText(1,'','ClearAll')} setShowListPMSBuilCode(true);} }
                           frmctrlid="fld1394_36548"
                           frmctrlidName="PMSBuilCode"
                           fieldorder = "1"
                           data={Data}
                           foreign = {false}
                           foreignFld={[]}
                           foreignClick={() => {}}
                           totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                           onChange={(i,e)=>{if(ShowListPMSBuilCode){PMSBuildingRegistry_SelectText(i,e,"PMSBuilCode");}storeDispatch(e,"PMSBuilCode","text")}}
                           onKeyDown={e => {if(e.keyCode == "8"|| e.keyCode == "46"){setShowListPMSBuilCode(true);}}}
                           showList = {ShowListPMSBuilCode}
                           SideEntryView = {false}
                           KeyBack={e=>{}} 




                           value={state.PMSBuilCode}
                           loading = {loading}
                           clear={(e) => { if(e){ 
                           dispatch({type:'text',name: "PMSBuilCode",value:""});
                           setShowListPMSBuilCode(true);
                           }
                           }}
                       />
                   </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2DropDown
                           //id = {state.PMSBuilName}
                           data-testid={state.PMSBuilName}
                           json={json}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilName"
                           tfLabel={tf("PMSBuilName")}
                           EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                           onSelect={(e) => !props.createEasy && updateAlert(e)}
                           onClick={()=>{ if(ShowListPMSBuilName){PMSBuildingRegistry_SelectText(1,'','ClearAll')} setShowListPMSBuilName(true);} }
                           frmctrlid="fld1394_36549"
                           frmctrlidName="PMSBuilName"
                           fieldorder = "2"
                           data={Data}
                           foreign = {false}
                           foreignFld={[]}
                           foreignClick={() => {}}
                           totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                           onChange={(i,e)=>{if(ShowListPMSBuilName){PMSBuildingRegistry_SelectText(i,e,"PMSBuilName");}storeDispatch(e,"PMSBuilName","text")}}
                           onKeyDown={e => {if(e.keyCode == "8"|| e.keyCode == "46"){setShowListPMSBuilName(true);}}}
                           showList = {ShowListPMSBuilName}
                           SideEntryView = {false}
                           KeyBack={e=>{}} 




                           value={state.PMSBuilName}
                           loading = {loading}
                           clear={(e) => { if(e){ 
                           dispatch({type:'text',name: "PMSBuilName",value:""});
                           setShowListPMSBuilName(true);
                           }
                           }}
                       />
                   </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2DropDown
                           //id = {state.PMSBuilNo}
                           data-testid={state.PMSBuilNo}
                           json={json}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilNo"
                           tfLabel={tf("PMSBuilNo")}
                           EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                           onSelect={(e) => !props.createEasy && updateAlert(e)}
                           onClick={()=>{ if(ShowListPMSBuilNo){PMSBuildingRegistry_SelectText(1,'','ClearAll')} setShowListPMSBuilNo(true);} }
                           frmctrlid="fld1394_36550"
                           frmctrlidName="PMSBuilNo"
                           fieldorder = "3"
                           data={Data}
                           foreign = {false}
                           foreignFld={[]}
                           foreignClick={() => {}}
                           totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                           onChange={(i,e)=>{if(ShowListPMSBuilNo){PMSBuildingRegistry_SelectText(i,e,"PMSBuilNo");}storeDispatch(e,"PMSBuilNo","text")}}
                           onKeyDown={e => {if(e.keyCode == "8"|| e.keyCode == "46"){setShowListPMSBuilNo(true);}}}
                           showList = {ShowListPMSBuilNo}
                           SideEntryView = {false}
                           KeyBack={e=>{}} 




                           value={state.PMSBuilNo}
                           loading = {loading}
                           clear={(e) => { if(e){ 
                           dispatch({type:'text',name: "PMSBuilNo",value:""});
                           setShowListPMSBuilNo(true);
                           }
                           }}
                       />
                   </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilArInSqFet}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilArInSqFet"
                           tfLabel={tf("PMSBuilArInSqFet")}
                           frmctrlid="fld1394_36551"
                           fieldorder = "4"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilArInSqFet",'number')}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'number',name: "PMSBuilArInSqFet",number:0});}}
                           }

                           value={state.PMSBuilArInSqFet}
                  />
               </GridItem>

       <GridItem xs={3} md={3} lg={3} sm={3}>   


                     <L2DropDown
                     json={json} 
                     id = {state.LocalityID}
                     data-testid={state.LocalityID}
                     value={state.LocalityName}





                     SPName = "PMSBuildingRegistry"
                     FieldName = "LocalityID"
                     tfLabel={tf("LocalityID")}
                     EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                     SideEntryView = {false}
                     onSelect={(e) => storeDispatch(e,"LocalityID","select")}
                     onChange={(i,e)=>{PMSBuildingRegistry_Select(i,e,"LocalityIDPK")}}
                     KeyBack={e => {storeDispatch_BackspaceClear("LocalityID",e)}}
                     fieldorder = "1"
                     data={Data}
                     foreign = {false}
                     foreignFld={[]}
                     foreignClick={() => {}}
                     totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                     openSlide={() => {OpenSlideComponent("12")}}
                     Tabledialog = {()=> OpenDialogComponent("12",'LocalityID')}
                     loading={loading}
                     clear={(e) => { if(e){ 
                     storeDispatch_HumanClear("LocalityID")
                       }
                     }}
           />

  </GridItem>

       <GridItem xs={3} md={3} lg={3} sm={3}>   


                     <L2DropDown
                     json={json} 
                     id = {state.CountryID}
                     data-testid={state.CountryID}
                     value={state.CountryName}





                     SPName = "PMSBuildingRegistry"
                     FieldName = "CountryID"
                     tfLabel={tf("CountryID")}
                     EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                     SideEntryView = {false}
                     onSelect={(e) => storeDispatch(e,"CountryID","select")}
                     onChange={(i,e)=>{PMSBuildingRegistry_Select(i,e,"CountryIDPK")}}
                     KeyBack={e => {storeDispatch_BackspaceClear("CountryID",e)}}
                     fieldorder = "2"
                     data={Data}
                     foreign = {false}
                     foreignFld={[]}
                     foreignClick={() => {}}
                     totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                     openSlide={() => {OpenSlideComponent("4")}}
                     Tabledialog = {()=> OpenDialogComponent("4",'CountryID')}
                     loading={loading}
                     clear={(e) => { if(e){ 
                     storeDispatch_HumanClear("CountryID")
                       }
                     }}
           />

  </GridItem>

       <GridItem xs={3} md={3} lg={3} sm={3}>   


                     <L2DropDown
                     json={json} 
                     id = {state.RegionID}
                     data-testid={state.RegionID}
                     value={state.RegionName}





                     SPName = "PMSBuildingRegistry"
                     FieldName = "RegionID"
                     tfLabel={tf("RegionID")}
                     EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                     SideEntryView = {false}
                     onSelect={(e) => storeDispatch(e,"RegionID","select")}
                     onChange={(i,e)=>{PMSBuildingRegistry_Select(i,e,"RegionIDPK")}}
                     KeyBack={e => {storeDispatch_BackspaceClear("RegionID",e)}}
                     fieldorder = "3"
                     data={Data}
                     foreign = {false}
                     foreignFld={[]}
                     foreignClick={() => {}}
                     totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                     openSlide={() => {OpenSlideComponent("16")}}
                     Tabledialog = {()=> OpenDialogComponent("16",'RegionID')}
                     loading={loading}
                     clear={(e) => { if(e){ 
                     storeDispatch_HumanClear("RegionID")
                       }
                     }}
           />

  </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilLatitude}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilLatitude"
                           tfLabel={tf("PMSBuilLatitude")}
                           frmctrlid="fld1394_36552"
                           fieldorder = "4"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilLatitude",'number')}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'number',name: "PMSBuilLatitude",number:0});}}
                           }

                           value={state.PMSBuilLatitude}
                  />
               </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilLongitude}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilLongitude"
                           tfLabel={tf("PMSBuilLongitude")}
                           frmctrlid="fld1394_36553"
                           fieldorder = "1"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilLongitude",'number')}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'number',name: "PMSBuilLongitude",number:0});}}
                           }

                           value={state.PMSBuilLongitude}
                  />
               </GridItem>

       <GridItem xs={3} md={3} lg={3} sm={3}>   


                     <L2DropDown
                     json={json} 
                     id = {state.OrganisationID}
                     data-testid={state.OrganisationID}
                     value={state.OrganisationName}





                     SPName = "PMSBuildingRegistry"
                     FieldName = "OrganisationID"
                     tfLabel={tf("OrganisationID")}
                     EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                     SideEntryView = {false}
                     onSelect={(e) => storeDispatch(e,"OrganisationID","select")}
                     onChange={(i,e)=>{PMSBuildingRegistry_Select(i,e,"OrganisationIDPK")}}
                     KeyBack={e => {storeDispatch_BackspaceClear("OrganisationID",e)}}
                     fieldorder = "2"
                     data={Data}
                     foreign = {false}
                     foreignFld={[]}
                     foreignClick={() => {}}
                     totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                     openSlide={() => {OpenSlideComponent("14")}}
                     Tabledialog = {()=> OpenDialogComponent("14",'OrganisationID')}
                     loading={loading}
                     clear={(e) => { if(e){ 
                     storeDispatch_HumanClear("OrganisationID")
                       }
                     }}
           />

  </GridItem>

       <GridItem xs={3} md={3} lg={3} sm={3}>   


                     <L2DropDown
                     json={json} 
                     id = {state.AssBuildingTypeID}
                     data-testid={state.AssBuildingTypeID}
                     value={state.AssBuildingTypeName}





                     SPName = "PMSBuildingRegistry"
                     FieldName = "AssBuildingTypeID"
                     tfLabel={tf("AssBuildingTypeID")}
                     EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                     SideEntryView = {false}
                     onSelect={(e) => storeDispatch(e,"AssBuildingTypeID","select")}
                     onChange={(i,e)=>{PMSBuildingRegistry_Select(i,e,"AssBuildingTypeIDPK")}}
                     KeyBack={e => {storeDispatch_BackspaceClear("AssBuildingTypeID",e)}}
                     fieldorder = "3"
                     data={Data}
                     foreign = {false}
                     foreignFld={[]}
                     foreignClick={() => {}}
                     totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                     openSlide={() => {OpenSlideComponent("956")}}
                     Tabledialog = {()=> OpenDialogComponent("956",'AssBuildingTypeID')}
                     loading={loading}
                     clear={(e) => { if(e){ 
                     storeDispatch_HumanClear("AssBuildingTypeID")
                       }
                     }}
           />

  </GridItem>

       <GridItem xs={3} md={3} lg={3} sm={3}>   


                     <L2DropDown
                     json={json} 
                     id = {state.PMSBuildingComID}
                     data-testid={state.PMSBuildingComID}
                     value={state.PMSBuildingComName}





                     SPName = "PMSBuildingRegistry"
                     FieldName = "PMSBuildingComID"
                     tfLabel={tf("PMSBuildingComID")}
                     EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                     SideEntryView = {false}
                     onSelect={(e) => storeDispatch(e,"PMSBuildingComID","select")}
                     onChange={(i,e)=>{PMSBuildingRegistry_Select(i,e,"PMSBuildingComIDPK")}}
                     KeyBack={e => {storeDispatch_BackspaceClear("PMSBuildingComID",e)}}
                     fieldorder = "4"
                     data={Data}
                     foreign = {false}
                     foreignFld={[]}
                     foreignClick={() => {}}
                     totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                     openSlide={() => {OpenSlideComponent("1383")}}
                     Tabledialog = {()=> OpenDialogComponent("1383",'PMSBuildingComID')}
                     loading={loading}
                     clear={(e) => { if(e){ 
                     storeDispatch_HumanClear("PMSBuildingComID")
                       }
                     }}
           />

  </GridItem>

       <GridItem xs={3} md={3} lg={3} sm={3}>   


                     <L2DropDown
                     json={json} 
                     id = {state.PMSLandLordID}
                     data-testid={state.PMSLandLordID}
                     value={state.PMSLLdName}





                     SPName = "PMSBuildingRegistry"
                     FieldName = "PMSLandLordID"
                     tfLabel={tf("PMSLandLordID")}
                     EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                     SideEntryView = {false}
                     onSelect={(e) => storeDispatch(e,"PMSLandLordID","select")}
                     onChange={(i,e)=>{PMSBuildingRegistry_Select(i,e,"PMSLandLordIDPK")}}
                     KeyBack={e => {storeDispatch_BackspaceClear("PMSLandLordID",e)}}
                     fieldorder = "1"
                     data={Data}
                     foreign = {false}
                     foreignFld={[]}
                     foreignClick={() => {}}
                     totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                     openSlide={() => {OpenSlideComponent("1392")}}
                     Tabledialog = {()=> OpenDialogComponent("1392",'PMSLandLordID')}
                     loading={loading}
                     clear={(e) => { if(e){ 
                     storeDispatch_HumanClear("PMSLandLordID")
                       }
                     }}
           />

  </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2DropDown
                           //id = {state.PMSBuilCostGroup}
                           data-testid={state.PMSBuilCostGroup}
                           json={json}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilCostGroup"
                           tfLabel={tf("PMSBuilCostGroup")}
                           EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                           onSelect={(e) => !props.createEasy && updateAlert(e)}
                           onClick={()=>{ if(ShowListPMSBuilCostGroup){PMSBuildingRegistry_SelectText(1,'','ClearAll')} setShowListPMSBuilCostGroup(true);} }
                           frmctrlid="fld1394_36554"
                           frmctrlidName="PMSBuilCostGroup"
                           fieldorder = "2"
                           data={Data}
                           foreign = {false}
                           foreignFld={[]}
                           foreignClick={() => {}}
                           totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                           onChange={(i,e)=>{if(ShowListPMSBuilCostGroup){PMSBuildingRegistry_SelectText(i,e,"PMSBuilCostGroup");}storeDispatch(e,"PMSBuilCostGroup","text")}}
                           onKeyDown={e => {if(e.keyCode == "8"|| e.keyCode == "46"){setShowListPMSBuilCostGroup(true);}}}
                           showList = {ShowListPMSBuilCostGroup}
                           SideEntryView = {false}
                           KeyBack={e=>{}} 




                           value={state.PMSBuilCostGroup}
                           loading = {loading}
                           clear={(e) => { if(e){ 
                           dispatch({type:'text',name: "PMSBuilCostGroup",value:""});
                           setShowListPMSBuilCostGroup(true);
                           }
                           }}
                       />
                   </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilPermitNo}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilPermitNo"
                           tfLabel={tf("PMSBuilPermitNo")}
                           frmctrlid="fld1394_36555"
                           fieldorder = "3"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilPermitNo","text")}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'text',name: "PMSBuilPermitNo",value:""});}}
                           }

                           value={state.PMSBuilPermitNo}
                  />
               </GridItem>

       <GridItem xs={3} md={3} lg={3} sm={3}>   


                     <L2DropDown
                     json={json} 
                     id = {state.EmployeeID}
                     data-testid={state.EmployeeID}
                     value={state.FirstName}





                     SPName = "PMSBuildingRegistry"
                     FieldName = "EmployeeID"
                     tfLabel={tf("EmployeeID")}
                     EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                     SideEntryView = {false}
                     onSelect={(e) => storeDispatch(e,"EmployeeID","select")}
                     onChange={(i,e)=>{PMSBuildingRegistry_Select(i,e,"EmployeeIDPK")}}
                     KeyBack={e => {storeDispatch_BackspaceClear("EmployeeID",e)}}
                     fieldorder = "4"
                     data={Data}
                     foreign = {false}
                     foreignFld={[]}
                     foreignClick={() => {}}
                     totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                     openSlide={() => {OpenSlideComponent("197")}}
                     Tabledialog = {()=> OpenDialogComponent("197",'EmployeeID')}
                     loading={loading}
                     clear={(e) => { if(e){ 
                     storeDispatch_HumanClear("EmployeeID")
                       }
                     }}
           />

  </GridItem>

       <GridItem xs={3} md={3} lg={3} sm={3}>   


                     <L2DropDown
                     json={json} 
                     id = {state.EmployeeID1}
                     data-testid={state.EmployeeID1}
                     value={state.FirstName1}





                     SPName = "PMSBuildingRegistry"
                     FieldName = "EmployeeID1"
                     tfLabel={tf("EmployeeID1")}
                     EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                     SideEntryView = {false}
                     onSelect={(e) => storeDispatch(e,"EmployeeID1","select")}
                     onChange={(i,e)=>{PMSBuildingRegistry_Select(i,e,"EmployeeID1PK")}}
                     KeyBack={e => {storeDispatch_BackspaceClear("EmployeeID1",e)}}
                     fieldorder = "1"
                     data={Data}
                     foreign = {false}
                     foreignFld={[]}
                     foreignClick={() => {}}
                     totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                     openSlide={() => {OpenSlideComponent("197")}}
                     Tabledialog = {()=> OpenDialogComponent("197",'EmployeeID1')}
                     loading={loading}
                     clear={(e) => { if(e){ 
                     storeDispatch_HumanClear("EmployeeID1")
                       }
                     }}
           />

  </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilConfig}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilConfig"
                           tfLabel={tf("PMSBuilConfig")}
                           frmctrlid="fld1394_36556"
                           fieldorder = "2"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilConfig","text")}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'text',name: "PMSBuilConfig",value:""});}}
                           }

                           value={state.PMSBuilConfig}
                  />
               </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilMakaniNo}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilMakaniNo"
                           tfLabel={tf("PMSBuilMakaniNo")}
                           frmctrlid="fld1394_36557"
                           fieldorder = "3"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilMakaniNo","text")}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'text',name: "PMSBuilMakaniNo",value:""});}}
                           }

                           value={state.PMSBuilMakaniNo}
                  />
               </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilDMNo}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilDMNo"
                           tfLabel={tf("PMSBuilDMNo")}
                           frmctrlid="fld1394_36558"
                           fieldorder = "4"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilDMNo","text")}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'text',name: "PMSBuilDMNo",value:""});}}
                           }

                           value={state.PMSBuilDMNo}
                  />
               </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilNoOfFlor}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilNoOfFlor"
                           tfLabel={tf("PMSBuilNoOfFlor")}
                           frmctrlid="fld1394_36559"
                           fieldorder = "1"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilNoOfFlor",'number')}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'number',name: "PMSBuilNoOfFlor",number:0});}}
                           }

                           value={state.PMSBuilNoOfFlor}
                  />
               </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilNoOfPark}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilNoOfPark"
                           tfLabel={tf("PMSBuilNoOfPark")}
                           frmctrlid="fld1394_36560"
                           fieldorder = "2"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilNoOfPark",'number')}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'number',name: "PMSBuilNoOfPark",number:0});}}
                           }

                           value={state.PMSBuilNoOfPark}
                  />
               </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilNoOfUnit}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilNoOfUnit"
                           tfLabel={tf("PMSBuilNoOfUnit")}
                           frmctrlid="fld1394_36561"
                           fieldorder = "3"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilNoOfUnit",'number')}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'number',name: "PMSBuilNoOfUnit",number:0});}}
                           }

                           value={state.PMSBuilNoOfUnit}
                  />
               </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilBUPArea}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilBUPArea"
                           tfLabel={tf("PMSBuilBUPArea")}
                           frmctrlid="fld1394_36562"
                           fieldorder = "4"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilBUPArea",'number')}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'number',name: "PMSBuilBUPArea",number:0});}}
                           }

                           value={state.PMSBuilBUPArea}
                  />
               </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilLeasArea}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilLeasArea"
                           tfLabel={tf("PMSBuilLeasArea")}
                           frmctrlid="fld1394_36563"
                           fieldorder = "1"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilLeasArea",'number')}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'number',name: "PMSBuilLeasArea",number:0});}}
                           }

                           value={state.PMSBuilLeasArea}
                  />
               </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3} className='flexEnd'>   


                        <Mat_DateTimePicker
                        data-testid={state.PMSBuilConsDateTime}
                        value = {state.PMSBuilConsDateTime}

                        skipMin={true}
                        onErr={(e) =>{setDateErrPMSBuilConsDateTime(e)}}
                        onChange={(val)=>{storeDispatch(val,'PMSBuilConsDateTime','date');
                        }}

                      label={tf("PMSBuilConsDateTime")}
                        frmctrlid="fld1394_36564"
                        frmctrlidName="PMSBuilConsDateTime"
                        fieldorder = "2"
                        />
                   </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3} className='flexEnd'>   


                        <Mat_DateTimePicker
                        data-testid={state.PMSBuilHODateTime}
                        value = {state.PMSBuilHODateTime}

                        skipMin={true}
                        onErr={(e) =>{setDateErrPMSBuilHODateTime(e)}}
                        onChange={(val)=>{storeDispatch(val,'PMSBuilHODateTime','date');
                        }}

                      label={tf("PMSBuilHODateTime")}
                        frmctrlid="fld1394_36565"
                        frmctrlidName="PMSBuilHODateTime"
                        fieldorder = "3"
                        />
                   </GridItem>

           <GridItem xs={3} md={3} lg={3} sm={3} className='flexEnd'>   


                        <Mat_DateTimePicker
                        data-testid={state.PMSBuilTenanDateTime}
                        value = {state.PMSBuilTenanDateTime}

                        skipMin={true}
                        onErr={(e) =>{setDateErrPMSBuilTenanDateTime(e)}}
                        onChange={(val)=>{storeDispatch(val,'PMSBuilTenanDateTime','date');
                        }}

                      label={tf("PMSBuilTenanDateTime")}
                        frmctrlid="fld1394_36566"
                        frmctrlidName="PMSBuilTenanDateTime"
                        fieldorder = "4"
                        />
                   </GridItem>

              </GridContainer>
       </div>
</div>


                                     </div> 

                                              <div className={"l4-side-menu "+(isSideMenu? '':"")}>
                                                                    <div className='cardhight cardl4'>
                                                                        <div>
                                                                            <div className="PMSBuildingRegistry-sublink formpanel">

                                   <div className='divacc' >
                                       <Accordion expanded={expandedPanel == 'panelS2'} onChange={handleChangePanel('panelS2')}>
                                           <AccordionSummary className='accpanel'  expandIcon={<ExpandMoreIcon className='iconExpand' />} >
                                               <p className={ 'mpadd5 plinkactive'} >Periods</p>
                                            </AccordionSummary >
                                                       <AccordionDetails >
              <GridContainer spacing={12}>
           <GridItem xs={12} md={12} lg={12} sm={12} className='flexEnd'>   


                        <Mat_DateTimePicker
                        data-testid={state.PMSBuilLeasDateTime}
                        value = {state.PMSBuilLeasDateTime}

                        skipMin={true}
                        onErr={(e) =>{setDateErrPMSBuilLeasDateTime(e)}}
                        onChange={(val)=>{storeDispatch(val,'PMSBuilLeasDateTime','date');
                        }}

                      label={tf("PMSBuilLeasDateTime")}
                        frmctrlid="fld1394_36568"
                        frmctrlidName="PMSBuilLeasDateTime"
                        fieldorder = "1"
                        />
                   </GridItem>

           <GridItem xs={12} md={12} lg={12} sm={12}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilGraPeriInMons}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilGraPeriInMons"
                           tfLabel={tf("PMSBuilGraPeriInMons")}
                           frmctrlid="fld1394_36567"
                           fieldorder = "2"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilGraPeriInMons",'number')}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'number',name: "PMSBuilGraPeriInMons",number:0});}}
                           }

                           value={state.PMSBuilGraPeriInMons}
                  />
               </GridItem>

           <GridItem xs={12} md={12} lg={12} sm={12}>   


                           <L2TextField
                           json={json}  
                           data-testid={state.PMSBuilDescription}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "PMSBuilDescription"
                           tfLabel={tf("PMSBuilDescription")}
                           frmctrlid="fld1394_37061"
                           fieldorder = "3"





                           onChange={(e)=>{storeDispatch(e,"PMSBuilDescription","text")}}
                           clear={(e) => { if(e){ 
                                   dispatch({type:'text',name: "PMSBuilDescription",value:""});}}
                           }

                           value={state.PMSBuilDescription}
                  />
               </GridItem>

              </GridContainer>
                                                       </AccordionDetails >
                                        </Accordion>
                                   </div>


                                   <div className='divacc' style ={{display: 'none'}}>
                                       <Accordion expanded={expandedPanel == 'panelS@number@'} onChange={handleChangePanel('panelS@number@')}>
                                           <AccordionSummary className='accpanel'  expandIcon={<ExpandMoreIcon className='iconExpand' />} >
                                               <p className={ 'mpadd5 plinkactive'} >Invisible Field</p>
                                            </AccordionSummary >
                                                       <AccordionDetails >
              <GridContainer spacing={12}>
           <GridItem xs={12} md={12} lg={12} sm={12}>   


                           <L2DropDown
                           //id = {state.BuildingKey}
                           data-testid={state.BuildingKey}
                           json={json}
                           SPName = "PMSBuildingRegistry"
                           FieldName = "BuildingKey"
                           tfLabel={tf("BuildingKey")}
                           EnterSave= {(e) => {if(e){ props.submitConfirmation(e) }}}
                           onSelect={(e) => !props.createEasy && updateAlert(e)}
                           onClick={()=>{ if(ShowListBuildingKey){PMSBuildingRegistry_SelectText(1,'','ClearAll')} setShowListBuildingKey(true);} }
                           frmctrlid="fld1394_37060"
                           frmctrlidName="BuildingKey"
                           fieldorder = "1"
                           data={Data}
                           foreign = {false}
                           foreignFld={[]}
                           foreignClick={() => {}}
                           totalCount={Data.length > 0 ? Data[0].TotalCount : 0}
                           onChange={(i,e)=>{if(ShowListBuildingKey){PMSBuildingRegistry_SelectText(i,e,"BuildingKey");}storeDispatch(e,"BuildingKey","text")}}
                           onKeyDown={e => {if(e.keyCode == "8"|| e.keyCode == "46"){setShowListBuildingKey(true);}}}
                           showList = {ShowListBuildingKey}
                           SideEntryView = {false}
                           KeyBack={e=>{}} 




                           value={state.BuildingKey}
                           loading = {loading}
                           clear={(e) => { if(e){ 
                           dispatch({type:'text',name: "BuildingKey",value:""});
                           setShowListBuildingKey(true);
                           }
                           }}
                       />
                   </GridItem>


              </GridContainer>
                                                       </AccordionDetails >
                                        </Accordion>
                                   </div>



                                                                            </div>
                                                                        </div>
                                                                    </div>
                                     <div id="PMSBuildingRegistrySideBar" className="sidenav"> 
                                     <div className="closebtn" onClick={() => closeNav()}>&times;</div> 
                                     {ShowSlide && 
                                     <div className="MainDivStyles Maincontent displayFlex width100 SideBarComponent" >
                                     {SlideComponentType}
                                     </div>
                                     }
                                     </div>
                                     </div> 
                                     </div>
                                     </div>
                                     </div> 
                                     </div>
                                     </div>
                                           </AccordionDetails>
                                            </Accordion>
                       </div>
                   </div> 
               }
               </div>
               </div>
           </div> 
           </div>
           </div>
    )
});

export default PMSBuildingRegistry;



// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023




