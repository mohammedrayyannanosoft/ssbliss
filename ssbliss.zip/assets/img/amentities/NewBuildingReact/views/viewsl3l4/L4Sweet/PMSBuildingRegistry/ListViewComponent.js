﻿



// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023
// Main Imports
import React,{forwardRef,useState, useEffect,useImperativeHandle,useRef} from 'react';
import DynamicTable from '../../../components/_helperComponents/DynamicTable';
import {config} from '../../../config.js';
import { withStyles } from '@material-ui/styles';
import GridContainer from "../../../components/Grid/GridContainer";
import GridItem from "../../../components/Grid/GridItem";
import CommonAPISelect from '../../../CommonAPISelect';
import { useSelector } from "react-redux";
import SchemaCardComponent from "../../../components/_helperComponents/SchemaCardComponent";
import ShareCardComponent from "../../../components/_helperComponents/ShareCardComponent";
import { PMSBuildingRegistryPopUpTable } from './TableComponent';
import { PMSBuildingRegistryContext,ContextApi} from './MainComponent';


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// List View Components
export function SchemaComponent(props){
const content = useSelector(state => state.form);
const [GridViewData,setGridViewData]=useState([]);
const [GridViewChildData,setGridViewChildData]=useState([]);
const [ListChild,setListChild]=useState(false);
const [GridViewChildHeader,setGridViewChildHeader]=useState([]);
const [GridViewChildCount,setGridViewChildCount]=useState([]);
const [GridViewSubChildData,setGridViewSubChildData]=useState([]);
const [GridViewSubChildHeader,setGridViewSubChildHeader]=useState([]);
const [GridViewSubChildCount,setGridViewSubChildCount]=useState([]);
const [MainTableData,setMainTableData]=useState({id:'',type:''});
const [SearchJson,setSearchJson]=useState({});
const [PageIndex,setPageIndex]=useState(1);  
const {cstate , cdispatch} = ContextApi();
const [SearchParams,setSearchParams] = useState({});
const [ShowView,setShowView]=useState(false);
const [EditData,setEditData]=useState({});
const [pagination,setPagination]= useState({current: 1, pageSize: 10})
const [DisplayName,setDisplayName]=useState('');
const [Cardtype, setCardtype] = useState('')
const [ApiParamType,setApiParamType]=useState({type:'PMSBuildingIDPK',params:{}});


useEffect(() => {
    if(props.onload){
        GridViewSelect(SearchParams,'PMSBuildingIDPK');
    }
    setListChild(false);
},[props.onload]);

useEffect(() => {
    if(props.refresh){
        GridViewSelect(ApiParamType.params,'PMSBuildingIDPK'); 
    }
}, [props.refresh])

function ViewToEdit(data){ 
    setEditData(data);
    document.getElementById('PMSBuildingRegistryPopUpTableSchema').style.width = '0';
    document.getElementById('PMSBuildingRegistryPopUpTableSchema').style.padding = '0';
    document.getElementById('PMSBuildingRegistry-ThemeSlide1').style.width = '3.3%';
    document.getElementById('PMSBuildingRegistry-ThemeSlide1').style.background = 'none';
    document.getElementById('PMSBuildingRegistry-Floatcnt').style.width = '0';
    document.getElementById('PMSBuildingRegistry-Floatcnt').style.display = 'none';
    document.getElementById('sidebarwid').style.zIndex = '1';
}

useEffect(() => {
GridViewSelect(props.json,"PMSBuildingIDPK");
setSearchJson(props.json);
   document.getElementById("PMSBuildingRegistryGridViewCard").style.width = '100%';
},[props.json]);

const GridViewSelect = (val,type) => { 
let url = config.Api + "FP1394S5/";
let data = {
       data:
       {
            "p1": val && val.PMSBuildingIDPK ? val.PMSBuildingIDPK : null
               ,"p2": val && val.PMSBuilCode? val.PMSBuilCode : null
               ,"p3": val && val.PMSBuilName? val.PMSBuilName : null
               ,"p4": val && val.PMSBuilNo? val.PMSBuilNo : null
               ,"p5": val && val.PMSBuilArInSqFet? val.PMSBuilArInSqFet : null
               ,"p6": val && val.PMSBuilLatitude? val.PMSBuilLatitude : null
               ,"p7": val && val.PMSBuilLongitude? val.PMSBuilLongitude : null
               ,"p8": val && val.PMSBuilCostGroup? val.PMSBuilCostGroup : null
               ,"p9": val && val.PMSBuilPermitNo? val.PMSBuilPermitNo : null
               ,"p10": val && val.PMSBuilConfig? val.PMSBuilConfig : null
               ,"p11": val && val.PMSBuilMakaniNo? val.PMSBuilMakaniNo : null
               ,"p12": val && val.PMSBuilDMNo? val.PMSBuilDMNo : null
               ,"p13": val && val.PMSBuilNoOfFlor? val.PMSBuilNoOfFlor : null
               ,"p14": val && val.PMSBuilNoOfPark? val.PMSBuilNoOfPark : null
               ,"p15": val && val.PMSBuilNoOfUnit? val.PMSBuilNoOfUnit : null
               ,"p16": val && val.PMSBuilBUPArea? val.PMSBuilBUPArea : null
               ,"p17": val && val.PMSBuilLeasArea? val.PMSBuilLeasArea : null
               ,"p18": val && val.PMSBuilConsDateTime? val.PMSBuilConsDateTime : null
               ,"p19": val && val.PMSBuilConsDateTimeType? val.PMSBuilConsDateTimeType : null
               ,"p20": val && val.PMSBuilConsDateTimeBetween? val.PMSBuilConsDateTimeBetween : null
               ,"p21": val && val.PMSBuilHODateTime? val.PMSBuilHODateTime : null
               ,"p22": val && val.PMSBuilHODateTimeType? val.PMSBuilHODateTimeType : null
               ,"p23": val && val.PMSBuilHODateTimeBetween? val.PMSBuilHODateTimeBetween : null
               ,"p24": val && val.PMSBuilTenanDateTime? val.PMSBuilTenanDateTime : null
               ,"p25": val && val.PMSBuilTenanDateTimeType? val.PMSBuilTenanDateTimeType : null
               ,"p26": val && val.PMSBuilTenanDateTimeBetween? val.PMSBuilTenanDateTimeBetween : null
               ,"p27": val && val.PMSBuilGraPeriInMons? val.PMSBuilGraPeriInMons : null
               ,"p28": val && val.PMSBuilLeasDateTime? val.PMSBuilLeasDateTime : null
               ,"p29": val && val.PMSBuilLeasDateTimeType? val.PMSBuilLeasDateTimeType : null
               ,"p30": val && val.PMSBuilLeasDateTimeBetween? val.PMSBuilLeasDateTimeBetween : null
               ,"p31": val && val.PMSBuilDescription? val.PMSBuilDescription : null
               ,"p32": val && val.BuildingKey? val.BuildingKey : null
               ,"p33": null
               ,"p34": null
               ,"p35": val && val.LocalityID? val.LocalityID : null
               ,"p36": val && val.OrganisationID? val.OrganisationID : null
               ,"p37": val && val.CountryID? val.CountryID : null
               ,"p38": val && val.RegionID? val.RegionID : null
               ,"p39": val && val.PMSBuildingComID? val.PMSBuildingComID : null
               ,"p40": val && val.AssBuildingTypeID? val.AssBuildingTypeID : null
               ,"p41": val && val.PMSLandLordID? val.PMSLandLordID : null
               ,"p42": val && val.EmployeeID? val.EmployeeID : null
               ,"p43": val && val.EmployeeID1? val.EmployeeID1 : null
               ,"p44": props.Dialogview ? "1" : null
               ,"p45": null
               ,"p46": val && val.CreatedUserID_varchar? val.CreatedUserID_varchar : null
               ,"p47": val && val.CreatedTtm? val.CreatedTtm : null
               ,"p48": val && val.CreatedTtmType? val.CreatedTtmType : null
               ,"p49": val && val.CreatedTtmBetween? val.CreatedTtmBetween : null
               ,"p50": null
               ,"p51": val && val.LocalityGroupID? val.LocalityGroupID : null
               ,"p52": val && val.LocalityGroupCode? val.LocalityGroupCode : null
               ,"p53": val && val.LocalityGroupName? val.LocalityGroupName : null
               ,"p54": val && val.CityID? val.CityID : null
               ,"p55": val && val.CityCode? val.CityCode : null
               ,"p56": val && val.CityName? val.CityName : null
               ,"p57": val && val.AdminLocalityTypeID? val.AdminLocalityTypeID : null
               ,"p58": val && val.AdminLocalityTypeCode? val.AdminLocalityTypeCode : null
               ,"p59": val && val.AdminLocalityTypeName? val.AdminLocalityTypeName : null
               ,"p60": val && val.LocalityCode? val.LocalityCode : null
               ,"p61": val && val.LocalityName? val.LocalityName : null
               ,"p62": val && val.OrganisationCode? val.OrganisationCode : null
               ,"p63": val && val.OrganisationName? val.OrganisationName : null
               ,"p64": val && val.CountryCode? val.CountryCode : null
               ,"p65": val && val.CountryName? val.CountryName : null
               ,"p66": val && val.RegionCode? val.RegionCode : null
               ,"p67": val && val.RegionName? val.RegionName : null
               ,"p68": val && val.PMSBuildingComCode? val.PMSBuildingComCode : null
               ,"p69": val && val.PMSBuildingComName? val.PMSBuildingComName : null
               ,"p70": val && val.AssBuildingTypeCode? val.AssBuildingTypeCode : null
               ,"p71": val && val.AssBuildingTypeName? val.AssBuildingTypeName : null
               ,"p72": val && val.ShiftID? val.ShiftID : null
               ,"p73": val && val.ShiftCode? val.ShiftCode : null
               ,"p74": val && val.ShiftName? val.ShiftName : null
               ,"p75": val && val.ClassificationID? val.ClassificationID : null
               ,"p76": val && val.ClassificationCode? val.ClassificationCode : null
               ,"p77": val && val.ClassificationName? val.ClassificationName : null
               ,"p78": val && val.DepartmentID? val.DepartmentID : null
               ,"p79": val && val.DepartmentCode? val.DepartmentCode : null
               ,"p80": val && val.DepartmentName? val.DepartmentName : null
               ,"p81": val && val.DesignationID? val.DesignationID : null
               ,"p82": val && val.DesignationCode? val.DesignationCode : null
               ,"p83": val && val.DesignationName? val.DesignationName : null
               ,"p84": val && val.NationalityID? val.NationalityID : null
               ,"p85": val && val.NationalityCode? val.NationalityCode : null
               ,"p86": val && val.NationalityName? val.NationalityName : null
               ,"p87": val && val.EmpWorkNatureID? val.EmpWorkNatureID : null
               ,"p88": val && val.NatureOfWorkCode? val.NatureOfWorkCode : null
               ,"p89": val && val.NatureOfWorkName? val.NatureOfWorkName : null
               ,"p90": val && val.EmployeeTypeID? val.EmployeeTypeID : null
               ,"p91": val && val.EmployeeTypeCode? val.EmployeeTypeCode : null
               ,"p92": val && val.EmployeeTypeName? val.EmployeeTypeName : null
               ,"p93": val && val.EmploymentTypeID? val.EmploymentTypeID : null
               ,"p94": val && val.EmploymentTypCode? val.EmploymentTypCode : null
               ,"p95": val && val.EmploymentTypeName? val.EmploymentTypeName : null
               ,"p96": val && val.EmployeeGroupID? val.EmployeeGroupID : null
               ,"p97": val && val.EmployeeGroupCode? val.EmployeeGroupCode : null
               ,"p98": val && val.EmployeeGroupName? val.EmployeeGroupName : null
               ,"p99": val && val.EmpGradeID? val.EmpGradeID : null
               ,"p100": val && val.EmpGradeCode? val.EmpGradeCode : null
               ,"p101": val && val.EmpGradeName? val.EmpGradeName : null
               ,"p102": val && val.EmpGenderID? val.EmpGenderID : null
               ,"p103": val && val.EmpGenderName? val.EmpGenderName : null
               ,"p104": val && val.EmpTitleID? val.EmpTitleID : null
               ,"p105": val && val.EmpTitleName? val.EmpTitleName : null
               ,"p106": val && val.EmployeeCode? val.EmployeeCode : null
               ,"p107": val && val.FirstName? val.FirstName : null
               ,"p108": val && val.EmpContactNo1? val.EmpContactNo1 : null
               ,"p109": val && val.EmpEmailOfficial? val.EmpEmailOfficial : null
             ,"p110": 1
             ,"p111": 10
             ,"p112": type
               ,"p113": null
               ,"p114": null
               ,"p115": localStorage.getItem('UserGroupID')
               ,"p116": localStorage.getItem('userid')
                }
}
CommonAPISelect(url,data,cstate.token[0])
.then(res => { 
    if(res.Output.data){ 
        let result = res.Output.data; 
            if(type == "PMSBuildingIDPK"){
                setGridViewData(result);
                setListChild(false);
            }else {
                setGridViewChildData(result);
                setListChild(true);
            }
            //setApiParamType({type:type,params:data.data});
    }
}); 
}


return (
                <div id="PMSBuildingRegistryGridViewCard">
                    <div className="GridViewChildCard">
                    <SchemaCardComponent 
                    name={DisplayName.DisplayName} 
                    count={DisplayName.Total} 
                    id ='PMSBuildingRegistryPopUpTableSchema' 
                    showSearch={props.showSearch} 
                    type='Schema' chipdata={GridViewChildData}
                    showview={ShowView} 
                    viewcomponent={ShowView && <ViewComponent ExpandDetailValue={true} l4viewonly={ShowView} data={EditData} editopen={ViewToEdit} />}
                    tablecomponent={
                    <DynamicTable dynamic={true}
                    name={CardName}
                    tableData={GridViewChildData}
                    TableVisibleItem={[]}
                    TableBodyItem={[]} 
               />
           } data={GridViewData} sendparams={setSearchParams}
           getChildData={(e,f) => {GridViewSelect(SearchJson,e,pagination);setCardName(f.Name); }} 
           float={true}
           />



        </div>
        </div>
    );
}



// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023

//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



