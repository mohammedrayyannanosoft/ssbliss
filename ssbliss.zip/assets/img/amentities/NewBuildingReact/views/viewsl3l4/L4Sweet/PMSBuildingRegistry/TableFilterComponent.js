﻿



// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023
import 'react-infinite-calendar/styles.css';
import  'react-modern-calendar-datepicker/lib/DatePicker.css';
import React,{useEffect, useRef, useState} from 'react';
import ArrowForwardIcon from '@material-ui/icons/ArrowForward';
import CloseIcon from '@material-ui/icons/Close';
import CommonAPISelect from '../../../CommonAPISelect';
import MatBtn from '@material-ui/core/Button';
import Tooltip from '@material-ui/core/Tooltip';
// Icons 
import MoreVertIcon from '@material-ui/icons/MoreVert'; 
import GridContainer from "../../../components/Grid/GridContainer";
import GridItem from "../../../components/Grid/GridItem";
//language 
// import RLDD from 'react-list-drag-and-drop/lib/RLDD';
import 'react-infinite-calendar/styles.css';
import {config} from '../../../config.js';
import Datecomponents,{GetDateValue} from '../../../components/_helperComponents/DateComponent';
import InputSearch from '../../../components/_helperComponents/InputSearch';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import multilingual from '../../../components/_helperComponents/tjson/multilingual';
import { BiFilterAlt } from 'react-icons/bi'
import { FiMaximize2, FiMinimize2 } from 'react-icons/fi';
import { PMSBuildingRegistryContext,ContextApi } from './MainComponent'




const DialogTitle = ((props) => {
    const { children, classes, onClose, ...other } = props;
    return (
        <MuiDialogTitle disableTypography style={{padding:0}}{...other}>
        <Typography variant="h6" style={{marginTop:"0.5rem"}}>{children}</Typography>
        {onClose ? (
            <IconButton aria-label="close" className="calenderdialogrootclose" id="fld1394L4TFCfiltercalenderclose" onClick={onClose}>
            <CloseIcon />
            </IconButton>
        ) : null}
        </MuiDialogTitle>
    );
});
// Drop Down Select Funtion 
export default  function PMSBuildingRegistryDropDownComponent(props){
const [userID] = useState(localStorage.getItem('userid'));
const [FilterData,setFilterData]=useState([]);
const [childDet,setChildDetails]=useState({name:'',type:''});
const [FilterInputValue,setFilterInputValue]=useState(''); 
const [selectedItem,setSelectedItem]=useState({}); 
const [ExpandItems,setExpandItems]=useState(true);
const [ShowChild,setShowChild]=useState(false); 
const [CreatedTtmData,setCreatedTtmData]=useState({from:'',to:'',type:'',dtype:'',fname:''}); 
const {cstate , cdispatch} = props.ContextApi ? props.ContextApi : ContextApi(); 
const [FilterIndex,setFilterIndex]=useState(1); 
const [FilterDataCount,setFilterDataCount]=useState(0); 


let lang = multilingual();
const t = (e) =>  lang[e] ? lang[e] : e; 
const tf = (e) =>  cstate.language?.[e] ? cstate.language[e] : e ; 



useEffect(()=>{
},[])

function ClearSearch(){
        setSelectedItem({});
        setCreatedTtmData({from:'',to:'',type:'',dtype:'',fname:''});
        props.searchData({});
        setShowChild(false);
}

const FilterDataFunction = async (type,FieldType,val,index=1,IDPK,clear) => {
   let nameof ='';
   let selc =[];
   await setChildDetails(prv => {nameof =prv.name; return prv})
   await setSelectedItem(prv => {selc =prv; return prv})
    const url = config.Api +"FP1394S3/";
    const params = {
    "data":{
            "p1": !IDPK ? null : await MergeArray()
               ,"p2": FieldType == "PMSBuilCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p3": FieldType == "PMSBuilName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p4": FieldType == "PMSBuilNo" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p5": FieldType == "PMSBuilArInSqFet" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p6": FieldType == "PMSBuilLatitude" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p7": FieldType == "PMSBuilLongitude" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p8": FieldType == "PMSBuilCostGroup" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p9": FieldType == "PMSBuilPermitNo" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p10": FieldType == "PMSBuilConfig" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p11": FieldType == "PMSBuilMakaniNo" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p12": FieldType == "PMSBuilDMNo" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p13": FieldType == "PMSBuilNoOfFlor" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p14": FieldType == "PMSBuilNoOfPark" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p15": FieldType == "PMSBuilNoOfUnit" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p16": FieldType == "PMSBuilBUPArea" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p17": FieldType == "PMSBuilLeasArea" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p18": FieldType == "PMSBuilConsDateTime" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p19": FieldType == "PMSBuilConsDateTimeType" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p20": FieldType == "PMSBuilConsDateTimeBetween" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p21": FieldType == "PMSBuilHODateTime" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p22": FieldType == "PMSBuilHODateTimeType" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p23": FieldType == "PMSBuilHODateTimeBetween" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p24": FieldType == "PMSBuilTenanDateTime" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p25": FieldType == "PMSBuilTenanDateTimeType" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p26": FieldType == "PMSBuilTenanDateTimeBetween" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p27": FieldType == "PMSBuilGraPeriInMons" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p28": FieldType == "PMSBuilLeasDateTime" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p29": FieldType == "PMSBuilLeasDateTimeType" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p30": FieldType == "PMSBuilLeasDateTimeBetween" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p31": FieldType == "PMSBuilDescription" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p32": FieldType == "BuildingKey" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p33": null
               ,"p34": null
               ,"p35": FieldType != 'LocalityName' ? (selc['LocalityName'] ? selc['LocalityName'].map(a => a['LocalityID']).toString() :null) : null
               ,"p36": FieldType != 'OrganisationName' ? (selc['OrganisationName'] ? selc['OrganisationName'].map(a => a['OrganisationID']).toString() :null) : null
               ,"p37": FieldType != 'CountryName' ? (selc['CountryName'] ? selc['CountryName'].map(a => a['CountryID']).toString() :null) : null
               ,"p38": FieldType != 'RegionName' ? (selc['RegionName'] ? selc['RegionName'].map(a => a['RegionID']).toString() :null) : null
               ,"p39": FieldType != 'PMSBuildingComName' ? (selc['PMSBuildingComName'] ? selc['PMSBuildingComName'].map(a => a['PMSBuildingComID']).toString() :null) : null
               ,"p40": FieldType != 'AssBuildingTypeName' ? (selc['AssBuildingTypeName'] ? selc['AssBuildingTypeName'].map(a => a['AssBuildingTypeID']).toString() :null) : null
               ,"p41": FieldType != 'PMSLLdName' ? (selc['PMSLLdName'] ? selc['PMSLLdName'].map(a => a['PMSLandLordID']).toString() :null) : null
               ,"p42": FieldType != 'FirstName' ? (selc['FirstName'] ? selc['FirstName'].map(a => a['EmployeeID']).toString() :null) : null
               ,"p43": FieldType != 'FirstName1' ? (selc['FirstName1'] ? selc['FirstName1'].map(a => a['EmployeeID1']).toString() :null) : null
               ,"p44": props.Dialogview ? "1" : null
               ,"p45": null
               ,"p46": FieldType == "p46" ? val.length >0 ? val : null : null
               ,"p47": null
               ,"p48": null
               ,"p49": null
               ,"p50": null
               ,"p51": FieldType != 'LocalityGroupName' ? (selc['LocalityGroupName'] ? selc['LocalityGroupName'].map(a => a['LocalityGroupID']).toString() :null) : null
               ,"p52": FieldType == "LocalityGroupCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p53": FieldType == "LocalityGroupName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p54": FieldType != 'CityName' ? (selc['CityName'] ? selc['CityName'].map(a => a['CityID']).toString() :null) : null
               ,"p55": FieldType == "CityCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p56": FieldType == "CityName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p57": FieldType != 'AdminLocalityTypeName' ? (selc['AdminLocalityTypeName'] ? selc['AdminLocalityTypeName'].map(a => a['AdminLocalityTypeID']).toString() :null) : null
               ,"p58": FieldType == "AdminLocalityTypeCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p59": FieldType == "AdminLocalityTypeName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p60": FieldType == "LocalityCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p61": FieldType == "LocalityName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p62": FieldType == "OrganisationCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p63": FieldType == "OrganisationName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p64": FieldType == "CountryCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p65": FieldType == "CountryName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p66": FieldType == "RegionCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p67": FieldType == "RegionName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p68": FieldType == "PMSBuildingComCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p69": FieldType == "PMSBuildingComName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p70": FieldType == "AssBuildingTypeCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p71": FieldType == "AssBuildingTypeName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p72": FieldType != 'ShiftName' ? (selc['ShiftName'] ? selc['ShiftName'].map(a => a['ShiftID']).toString() :null) : null
               ,"p73": FieldType == "ShiftCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p74": FieldType == "ShiftName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p75": FieldType != 'ClassificationName' ? (selc['ClassificationName'] ? selc['ClassificationName'].map(a => a['ClassificationID']).toString() :null) : null
               ,"p76": FieldType == "ClassificationCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p77": FieldType == "ClassificationName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p78": FieldType != 'DepartmentName' ? (selc['DepartmentName'] ? selc['DepartmentName'].map(a => a['DepartmentID']).toString() :null) : null
               ,"p79": FieldType == "DepartmentCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p80": FieldType == "DepartmentName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p81": FieldType != 'DesignationName' ? (selc['DesignationName'] ? selc['DesignationName'].map(a => a['DesignationID']).toString() :null) : null
               ,"p82": FieldType == "DesignationCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p83": FieldType == "DesignationName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p84": FieldType != 'NationalityName' ? (selc['NationalityName'] ? selc['NationalityName'].map(a => a['NationalityID']).toString() :null) : null
               ,"p85": FieldType == "NationalityCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p86": FieldType == "NationalityName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p87": FieldType != 'NatureOfWorkName' ? (selc['NatureOfWorkName'] ? selc['NatureOfWorkName'].map(a => a['EmpWorkNatureID']).toString() :null) : null
               ,"p88": FieldType == "NatureOfWorkCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p89": FieldType == "NatureOfWorkName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p90": FieldType != 'EmployeeTypeName' ? (selc['EmployeeTypeName'] ? selc['EmployeeTypeName'].map(a => a['EmployeeTypeID']).toString() :null) : null
               ,"p91": FieldType == "EmployeeTypeCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p92": FieldType == "EmployeeTypeName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p93": FieldType != 'EmploymentTypeName' ? (selc['EmploymentTypeName'] ? selc['EmploymentTypeName'].map(a => a['EmploymentTypeID']).toString() :null) : null
               ,"p94": FieldType == "EmploymentTypCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p95": FieldType == "EmploymentTypeName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p96": FieldType != 'EmployeeGroupName' ? (selc['EmployeeGroupName'] ? selc['EmployeeGroupName'].map(a => a['EmployeeGroupID']).toString() :null) : null
               ,"p97": FieldType == "EmployeeGroupCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p98": FieldType == "EmployeeGroupName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p99": FieldType != 'EmpGradeName' ? (selc['EmpGradeName'] ? selc['EmpGradeName'].map(a => a['EmpGradeID']).toString() :null) : null
               ,"p100": FieldType == "EmpGradeCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p101": FieldType == "EmpGradeName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p102": FieldType != 'EmpGenderName' ? (selc['EmpGenderName'] ? selc['EmpGenderName'].map(a => a['EmpGenderID']).toString() :null) : null
               ,"p103": FieldType == "EmpGenderName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p104": FieldType != 'EmpTitleName' ? (selc['EmpTitleName'] ? selc['EmpTitleName'].map(a => a['EmpTitleID']).toString() :null) : null
               ,"p105": FieldType == "EmpTitleName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p106": FieldType == "EmployeeCode" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p107": FieldType == "FirstName" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p108": FieldType == "EmpContactNo1" ? val.length >0 ? '%' + val + '%' : null : null
               ,"p109": FieldType == "EmpEmailOfficial" ? val.length >0 ? '%' + val + '%' : null : null
             ,"p110": index
             ,"p111": 10
             ,"p112": type
               ,"p113": null
               ,"p114": null
               ,"p115": localStorage.getItem('UserGroupID')
               ,"p116":localStorage.getItem('userid')
       }
     }      
            //setLoading(true);
      CommonAPISelect(url,params,props.token)
      .then((res)=>{ 
          const result = res.Output.status.code;
          const data = res.Output.data;
          if(result === '200'){ 
           if(data.length > 0){
               if(index === 1){ 
                      let ffobj = removeobj(data,nameof) 
                      setFilterData(ffobj); 
                      setFilterDataCount(ffobj[0].TotalCount); 
                  }else { 
                      let finarr = [...FilterData, ...data]; 
                      let movf = removeobj(finarr,nameof); 
                      setFilterDataCount(movf.length < 10 ? movf.length : data[0].TotalCount); 
                      setFilterData(removeobj(movf,nameof));  
                  } 
           }else{
               if(FilterInputValue.length > 0){
                   setFilterData([]);
               }
                   setFilterDataCount(FilterData.length);
           }
       }
      });
  }

  const removeobj = (arr,value) => { 
      return arr.filter((v,i,a)=>a.findIndex(v2=>(v2[value]===v[value]))===i) 
    } 

  const BackBtnFunction = () =>{ 
      setShowChild(false); 
      setChildDetails({name:'',type:''}); 
      setFilterIndex(1) 
    } 

  const AddItems = async(val) => { 
      let prentObj = {}; 
      let item = []; 
      item.push(val) 
      let fewItems = {} 
      await setSelectedItem(prv => { 
          fewItems = prv 
          return prv; 
      }) 
      let prv = fewItems[childDet.name] 
      prentObj[childDet.name] = prv ?  [...item,...prv] : item ;  
      fewItems = {...fewItems,...prentObj} 
       
      setSelectedItem(fewItems) 
      setFilterData(prv => prv.filter(a => a != val)) 
    } 

  const SendFilterValue = async(val) => { 
   
      let fillObj = '';  
   
      await setSelectedItem(prv => { 
          fillObj = prv 
          return prv; 
      }) 
   
      let primval = ['CityCode', 'CityName'] 
   
      let primid = [] 
   
      for(let cur of primval){ 
          let id = fillObj[cur]?.map(v => v.CityIDPK).toString(); 
          if(id) primid.push(id) 
      } 
   
      let params = { 
            PMSBuildingIDPK: primid ? [...new Set(primid)].toString() : '', 
            CreatedTtm: '',
            CreatedTtmType:'',
            CreatedTtmBetween:'',

          LocalityID:selectedItem['LocalityName']?.map(v => v['LocalityID']).toString(),
          CountryID:selectedItem['CountryName']?.map(v => v['CountryID']).toString(),
          RegionID:selectedItem['RegionName']?.map(v => v['RegionID']).toString(),
          OrganisationID:selectedItem['OrganisationName']?.map(v => v['OrganisationID']).toString(),
          AssBuildingTypeID:selectedItem['AssBuildingTypeName']?.map(v => v['AssBuildingTypeID']).toString(),
          PMSBuildingComID:selectedItem['PMSBuildingComName']?.map(v => v['PMSBuildingComID']).toString(),
          PMSLandLordID:selectedItem['PMSLLdName']?.map(v => v['PMSLandLordID']).toString(),
          EmployeeID:selectedItem['FirstName']?.map(v => v['EmployeeID']).toString(),
          EmployeeID1:selectedItem['FirstName1']?.map(v => v['EmployeeID1']).toString(),
    } 
      props.searchData(params); 
      setShowChild(false) 
   
    } 
  const ClearSelectedChild = async(val,i) => { 
      setFilterIndex(1) 
      let item = selectedItem[childDet.name].filter(a => a != val) 
      let obj = {} 
      await setSelectedItem(prv => { 
          obj = prv; 
          return prv; 
      }) 
      obj[childDet.name] = item 
      setSelectedItem(obj) 
      setFilterData(prv => [val,...prv]) 
   
    } 
    const SelectedItemFunction = () => { 
        return  
    } 

  const ClearAllSelectedChild = async() => { 
      
      let fewItems = {} 
      await setSelectedItem(prv => { 
          fewItems = prv; 
          console.log('clear fewItems',fewItems) 
          return prv; 
      }) 
        fewItems[childDet.name] = [] 
        FilterDataFunction(childDet.type,childDet.name,'',1,'','clear'); 
    } 

  const OpenChild = (item) =>{ 
      setShowChild(true); 
      setFilterInputValue(''); 
      setChildDetails({name: item.FieldDisplay, type: item.IsForeign ? 'Filter'+item.FieldName :  'FilterPMSBuildingID'}); 
      FilterDataFunction(item.IsForeign ? 'Filter'+item.FieldName :  'FilterPMSBuildingID',item,'',1,MergeArray()) 
    } 
   
    function OpenChildDate(name,type,data){ 
      setShowChild(true); 
      setChildDetails({name:name,type:type}); 
      if (data.length > 0) { 
             FilterDataFunction(type,name,'',1,''); 
      }else{ 
             FilterDataFunction(type,name,'',1,MergeArray()); 
      } 
      setFilterInputValue(''); 
  } 
  async function MergeArray(){ 
      let fillObj = {}; 
      await setSelectedItem(prv => { 
          fillObj = prv; 
          return prv; 
      }) 
      let primval = [
'PMSBuilCode'
,'PMSBuilName'
,'PMSBuilNo'
,'PMSBuilArInSqFet'
,'PMSBuilLatitude'
,'PMSBuilLongitude'
,'PMSBuilCostGroup'
,'PMSBuilPermitNo'
,'PMSBuilConfig'
,'PMSBuilMakaniNo'
,'PMSBuilDMNo'
,'PMSBuilNoOfFlor'
,'PMSBuilNoOfPark'
,'PMSBuilNoOfUnit'
,'PMSBuilBUPArea'
,'PMSBuilLeasArea'
,'PMSBuilConsDateTime'
,'PMSBuilHODateTime'
,'PMSBuilTenanDateTime'
,'PMSBuilLeasDateTime'
,'PMSBuilGraPeriInMons'
,'PMSBuilDescription'
,'BuildingKey'] 
      let primid = [] 
      for(let cur of primval){ 
          let id = fillObj[cur]?.map(v => v.PMSBuildingIDPK).toString(); 
          if(id) primid.push(id) 
      } 
      return primid ? [...new Set(primid)].toString() : ''; 
   
  } 

  const taglist = (val) => { 
      return( 
      selectedItem[val]?.length > 0 && <div className='FilterItemDivSelected'> 
                      <span className='RoundedDivName'>{selectedItem[val][0][val]}</span> 
                      {selectedItem[val].length>1 && <span className='RoundedDivName'>{selectedItem[val][1][val]}</span>} 
                      {selectedItem[val].length>2 && <span className='RoundedDivNumber'>{'+'+(selectedItem[val].length-2)}</span>} 
                  </div> 
      ) 
    } 
  function SendDate(from,to,datetype,type,dtype,fname){ 
      const fillObj = {...selectedItem} 
   
      let primval = [
'PMSBuilCode'
,'PMSBuilName'
,'PMSBuilNo'
,'PMSBuilArInSqFet'
,'PMSBuilLatitude'
,'PMSBuilLongitude'
,'PMSBuilCostGroup'
,'PMSBuilPermitNo'
,'PMSBuilConfig'
,'PMSBuilMakaniNo'
,'PMSBuilDMNo'
,'PMSBuilNoOfFlor'
,'PMSBuilNoOfPark'
,'PMSBuilNoOfUnit'
,'PMSBuilBUPArea'
,'PMSBuilLeasArea'
,'PMSBuilConsDateTime'
,'PMSBuilHODateTime'
,'PMSBuilTenanDateTime'
,'PMSBuilLeasDateTime'
,'PMSBuilGraPeriInMons'
,'PMSBuilDescription'
,'BuildingKey'] 
   
      let primid = [] 
   
      for(let cur of primval){ 
          let id = fillObj[cur]?.map(v => v.PMSBuildingIDPK).toString(); 
          if(id) primid.push(id) 
      } 
   
      let params = { 
   
              CreatedTtm:type == 'Created Ttm' ? from : CreatedTtmData.from, 
              CreatedTtmType:type == 'Created Ttm' ? datetype :CreatedTtmData.type, 
              CreatedTtmBetween:type == 'Created Ttm'? to :CreatedTtmData.to, 
              PMSBuildingIDPK: primid ? [...new Set(primid)].toString() : '', 

          LocalityID:selectedItem['LocalityName']?.map(v => v['LocalityIDPK']).toString(),
          CountryID:selectedItem['CountryName']?.map(v => v['CountryIDPK']).toString(),
          RegionID:selectedItem['RegionName']?.map(v => v['RegionIDPK']).toString(),
          OrganisationID:selectedItem['OrganisationName']?.map(v => v['OrganisationIDPK']).toString(),
          AssBuildingTypeID:selectedItem['AssBuildingTypeName']?.map(v => v['AssBuildingTypeIDPK']).toString(),
          PMSBuildingComID:selectedItem['PMSBuildingComName']?.map(v => v['PMSBuildingComIDPK']).toString(),
          PMSLandLordID:selectedItem['PMSLLdName']?.map(v => v['PMSLandLordIDPK']).toString(),
          EmployeeID:selectedItem['FirstName']?.map(v => v['EmployeeIDPK']).toString(),
          EmployeeID1:selectedItem['FirstName1']?.map(v => v['EmployeeID1PK']).toString(),
      } 
   
  if (type === 'Created Ttm') { 
         setCreatedTtmData ({from:from,to:to,type:datetype,dtype:dtype,fname:fname}) 
  } 
      props.searchData(params) 
  } 

  function DateComponentDiv(){ 
   
      if(childDet.name === 'Created Ttm'){ 
          return ( 
              <Datecomponents  
              frmctrlid ='fld3L2TFCCreatedTtm'
              SendDateVal={(f,t,type,dtype,fname) => {SendDate(f,t,type,'Created Ttm',dtype,fname) }} 
              keyboardback={() =>{ 
                  setShowChild(false); 
                  setChildDetails({name:'',type:''}); 
              }} 
              title = {t('Created Date')} 
              fieldname={'CreatedTtm'} 
              save={(e) => {alert(true)}} 
              /> 
          ) 
    } 
  } 





return ( 
  <div>
            {ShowChild ? 
                (((childDet.name === "Created Ttm") || [childDet.name].includes("Date")) ? 
                        <DateComponentDiv/> 
                    :
                        <div>
                            <div className="columnHeader displayFlex">
                                <div className="columnFilterHeaderTitle width100 displayFlex">
                                    <GridContainer>
                                        <GridItem xs={6} sm={6} md={6} lg={6}>
                                            <p className="columnHeaderp">{tf(childDet.name)} ({FilterData.length}/{FilterData[0]?.TotalCount})</p>
                                        </GridItem>
                                        <GridItem xs={6} sm={6} md={6} lg={6} >
                                           <Tooltip title={t('Close')} placement='top'> 
                                               <div className="FilterItemClose" align="right">
                                                   <CloseIcon id="fld1394L4TFCFilterItemCloseIcon" className="FilterItemCloseIcon" onClick={BackBtnFunction}
                                                   />
                                               </div>
                                           </Tooltip>
                                            {selectedItem[childDet.name] && 
                                            <div className='FiltercloseAlign' align="right">
                                                <MatBtn
                                                    frmctrlid="fld1394L4TFCFilterSelectedClearAll"
                                                    className = "ColumnApplyButton"
                                                    onClick={()=> {ClearAllSelectedChild()}}
                                                >
                                                    <span className="ColumnApplyTitle">{t('Clear All')}</span>
                                                </MatBtn>
                                            </div>}
                                        </GridItem>
                                    </GridContainer>
                                </div>
                            </div>
                            <div className="FilterParentDiv">
                                <div data-list-scroll-container="true">
                                    <div id="SelectedItems" tabIndex="-1" className="heightScrollY">
                                       <div className="FilterMaximize">
                                {ExpandItems ?
                                   <Tooltip title="Maximize" placement="right">
                                       <span><FiMaximize2 className="FilterMaximizeIcon" onClick={()=>{setExpandItems(false)}}/></span>
                                   </Tooltip>
                                    :
                                   <Tooltip title="Minimize" placement="right">
                                       <span><FiMinimize2 className="FilterMaximizeIcon" onClick={()=>{setExpandItems(true)}}/></span>
                                   </Tooltip>
                                }
                                </div>
                                        <ul>
                                              { 
                                                  selectedItem[childDet.name] &&      
                                                  selectedItem[childDet.name].map((val,i) => ( 
                                                      <div key={i} tabIndex='-1' className={ExpandItems ? 'filterSelectedItems' : 'filterSelectedItemsMaximize'}> 
                                                          <div className='filterSelectedItemNames'><span>{val[childDet.name]}</span></div> 
                                                          <div className='filterSelectedItemClose'> 
                                                          <div id={'fildacls_3_L2_'+ val[childDet.name]} onClick={()=>ClearSelectedChild(val,i)}> 
                                                              <CloseIcon className='filterSelectedItemCloseIcon'/>  
                                                          </div> 
                                                          </div> 
                                                      </div> 
                                                  ) 
                                              ) 
                                              } 
                                        </ul>
                                    </div>
                                    <div className="displayFlex width100 FilterSearch" >
                                        <div className="FilterSearchInputDiv">
                                            <InputSearch frmctrlid="fld1394L4TFCFilterSearchInput" className="filterSearchInput" type="text"
                                                value={FilterInputValue} placeholder={t('Enter ')+ ' ' + tf(childDet.name)} 
                                                onChange={(e) => {
                                                    setFilterInputValue(e);
                                                           FilterDataFunction(childDet.type,childDet.name,e,1,MergeArray());
                                             }}/>
                                        </div>
                                        <div id="fld1394L4TFCFilterGoForward" className="FilterSearchBtn" onClick={SendFilterValue} > 
                                            <Tooltip title={''} placement='top'>
                                               <MatBtn
                                                        className = "ColumnSearchButton"
                                                   >
                                                        <span className="ColumnCloseTitle">Search</span>
                                                </MatBtn>
                                             </Tooltip>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div id="fld1394L4TFCScrollYDefault" className={"height65 scrollYDefault"}>

                                {FilterData.length > 0 && 
                                  FilterData.map((val,i) => ( 
                                      <div id={'filda_3_L2_'+ val[childDet.name]} key={i} className='FilterItemDiv' onClick={()=>{AddItems(val)}}> 
                                          <MoreVertIcon className='DotIcon'/><span>{val[childDet.name]}</span> 
                                      </div> 
                                  )) 
                                  } 
                                {((FilterData.length + 0) < FilterData[0]?.TotalCount && (FilterData.length > 0))  &&
                                <div id="fld1394L4TFCMoreDataDiv" className="MoreDataDiv" onClick={() =>{
                                    setFilterIndex(FilterIndex+1);
                                    FilterDataFunction(childDet.type,childDet.name,'',FilterIndex+1,'','');
                                    }}>
                                    <p> more... </p>
                                </div>}
                                {FilterData.length === 0 &&  <div>
                                    <div className="NoDataImage" >
                                        <img src={config.NoData} alt="NoImage"/>
                                    </div>
                                    <div className="NoDataDesc">
                                        <span>Sorry, no results found. Try a different search selection or refresh the list.</span>
                                    </div>
                                </div>}
                            </div>
                        </div>
                )
                :
                <div>
                    <div className="columnHeader displayFlex">
                        <div className="columnHeaderTitle">
                            <BiFilterAlt className="columnHeaderIcon"/>
                            // <p className="columnHeaderp"> {t('Filter')} {FavName.length >0 && `(${FavName})`}</p>
                        </div>
                        <div className="columnHeaderbtn" align="right">
                          {/* <Tooltip title={'Favorite List'} placement='top'> 
                          {ShowFav ?
                            <CloseIcon className='favlisticon' onClick={() => { setShowFav(false) }}/> 
                           :  
                          <ListAltIcon className='favlisticon' onClick={() => { GetFavList() }}/>}
                          </Tooltip>*/} 
                           {[].length >0 && 
                           <Tooltip title={'Save Favorites'} placement='top'> 
                                   <SaveIcon className='favlisticon' onClick={()=> { setOpen(true) }}/>
                           </Tooltip>
                           }
                           <Tooltip title={''} placement='top'> 
                            <MatBtn 
                                className = "ColumnApplyButton"
                                onClick={()=> {ClearSearch()}}
                                id="fld1394L4TFCColumApplyBttn"
                            >
                                <span className="ColumnApplyTitle">{t('Clear')}</span>
                            </MatBtn>
                           </Tooltip>
                            <Tooltip title={''} placement='top'>
                            <MatBtn
                                className="ColumnCloseButton"
                                onClick={() => { props.CloseBtnClk() }}
                                id="fld1394L4TFCColumnCloseButton"
                             >
                                <span className="ColumnCloseTitle">{t('Close')}</span>
                            </MatBtn>
                        </Tooltip>
                        </div> 
                    </div>

                                                <div className={'height65'}>

{/*{ShowFav ? 
        <div id="fld1394L4TFCFilItemsShowFav" className="FilterItems">
            {FavList.map((e) => {
                return (
                    <div className="FilterItemDivTitle">
                        <GridContainer>
                            <GridItem xs={3} md={3} lg={3} sm={3}>
                                <span onClick={() => {SetFilterData(e)}} >{e.Name}</span>
                            </GridItem>
                            <GridItem xs={6} md={6} lg={6} sm={6} />
                            <GridItem align="right" xs={3} md={3} lg={3} sm={3}> 
                            <CloseIcon className="filterSelectedItemCloseIcon" onClick={() => {DeleteFavorites(e._id)}}/> 
                            </GridItem> 
                        </GridContainer>
                    </div>
                )
            })}
        </div>
        : null }*/}
                   <div id="fld1394L4TFCFilItems" className="FilterItems">
              <div className='FilterItemDivTitle' onClick={()=>{OpenChildDate('Created Ttm','FilterPMSBuildingID',CreatedTtmData )}}> 
                  {t('Created Date')}{CreatedTtmData.from && <p className='filterdatevalue'>({CreatedTtmData.from+ ' to ' + CreatedTtmData.to})</p>} 
              </div> 
                   {props.userGrid.filter(a => a.IsVisible && !a.FieldName.startsWith('Is')).map((item, ind) => ( 
                       <div className='FilterItemDivTitle' onClick={()=>{OpenChild(item) }}> 
                       <span>{tf(item.FieldName)}</span> 
                       {taglist(item.FieldDisplay)} 
                   </div> 
                   )) } 
               </div>
              </div>
            </div>
        } 
    </div>
)
}


// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



