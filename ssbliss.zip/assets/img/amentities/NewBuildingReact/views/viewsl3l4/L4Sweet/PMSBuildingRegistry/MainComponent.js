﻿

// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023
import React,{useState,useRef,useEffect,createContext,forwardRef} from 'react';
import PMSBuildingRegistryEntry from './EntryComponent';
import AccessRightsAPI from "../../../AccessRightsAPI";
import PMSBuildingRegistryTable,{PMSBuildingRegistryPopUpTable} from './TableComponent';
import { useDispatch, useSelector } from "react-redux";
import Token from '../../../Token';
import {l4Reducer,initialState } from '../../../Reducer/L4Reducer';
import Attachment from '../../../components/_helperComponents/Attachment';
import PriviewImage from '../../../components/_helperComponents/PriviewImg';
import FloatBtn from '../../../components/_helperComponents/FloatBtn';
import ApprDialog from 'dashboard/ApprDialog';

export const PMSBuildingRegistryContext = createContext();

export function ContextApi() {
const context = React.useContext(PMSBuildingRegistryContext)
    if (context === undefined) {
      throw new Error('ContextApi must be used within a PMSBuildingRegistryContext.Provider')
    }
       return context
  }

const PMSBuildingRegistryMain= forwardRef ((props,ref) =>{
const content = useSelector(state => state.form);
const entryRef = useRef();
const dispatch = useDispatch();
const [Tokenval,setTokenval]=useState(0);
const [cstate, cdispatch] = React.useReducer(l4Reducer, initialState )
const tableRef = useRef();
const imgRef = useRef();
const PriviewRef = useRef();
const [ImgLoading, setImgLoading] = useState();
const [FilterData,setFilterData]= useState(null);
const [MainData, setMainData] = useState('')
const screenRef = useRef();
const [Attach, setAttach] = useState([])
const [openAppr, setopenAppr] =useState(false);

useEffect(()=>{
    dispatch(tokenFunction()); 
        props.loading(true)
},[])

function tokenFunction(){
    return (dispatch) => { 
            Token(1).then(val => {
                var arr=new Array();
                arr.push(val);
                cdispatch({type:'token',payload:arr})
        setTokenval(arr.length)
        AccessRights_Select(val)
            })
        }
    }
    const AccessRights_Select = (token) => {
    AccessRightsAPI(token, 1394 ).then(res => cdispatch({type: 'AccessRights', payload: res }) )
    }


function ShowTableDiv(val){ 
    cdispatch({type: 'expandDetail', payload: 'mainpanel'})
    if(val){
         document.getElementById("PMSBuildingRegistry-MainTable").style.width = "0%";
         document.getElementById("PMSBuildingRegistry-MainEntry").style.width = "100%";
         document.getElementById("PMSBuildingRegistry-MainEntry").style.display="flex";
         document.getElementById("PMSBuildingRegistry-MainTable").style.display = "none";
         cdispatch({type: 'Showtable', payload: false});
         }else{
         document.getElementById("PMSBuildingRegistry-MainTable").style.width = "100%";
         document.getElementById("PMSBuildingRegistry-MainTable").style.display = "block";
         document.getElementById("PMSBuildingRegistry-MainEntry").style.width="0%";
         document.getElementById("PMSBuildingRegistry-MainEntry").style.display="none";
         cdispatch({type: 'Showtable', payload: true});
         tableRef.current.tableRefresh();
    }
}


function EditTable(row,draft,show){
    if(!row) {
        entryRef.current.formlink(0)
        cdispatch({type: 'ShowView',payload: false})
        ShowTableDiv(true);
        entryRef.current.clear();
    }else{
        cdispatch({type: 'ShowView',payload: true})
        cdispatch({type: 'PrimaryData',payload: row})
        if(draft){
           entryRef.current.editRecord(row,draft,false);
        }else{
           entryRef.current.editRecord(row,draft,show);
        }
        cdispatch({type: 'IsDraft',payload: draft});
        ShowTableDiv(true);
    }
 }

const openAttachments = (val) => {
imgRef.current.AttachmentData(cstate.PrimaryId)
    if(cstate.ExpandTableValue){
        document.getElementById("overlayimgAttPMSBuildingRegistry").style.width="30%";
        document.getElementById("divPMSBuildingRegistry-Entry").style.width = "100%";
        document.getElementById("PMSBuildingRegistry-MainTable").style.width="100%";
        document.getElementById("PMSBuildingRegistry-MainEntry").style.width="100%";
        document.getElementById("PMSBuildingRegistry-MainDiv").classList.remove("displayFlex");
        document.getElementById("PMSBuildingRegistry-MainDiv").classList.add("displayGrid");
        document.getElementById("overlayimgAttPMSBuildingRegistry").style.display="block";
        document.getElementById("PMSBuildingRegistryTbsearch").style.display="none";
    }else{
        document.getElementById("PMSBuildingRegistry-MainTable").style.width="40%";
        document.getElementById("divPMSBuildingRegistry-Entry").style.width = "100%";
        document.getElementById("PMSBuildingRegistry-MainEntry").style.width="100%";
        document.getElementById("PMSBuildingRegistry-MainEntry").style.display="block";
        document.getElementById("PMSBuildingRegistry-MainDiv").classList.add("displayFlex");
        document.getElementById("PMSBuildingRegistry-MainDiv").classList.remove("displayGrid");
        document.getElementById("overlayimgAttPMSBuildingRegistry").style.width = "30%"
        document.getElementById("overlayimgAttPMSBuildingRegistry").style.display="block";
        document.getElementById("PMSBuildingRegistryTbsearch").style.display="none";
    }
}
 // Img Attachment
const ImgAttachment = (val) => {
    if(cstate.IsCollapse){
        document.getElementById("PMSBuildingRegistry-MainTable").style.width="50%";
        document.getElementById("divPMSBuildingRegistry-Entry").style.width = "100%";
        document.getElementById("PMSBuildingRegistry-MainEntry").style.width="100%";
        document.getElementById("PMSBuildingRegistry-MainEntry").style.display="block";
        document.getElementById("PMSBuildingRegistry-MainDiv").classList.add("displayFlex");
        document.getElementById("PMSBuildingRegistry-MainDiv").classList.remove("displayGrid"); 
        document.getElementById("overlayimgAttPMSBuildingRegistry").style.width="0%";
        document.getElementById("overlayimgAttPMSBuildingRegistry").style.display="none";
        document.getElementById("PMSBuildingRegistryTbsearch").style.display="block";
    }else{
        document.getElementById("overlayimgAttPMSBuildingRegistry").style.width = "0%"
        document.getElementById("overlayimgAttPMSBuildingRegistry").style.display="none";
        document.getElementById("divPMSBuildingRegistry-Entry").style.width = "100%";
        document.getElementById("PMSBuildingRegistry-MainTable").style.width="100%";
        document.getElementById("PMSBuildingRegistry-MainEntry").style.width="100%";
        document.getElementById("PMSBuildingRegistry-MainDiv").classList.remove("displayFlex");
        document.getElementById("PMSBuildingRegistry-MainDiv").classList.add("displayGrid"); 
        document.getElementById("PMSBuildingRegistryTbsearch").style.display="block";
    }
}

return (
       <div>
       <PMSBuildingRegistryContext.Provider value={{
          cstate, cdispatch,
          loading: (e) => props.loading(e),
          alert: (e)=> props.alertmsg(e),
          ConfirmAlert: (val)=>props.ConfirmAlert(val),
          SlideComponentType: (e) => props.SlideComponentType(e),
          openNav: (e) => props.openNav(e),
          edit: (a,b,c) => EditTable(a,b,c),
          add: () => entryRef.current.Add(),
          editview: (r) => {entryRef.current.Editview(r);cdispatch({ type: 'expandDetail',payload: 'mainpanel'})},
          ShowTableDiv: (e) => ShowTableDiv(e),
          AttachExpand: (val) => openAttachments(val), 
          openDialog: (e) => props.openDialog(e),
          Approval: (e) => setopenAppr(e),
          DialogComponentType: (e) => props.DialogComponentType(e),
          attachmentSave: (id) => {PriviewRef.current.tempsave(id,Attach); setAttach([])},
          floatRefresh: () => screenRef.current.countRefresh(),
          IsInboxApproval: (e) => entryRef.current.IsInboxApproval(e),
       }}> 
       <div className="MainDivStyles displayGrid">
        <div id="PMSBuildingRegistry-MainDiv" className="Maincontent" style={{paddingTop: '8px',minHeight: '100%'}}>
                <div className="displayFlex width100" >
                 <div className="width100">
                   <div id="PMSBuildingRegistry-MainTable" className="commonSlide" style={{width:'100%',display:'block'}}>
                        {(Tokenval !== 0) &&
                         //  (cstate.Showtable &&
                               <PMSBuildingRegistryTable ref={tableRef}/>
                         //  )
                        }
                    </div>
                        <div className='displayFlex'>
                    <div className='width100'>
                 <PMSBuildingRegistryEntry
                       ref={entryRef}
                       clrImgstate={(e) => imgRef.current.clrImgstate(e)}
                  /> 
                        <PriviewImage 
                           ref = {PriviewRef}
                           menurefID ={1394}
                           fileId = "LogoImgPMSBuildingRegistry"
                           imgloading={(val)=>setImgLoading(val)}
                           valueIDPK = {cstate.PrimaryId}
                           AttachmentVal = {(RecordID) => imgRef.current.AttachmentData(RecordID)}
                           previd="overlayPreviewPMSBuildingRegistry"
                           AccessRights = {cstate.AccessRights}
                           frmctrlid="PvwIm_1394_L4_"
                           tempImg={(val)=>{cstate.PrimaryId ? imgRef.current.AttachmentData(cstate.PrimaryId) 
                           : imgRef.current.tempImg(val);setAttach(val)}}
                           clearTempData={cstate.Add}
                        />
                           </div> 
                        <Attachment  ImgAttachment = {(val)=>ImgAttachment(val) }
                           menurefID ={1394}
                           fileId = "AttImgPMSBuildingRegistry"
                           imgid = "overlayimgAttPMSBuildingRegistry"
                           valueIDPK = {cstate.PrimaryId}
                           PriviewData = {(url,name,size,prv)=> 
                           {PriviewRef.current.PriviewItem(url,name,size,prv)}}
                           previd="overlayPreviewPMSBuildingRegistry"
                           ref = {imgRef} 
                           imgloading={ImgLoading}
                           ConfirmAlert = {(val) => {props.ConfirmAlert(val)}}
                           frmctrlid="Imgatt_1394_L4_"
                           timglist={(val)=> PriviewRef.current.timglist(val)}
                           clearTempData={cstate.Add}
                        />
              </div>
              </div>
            </div>
         </div>
       </div>

            {openAppr && 
               <ApprDialog 
                   openDialog = {openAppr}
                   closeDialog = {(e) >= setopenAppr(e)}
                   formID = {1394}
                   PrimID = {cstate.PrimaryId}
                   alert={(e,params,stage)=>{ 
                       if(e.message == 'Approval Sent Succesfully'){ 
                          entryRef.current.cardRefresh(); 
                       } 
                   }}
                   loading = {(e) => {props.loading(e)}}
               />
            }
       </PMSBuildingRegistryContext.Provider>
       </div>
    );
});

export default PMSBuildingRegistryMain;



// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023
