﻿



// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023
// Main Imports
import 'react-infinite-calendar/styles.css';
 import React,{forwardRef, useEffect, useImperativeHandle, useRef, useState,useContext,useLayoutEffect} from 'react';
 import {withStyles } from '@material-ui/styles';
 import { useDispatch, useSelector } from "react-redux";
 import Accordion from '@material-ui/core/Accordion';
 import AccordionDetails from '@material-ui/core/AccordionDetails';
 import AccordionSummary from '@material-ui/core/AccordionSummary';
 import AppsIcon from '@material-ui/icons/Apps';
 import Badge from '@material-ui/core/Badge';
 import ShareIcon from '@material-ui/icons/Share';
 import ButtonGroup from '@material-ui/core/ButtonGroup';
 import CloseIcon from '@material-ui/icons/Close';
 import CommonAPISelect from '../../../CommonAPISelect';
 import DraftsIcon from '@material-ui/icons/Drafts';
 import  PMSBuildingRegistryDropDownComponent  from './TableFilterComponent';
 import ExpandLessIcon from '@material-ui/icons/ExpandLess';
 import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
 import Export_Print from '../../../components/_helperComponents/Export_Print.js';
 //import FilterListIcon from '@material-ui/icons/FilterList';
 import { BiFilterAlt } from 'react-icons/bi'
 import GridContainer from "../../../components/Grid/GridContainer";
 import GridItem from "../../../components/Grid/GridItem";
 import InputBase from "@material-ui/core/InputBase";
 import KeyboardBackspaceRoundedIcon from '@material-ui/icons/KeyboardBackspaceRounded';
 import {SchemaComponent,ShareComponent} from './ListViewComponent';
 import ListIcon from '@material-ui/icons/Reorder';
 import MUICheckbox from '@material-ui/core/Checkbox';
 import MUIPagination from "@material-ui/lab/Pagination";
 import MUISelect from "@material-ui/core/Select";
 import Mat_Btn from '@material-ui/core/Button';
 import MenuItem from "@material-ui/core/MenuItem";
 import SearchIcon from '@material-ui/icons/Search';
 import TableColumnOrder from '../../../components/_helperComponents/TableColumnOrder';
 import Tooltip from "@material-ui/core/Tooltip";
 import { TiMediaPauseOutline } from 'react-icons/ti'//changes
 import {config} from '../../../config.js';
 import AddBtn from '../../../components/Buttons/AddButton';
import InputSearch from '../../../components/_helperComponents/InputSearch';
import { RiArrowLeftRightFill } from 'react-icons/ri'
import {BsFillGrid3X2GapFill} from 'react-icons/bs';
import {GoThreeBars} from 'react-icons/go';
import ExpandedCardDual from '../../../components/_helperComponents/ExpandedCardComponent'
import IconButton from '@material-ui/core/IconButton';
import multilingual from '../../../components/_helperComponents/tjson/multilingual';
import { FiGrid } from 'react-icons/fi'
import { HiMenuAlt2, HiChevronDoubleRight, HiChevronDoubleLeft } from 'react-icons/hi'
import { IoIosArrowDown, IoIosArrowBack } from 'react-icons/io'
import { TbFilePencil } from 'react-icons/tb'
import { MdFormatListBulleted } from 'react-icons/md'
import { MdOutlineArrowBackIosNew } from 'react-icons/md';
import {PDF_Excel_Generate} from 'dashboard/PDF_Excel_Generate'

import Token from '../../../Token';
import CommonAPISave from '../../../CommonAPISave';
import moment from 'moment';
import ExportMigration from '../../../components/_helperComponents/ExcelMigration/ExcelMigrate'
import UserGridView from 'dashboard/UserGridView';

import MUITable from '../../../components/_helperComponents/MUITable';
import {PMSBuildingRegistryContext,ContextApi } from './MainComponent'
import TableScroll from '../../../components/_helperComponents/TableScroll';
import GridOnIcon from '@material-ui/icons/GridOn';
window.clickFilter= "";




//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Main Rendering  Function Of Table

const PMSBuildingRegistry= forwardRef((props,ref) =>{
const refPrint = useRef(null);
const migRef = useRef(null);
const MuiRef = useRef(null);
const content = useSelector(state => state.form);
const [userID] = useState(localStorage.getItem('userid'));
const [userGridViewFormID] = useState("1394")
const [IsMig,setIsMig] = useState(true)
const [Dialogview, setDialogview] = useState(false)

const [TableTotal, setTableTotal] = useState(0);
const [TableTotalCount, setTableTotalCount] = useState(0);
const [DraftCount,setDraftCount] = useState(0);
const [GridPagination, setGridPagination] = useState({current: 1, pageSize: 10}); // State for table Pagination
const [ExportData,setExportData] = useState('');
const [PrintData ,setPrintData] = useState([]);
const [Filter, setFilter] = useState({ val:'', column:'' })
const [PMSBuildingRegistryData,setPMSBuildingRegistryData]=useState([]);
const [showSearch,setShowSearch]=useState(false);  
const [searchParams,setSearchParams]=useState("");
const [CommonSearchValue,setCommonSearchValue] = useState("");
const [showColumn,setShowColumn]=useState(false); 
const [GridView, setGridView] = useState(false);
const [TableVisibleData,setTableVisibleData]=useState([]);
const [TableVisibleItem,setTableVisibleItem]=useState([]);
const [TableBodyItem,setTableBodyItem]=useState([]);
const [BubbleView,setBubbleView]=useState(false); 
const [ShareData,setShareData]=useState(
{"children":[{"name":"PMSBuildingRegistry","children":[] }]})
const [ShareView,setShareView]=useState(false);
let EmptyJson = {
PMSBuildingIDPK: "",
PMSBuilCode: "",
PMSBuilName: "",
PMSBuilNo: "",
PMSBuilArInSqFet: "",
PMSBuilLatitude: "",
PMSBuilLongitude: "",
PMSBuilCostGroup: "",
PMSBuilPermitNo: "",
PMSBuilConfig: "",
PMSBuilMakaniNo: "",
PMSBuilDMNo: "",
PMSBuilNoOfFlor: "",
PMSBuilNoOfPark: "",
PMSBuilNoOfUnit: "",
PMSBuilBUPArea: "",
PMSBuilLeasArea: "",
PMSBuilConsDateTime: "",
PMSBuilConsDateTimeType: "",
PMSBuilConsDateTimeBetween: "",
PMSBuilHODateTime: "",
PMSBuilHODateTimeType: "",
PMSBuilHODateTimeBetween: "",
PMSBuilTenanDateTime: "",
PMSBuilTenanDateTimeType: "",
PMSBuilTenanDateTimeBetween: "",
PMSBuilGraPeriInMons: "",
PMSBuilLeasDateTime: "",
PMSBuilLeasDateTimeType: "",
PMSBuilLeasDateTimeBetween: "",
PMSBuilDescription: "",
BuildingKey: "",
IsDraft: "",
Remarks: "",
LocalityID: "",
OrganisationID: "",
CountryID: "",
RegionID: "",
PMSBuildingComID: "",
AssBuildingTypeID: "",
PMSLandLordID: "",
EmployeeID: "",
EmployeeID1: "",
IsActive: "",
DeleStat: "",
CreatedUserID: "",
CreatedTtm: "",
CreatedTtmType: "",
CreatedTtmBetween: "",
UpdatedTtm: "",
LocalityGroupID: "",
LocalityGroupCode: "",
LocalityGroupName: "",
CityID: "",
CityCode: "",
CityName: "",
AdminLocalityTypeID: "",
AdminLocalityTypeCode: "",
AdminLocalityTypeName: "",
LocalityCode: "",
LocalityName: "",
OrganisationCode: "",
OrganisationName: "",
CountryCode: "",
CountryName: "",
RegionCode: "",
RegionName: "",
PMSBuildingComCode: "",
PMSBuildingComName: "",
AssBuildingTypeCode: "",
AssBuildingTypeName: "",
ShiftID: "",
ShiftCode: "",
ShiftName: "",
ClassificationID: "",
ClassificationCode: "",
ClassificationName: "",
DepartmentID: "",
DepartmentCode: "",
DepartmentName: "",
DesignationID: "",
DesignationCode: "",
DesignationName: "",
NationalityID: "",
NationalityCode: "",
NationalityName: "",
EmpWorkNatureID: "",
NatureOfWorkCode: "",
NatureOfWorkName: "",
EmployeeTypeID: "",
EmployeeTypeCode: "",
EmployeeTypeName: "",
EmploymentTypeID: "",
EmploymentTypCode: "",
EmploymentTypeName: "",
EmployeeGroupID: "",
EmployeeGroupCode: "",
EmployeeGroupName: "",
EmpGradeID: "",
EmpGradeCode: "",
EmpGradeName: "",
EmpGenderID: "",
EmpGenderName: "",
EmpTitleID: "",
EmpTitleName: "",
EmployeeCode: "",
FirstName: "",
EmpContactNo1: "",
EmpEmailOfficial: "",
PageIndex: "",
PageSize: "",
Type: "",
OrderByType: "",
SortOrder: "",
UserGroupKey: "",
UserAccessKey: "",
}
const [JsonWithValue,setJsonWithValue]=useState(EmptyJson);
const [GridViewSearchJson, setGridViewSearchJson] = useState(EmptyJson);
const [BubbleSearchJson, setBubbleSearchJson] = useState(EmptyJson);
const [ShareSearchJson, setShareSearchJson] = useState(EmptyJson);
const [order, setOrder] = useState('asc');
const [orderBy, setOrderBy] = useState('');
const [IsDraft,setIsDraft] = useState(false);
const [expanded, setExpanded] = useState(true);
const [ExpandView,setExpandView]=useState(false);
const [CardTableView,setCardTableView]=useState(true);
const [TableSearchParams,setTableSearchParams]=useState({"PMSBuilCode":"","PMSBuilName":"","PMSBuilNo":"","PMSBuilArInSqFet":"","LocalityName":"","CountryName":"","RegionName":"","PMSBuilLatitude":"","PMSBuilLongitude":"","OrganisationName":"","AssBuildingTypeName":"","PMSBuildingComName":"","PMSLLdName":"","PMSBuilCostGroup":"","PMSBuilPermitNo":"","FirstName":"","FirstName1":"","PMSBuilConfig":"","PMSBuilMakaniNo":"","PMSBuilDMNo":"","PMSBuilNoOfFlor":"","PMSBuilNoOfPark":"","PMSBuilNoOfUnit":"","PMSBuilBUPArea":"","PMSBuilLeasArea":"","PMSBuilConsDateTime":"","PMSBuilHODateTime":"","PMSBuilTenanDateTime":"","PMSBuilLeasDateTime":"","PMSBuilGraPeriInMons":"","PMSBuilDescription":"","BuildingKey":"",});
const context = useContext(props.context ? props.context :PMSBuildingRegistryContext);
const {cstate , cdispatch} = props.ContextApi ? props.ContextApi : ContextApi();
const [showTableScroll,setShowTableScroll]=useState(false);
const [PMSBuildingRegistryScrollData,setPMSBuildingRegistryScrollData]=useState([]);
const [TableScrollTotal, setTableScrollTotal] = useState(0);
const [TableScrollTotalCount, setTableScrollTotalCount] = useState(0);
const [ScrollGridPagination, setScrollGridPagination] = useState({current: 1, pageSize: 10});
const [columnIndex,setColumnIndex] = useState([]);
const [Items,setItems] = useState([]);
const [CardModelView,setCardModelView]=useState(false);

const [Lang] = useState(localStorage.getItem('Language'));
const [FormLang] = useState(localStorage.getItem('Language'));
const [More, setMore] = useState(false);
const [userGrid, setUserGrid] = UserGridView('1394')
const [GridViewShow, setGridViewShow] = useState(false)
const [userGridViewMigFormID] = useState("0")
const [MigTableVisibleItem,setMigTableVisibleItem]=useState([]);
const [MigTableBodyItem,setMigTableBodyItem]=useState([]);// Table Search
let columnSearch = {"PMSBuilCode":"","PMSBuilName":"","PMSBuilNo":"","PMSBuilArInSqFet":"","LocalityName":"","CountryName":"","RegionName":"","PMSBuilLatitude":"","PMSBuilLongitude":"","OrganisationName":"","AssBuildingTypeName":"","PMSBuildingComName":"","PMSLLdName":"","PMSBuilCostGroup":"","PMSBuilPermitNo":"","FirstName":"","FirstName1":"","PMSBuilConfig":"","PMSBuilMakaniNo":"","PMSBuilDMNo":"","PMSBuilNoOfFlor":"","PMSBuilNoOfPark":"","PMSBuilNoOfUnit":"","PMSBuilBUPArea":"","PMSBuilLeasArea":"","PMSBuilConsDateTime":"","PMSBuilHODateTime":"","PMSBuilTenanDateTime":"","PMSBuilLeasDateTime":"","PMSBuilGraPeriInMons":"","PMSBuilDescription":"","BuildingKey":"",};
// Excel Export
const exportData = [
     {
         columns: columnIndex ,
         data:   ExportData
     }
     ];

let lang = multilingual();
const t = (e) =>  lang?.[e] ? lang[e] : e ;
const tf = (e) =>  cstate.language?.[e] ? cstate.language[e] : e ;

       useEffect(() => {
               VisibleItemSelect(userGrid);
               MigVisibleItemSelect(userGrid);
           }, [userGrid]);
// Onload data fetch for table

useEffect(() => {
    if(!GridView && !BubbleView && !ShareView){
        setJsonWithValue(searchParams)
        if(cstate.token.length > 0){
           searchData(GridPagination, searchParams,"PMSBuildingID");
        }
    }else if(GridView){
        setGridViewSearchJson(searchParams)
    }else if(BubbleView){
        setBubbleSearchJson(searchParams)
    }else if(ShareView){ 
        setShareSearchJson(searchParams);
    }
},[searchParams]);
useEffect(() => {
    if(props.cardview === false){
        setCardTableView(props.cardview);
    }
    if(props.Dialogview){
                setDialogview(props.Dialogview)
    }
},[props.cardview, props.Dialogview]);
useEffect(() => {
       if(props.searchsafaritext) CommonSearchFunction(props.searchsafaritext,{current:GridPagination.current,pageSize:GridPagination.pageSize});
}, [props.searchsafaritext]);

useImperativeHandle(ref, () => ({
   searchItem: (data) => {
       CommonSearchFunction(data,{current:1,pageSize:10});
},
tableRefresh: () => {
//if(IsDraft){ 
//     searchData(GridPagination,EmptyJson,"DraftPMSBuildingID");
//  }else{   
     searchData(GridPagination,EmptyJson,"PMSBuildingID");
// }
}
}));


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Fetch Data for Table
   const searchData = (param, val,type,idpk,show) => {
   //    document.getElementsByClassName("menuSearch")[0].getElementsByTagName("button")[0].click();
           context.loading(true);
           let url = config.Api + "FP1394S3/";
           let params = {
           "data": {
                       "p1": idpk ? idpk : val && val.PMSBuildingIDPK ? val.PMSBuildingIDPK : null
               ,"p2": val && val.PMSBuilCode ? val.PMSBuilCode : null
               ,"p3": val && val.PMSBuilName ? val.PMSBuilName : null
               ,"p4": val && val.PMSBuilNo ? val.PMSBuilNo : null
               ,"p5": val && val.PMSBuilArInSqFet ? val.PMSBuilArInSqFet : null
               ,"p6": val && val.PMSBuilLatitude ? val.PMSBuilLatitude : null
               ,"p7": val && val.PMSBuilLongitude ? val.PMSBuilLongitude : null
               ,"p8": val && val.PMSBuilCostGroup ? val.PMSBuilCostGroup : null
               ,"p9": val && val.PMSBuilPermitNo ? val.PMSBuilPermitNo : null
               ,"p10": val && val.PMSBuilConfig ? val.PMSBuilConfig : null
               ,"p11": val && val.PMSBuilMakaniNo ? val.PMSBuilMakaniNo : null
               ,"p12": val && val.PMSBuilDMNo ? val.PMSBuilDMNo : null
               ,"p13": val && val.PMSBuilNoOfFlor ? val.PMSBuilNoOfFlor : null
               ,"p14": val && val.PMSBuilNoOfPark ? val.PMSBuilNoOfPark : null
               ,"p15": val && val.PMSBuilNoOfUnit ? val.PMSBuilNoOfUnit : null
               ,"p16": val && val.PMSBuilBUPArea ? val.PMSBuilBUPArea : null
               ,"p17": val && val.PMSBuilLeasArea ? val.PMSBuilLeasArea : null
               ,"p18": val && val.PMSBuilConsDateTime ? val.PMSBuilConsDateTime : null
               ,"p19": val && val.PMSBuilConsDateTimeType ? val.PMSBuilConsDateTimeType : null
               ,"p20": val && val.PMSBuilConsDateTimeBetween ? val.PMSBuilConsDateTimeBetween : null
               ,"p21": val && val.PMSBuilHODateTime ? val.PMSBuilHODateTime : null
               ,"p22": val && val.PMSBuilHODateTimeType ? val.PMSBuilHODateTimeType : null
               ,"p23": val && val.PMSBuilHODateTimeBetween ? val.PMSBuilHODateTimeBetween : null
               ,"p24": val && val.PMSBuilTenanDateTime ? val.PMSBuilTenanDateTime : null
               ,"p25": val && val.PMSBuilTenanDateTimeType ? val.PMSBuilTenanDateTimeType : null
               ,"p26": val && val.PMSBuilTenanDateTimeBetween ? val.PMSBuilTenanDateTimeBetween : null
               ,"p27": val && val.PMSBuilGraPeriInMons ? val.PMSBuilGraPeriInMons : null
               ,"p28": val && val.PMSBuilLeasDateTime ? val.PMSBuilLeasDateTime : null
               ,"p29": val && val.PMSBuilLeasDateTimeType ? val.PMSBuilLeasDateTimeType : null
               ,"p30": val && val.PMSBuilLeasDateTimeBetween ? val.PMSBuilLeasDateTimeBetween : null
               ,"p31": val && val.PMSBuilDescription ? val.PMSBuilDescription : null
               ,"p32": val && val.BuildingKey ? val.BuildingKey : null
               ,"p33": type == "DraftPMSBuildingID" ? "1" : "0"
               ,"p34": null
               ,"p35": val && val.LocalityID ? val.LocalityID : null
               ,"p36": val && val.OrganisationID ? val.OrganisationID : null
               ,"p37": val && val.CountryID ? val.CountryID : null
               ,"p38": val && val.RegionID ? val.RegionID : null
               ,"p39": val && val.PMSBuildingComID ? val.PMSBuildingComID : null
               ,"p40": val && val.AssBuildingTypeID ? val.AssBuildingTypeID : null
               ,"p41": val && val.PMSLandLordID ? val.PMSLandLordID : null
               ,"p42": val && val.EmployeeID ? val.EmployeeID : null
               ,"p43": val && val.EmployeeID1 ? val.EmployeeID1 : null
               ,"p44": props.Dialogview ? "1" : null
               ,"p45": null
               ,"p46": val && val.CreatedUserID_varchar ? val.CreatedUserID_varchar : null
               ,"p47": val && val.CreatedTtm ? val.CreatedTtm : null
               ,"p48": val && val.CreatedTtmType ? val.CreatedTtmType : null
               ,"p49": val && val.CreatedTtmBetween ? val.CreatedTtmBetween : null
               ,"p50": null
               ,"p51": val && val.LocalityGroupID ? val.LocalityGroupID : null
               ,"p52": val && val.LocalityGroupCode ? val.LocalityGroupCode : null
               ,"p53": val && val.LocalityGroupName ? val.LocalityGroupName : null
               ,"p54": val && val.CityID ? val.CityID : null
               ,"p55": val && val.CityCode ? val.CityCode : null
               ,"p56": val && val.CityName ? val.CityName : null
               ,"p57": val && val.AdminLocalityTypeID ? val.AdminLocalityTypeID : null
               ,"p58": val && val.AdminLocalityTypeCode ? val.AdminLocalityTypeCode : null
               ,"p59": val && val.AdminLocalityTypeName ? val.AdminLocalityTypeName : null
               ,"p60": val && val.LocalityCode ? val.LocalityCode : null
               ,"p61": val && val.LocalityName ? val.LocalityName : null
               ,"p62": val && val.OrganisationCode ? val.OrganisationCode : null
               ,"p63": val && val.OrganisationName ? val.OrganisationName : null
               ,"p64": val && val.CountryCode ? val.CountryCode : null
               ,"p65": val && val.CountryName ? val.CountryName : null
               ,"p66": val && val.RegionCode ? val.RegionCode : null
               ,"p67": val && val.RegionName ? val.RegionName : null
               ,"p68": val && val.PMSBuildingComCode ? val.PMSBuildingComCode : null
               ,"p69": val && val.PMSBuildingComName ? val.PMSBuildingComName : null
               ,"p70": val && val.AssBuildingTypeCode ? val.AssBuildingTypeCode : null
               ,"p71": val && val.AssBuildingTypeName ? val.AssBuildingTypeName : null
               ,"p72": val && val.ShiftID ? val.ShiftID : null
               ,"p73": val && val.ShiftCode ? val.ShiftCode : null
               ,"p74": val && val.ShiftName ? val.ShiftName : null
               ,"p75": val && val.ClassificationID ? val.ClassificationID : null
               ,"p76": val && val.ClassificationCode ? val.ClassificationCode : null
               ,"p77": val && val.ClassificationName ? val.ClassificationName : null
               ,"p78": val && val.DepartmentID ? val.DepartmentID : null
               ,"p79": val && val.DepartmentCode ? val.DepartmentCode : null
               ,"p80": val && val.DepartmentName ? val.DepartmentName : null
               ,"p81": val && val.DesignationID ? val.DesignationID : null
               ,"p82": val && val.DesignationCode ? val.DesignationCode : null
               ,"p83": val && val.DesignationName ? val.DesignationName : null
               ,"p84": val && val.NationalityID ? val.NationalityID : null
               ,"p85": val && val.NationalityCode ? val.NationalityCode : null
               ,"p86": val && val.NationalityName ? val.NationalityName : null
               ,"p87": val && val.EmpWorkNatureID ? val.EmpWorkNatureID : null
               ,"p88": val && val.NatureOfWorkCode ? val.NatureOfWorkCode : null
               ,"p89": val && val.NatureOfWorkName ? val.NatureOfWorkName : null
               ,"p90": val && val.EmployeeTypeID ? val.EmployeeTypeID : null
               ,"p91": val && val.EmployeeTypeCode ? val.EmployeeTypeCode : null
               ,"p92": val && val.EmployeeTypeName ? val.EmployeeTypeName : null
               ,"p93": val && val.EmploymentTypeID ? val.EmploymentTypeID : null
               ,"p94": val && val.EmploymentTypCode ? val.EmploymentTypCode : null
               ,"p95": val && val.EmploymentTypeName ? val.EmploymentTypeName : null
               ,"p96": val && val.EmployeeGroupID ? val.EmployeeGroupID : null
               ,"p97": val && val.EmployeeGroupCode ? val.EmployeeGroupCode : null
               ,"p98": val && val.EmployeeGroupName ? val.EmployeeGroupName : null
               ,"p99": val && val.EmpGradeID ? val.EmpGradeID : null
               ,"p100": val && val.EmpGradeCode ? val.EmpGradeCode : null
               ,"p101": val && val.EmpGradeName ? val.EmpGradeName : null
               ,"p102": val && val.EmpGenderID ? val.EmpGenderID : null
               ,"p103": val && val.EmpGenderName ? val.EmpGenderName : null
               ,"p104": val && val.EmpTitleID ? val.EmpTitleID : null
               ,"p105": val && val.EmpTitleName ? val.EmpTitleName : null
               ,"p106": val && val.EmployeeCode ? val.EmployeeCode : null
               ,"p107": val && val.FirstName ? val.FirstName : null
               ,"p108": val && val.EmpContactNo1 ? val.EmpContactNo1 : null
               ,"p109": val && val.EmpEmailOfficial ? val.EmpEmailOfficial : null
             ,"p110":  idpk ? 1 : param.current
             ,"p111": param.pageSize
             ,"p112": type
               ,"p113": null
               ,"p114": null
               ,"p115": localStorage.getItem('UserGroupID')
               ,"p116": localStorage.getItem('userid')
        }
   }

   CommonAPISelect(url,params,cstate.token[0])
   .then(res => {
   if(res.Output.status.code == "200"){
     if(res.Output.data.length > 0){
           if(res.Output.data){
               let result = res.Output.data.length;
               let totalRow = 0;
               if(result > 0){
                    totalRow = parseFloat(res.Output.data[0].TotalCount , 10)/10;  
                    setTableTotalCount(res.Output.data[0].TotalCount)
                    cdispatch({type:'count', payload: res.Output.data[0].TotalCount})
                    setDraftCount(res.Output.data[0].DraftCnt);
               }else{
                       totalRow = 0;
                       setTableTotalCount(0)
                       cdispatch({type:'count', payload: 0})
                       setDraftCount(0);
               }
        if(param.pageSize == 10){
             setTableTotal(Math.ceil(totalRow));
         }else if(param.pageSize == 20){
             setTableTotal(Math.ceil(totalRow/2));
         }else if(param.pageSize == 50){
             setTableTotal(Math.ceil(totalRow/5));
         }else if(param.pageSize == 100){
             setTableTotal(Math.ceil(totalRow/10));
         }
         setPMSBuildingRegistryData(res.Output.data);
         context.loading(false);
         //document.getElementById('PMSBuildingRegistry-MainEntry').style.display = 'none';
    }
    if(type ==="DraftPMSBuildingID"){ 
    setIsDraft(true);  
    setShowColumn(false)
    }
       else{
           setIsDraft(false);
    }
    }else{
        if(type === "DraftPMSBuildingID"){
                   context.alert({open: true,color:"warning",message: ['There is no Record Found']});
                    setShowColumn(true);
                    setIsDraft(false);
                    context.loading(false);
            }else{
                    setIsDraft(false);
                    setPMSBuildingRegistryData([]);
                    setGridPagination({current: 1, pageSize: 10});
                    setTableTotal(0);
                    setTableTotalCount(0);
                    //setDraftCount(0);
                    context.loading(false);
               if (Object.values(val).some(e => e)){
                    context.alert({open: true,color:"warning",message: ['There is no Record Found']});
                    document.getElementById('PMSBuildingRegistry-MainTable').style.display = 'block';
                    }
            }
        }
     }
       else{
           context.alert({open: true,color:'warning',message: [res.Output.status.message]});
           context.loading(false);
     }
   }); 
 }
 const ToggleFilterView =() =>{
     if(!showSearch){
           document.getElementById("PMSBuildingRegistryFilterDiv").style.width = "25%";
           document.getElementById("PMSBuildingRegistryTabDiv").style.width = "75%";
           document.getElementById("PMSBuildingRegistryFilterDiv").style.display = "block";
           setShowSearch(true);
               if(!GridView){
                   if(!CardTableView){
                     document.getElementById("PMSBuildingRegistryfildiv").style.width = 'fit-content';
                     document.getElementById("PMSBuildingRegistryfildiv").getElementsByTagName('svg')[0].style.padding = '4px'
                   } else {
                     if(!BubbleView){
                        document.getElementById("PMSBuildingRegistrycoldiv").style.width = 'fit-content';
                        document.getElementById("PMSBuildingRegistrycoldiv").getElementsByTagName('svg')[0].style.padding = '4px'
                        document.getElementById("PMSBuildingRegistryfildiv").style.width = 'fit-content';
                        document.getElementById("PMSBuildingRegistryfildiv").getElementsByTagName('svg')[0].style.padding = '4px'
                      }else{
                        document.getElementById("PMSBuildingRegistryfildiv").style.width = 'fit-content';
                        document.getElementById("PMSBuildingRegistryfildiv").getElementsByTagName('svg')[0].style.padding = '4px'
                      }
                      }
                           }else{
                               document.getElementById("PMSBuildingRegistryfildiv").style.width = 'fit-content';
                               document.getElementById("PMSBuildingRegistryfildiv").getElementsByTagName('svg')[0].style.padding = '4px'
                           }
                                }else{
                                    document.getElementById("PMSBuildingRegistryFilterDiv").style.width = "0%";
                                    document.getElementById("PMSBuildingRegistryTabDiv").style.width = "100%";
                                    document.getElementById("PMSBuildingRegistryFilterDiv").style.display = "none";
                                    setShowSearch(false);
                                     if(!GridView){
                                            if(!CardTableView){
                                               document.getElementById("PMSBuildingRegistryfildiv").style.width = 'fit-content';
                                               document.getElementById("PMSBuildingRegistryfildiv").getElementsByTagName('svg')[0].style.padding = '4px'
                                           } else {
                                                   if(!BubbleView){
                                                       document.getElementById("PMSBuildingRegistrycoldiv").style.width = 'fit-content';
                                                       document.getElementById("PMSBuildingRegistrycoldiv").getElementsByTagName('svg')[0].style.padding = '4px'
                                                       document.getElementById("PMSBuildingRegistryfildiv").style.width = 'fit-content';
                                                       document.getElementById("PMSBuildingRegistryfildiv").getElementsByTagName('svg')[0].style.padding = '4px'
                                                   }else{
                                                       document.getElementById("PMSBuildingRegistryfildiv").style.width = 'fit-content';
                                                       document.getElementById("PMSBuildingRegistryfildiv").getElementsByTagName('svg')[0].style.padding = '4px'
                                                   }
                                           }
                                      }else{
                                           document.getElementById("PMSBuildingRegistryfildiv").style.width = 'fit-content';
                                           document.getElementById("PMSBuildingRegistryfildiv").getElementsByTagName('svg')[0].style.padding = '4px'
                                      }
                                }
                                setShowColumn(false);
                                window.clickFilter = showSearch ? false : true ;
                                  }

 const ToggleFilterDataIsAdd = () => { 
    if (!showColumn) {
        document.getElementById("PMSBuildingRegistryFilterDiv").style.width = "25%";
        document.getElementById("PMSBuildingRegistryTabDiv").style.width = "75%";
        document.getElementById("PMSBuildingRegistryFilterDiv").style.display = "block";
        document.getElementById("PMSBuildingRegistryfildiv").style.width = "fit-content";
        document.getElementById("PMSBuildingRegistryfildiv").getElementsByTagName('svg')[0].style.padding = '4px'
        document.getElementById("PMSBuildingRegistrycoldiv").style.width = "fit-content";
        document.getElementById("PMSBuildingRegistrycoldiv").getElementsByTagName('svg')[0].style.padding = '4px'
        setShowColumn(true);
    } else {
        document.getElementById("PMSBuildingRegistryFilterDiv").style.width = "0%";
        document.getElementById("PMSBuildingRegistryTabDiv").style.width = "100%";
        document.getElementById("PMSBuildingRegistryFilterDiv").style.display = "none";
        document.getElementById("PMSBuildingRegistrycoldiv").style.width = "fit-content";
        document.getElementById("PMSBuildingRegistrycoldiv").getElementsByTagName('svg')[0].style.padding = '4px'
        setShowColumn(false);
    }
    setShowSearch(false);
 }


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// get All data for Print and Excel export functions
   const getAllDataPrint = (val, column,idpk,show,file) =>{
           if(TableTotalCount === 0){
               context.alert({open: true,color:'warning', message: ['There is no Record Found']});
               return false
           }
           columnSearch[column] = val;  
           context.loading(true);
           let url = config.Api + "FP1394S3/";
           let params = {
           "data": {
            "p1": idpk ? idpk : val && val.PMSBuildingIDPK ? val.PMSBuildingIDPK : null
               ,"p2": val && val.PMSBuilCode ? val.PMSBuilCode : null
               ,"p3": val && val.PMSBuilName ? val.PMSBuilName : null
               ,"p4": val && val.PMSBuilNo ? val.PMSBuilNo : null
               ,"p5": val && val.PMSBuilArInSqFet ? val.PMSBuilArInSqFet : null
               ,"p6": val && val.PMSBuilLatitude ? val.PMSBuilLatitude : null
               ,"p7": val && val.PMSBuilLongitude ? val.PMSBuilLongitude : null
               ,"p8": val && val.PMSBuilCostGroup ? val.PMSBuilCostGroup : null
               ,"p9": val && val.PMSBuilPermitNo ? val.PMSBuilPermitNo : null
               ,"p10": val && val.PMSBuilConfig ? val.PMSBuilConfig : null
               ,"p11": val && val.PMSBuilMakaniNo ? val.PMSBuilMakaniNo : null
               ,"p12": val && val.PMSBuilDMNo ? val.PMSBuilDMNo : null
               ,"p13": val && val.PMSBuilNoOfFlor ? val.PMSBuilNoOfFlor : null
               ,"p14": val && val.PMSBuilNoOfPark ? val.PMSBuilNoOfPark : null
               ,"p15": val && val.PMSBuilNoOfUnit ? val.PMSBuilNoOfUnit : null
               ,"p16": val && val.PMSBuilBUPArea ? val.PMSBuilBUPArea : null
               ,"p17": val && val.PMSBuilLeasArea ? val.PMSBuilLeasArea : null
               ,"p18": val && val.PMSBuilConsDateTime ? val.PMSBuilConsDateTime : null
               ,"p19": val && val.PMSBuilConsDateTimeType ? val.PMSBuilConsDateTimeType : null
               ,"p20": val && val.PMSBuilConsDateTimeBetween ? val.PMSBuilConsDateTimeBetween : null
               ,"p21": val && val.PMSBuilHODateTime ? val.PMSBuilHODateTime : null
               ,"p22": val && val.PMSBuilHODateTimeType ? val.PMSBuilHODateTimeType : null
               ,"p23": val && val.PMSBuilHODateTimeBetween ? val.PMSBuilHODateTimeBetween : null
               ,"p24": val && val.PMSBuilTenanDateTime ? val.PMSBuilTenanDateTime : null
               ,"p25": val && val.PMSBuilTenanDateTimeType ? val.PMSBuilTenanDateTimeType : null
               ,"p26": val && val.PMSBuilTenanDateTimeBetween ? val.PMSBuilTenanDateTimeBetween : null
               ,"p27": val && val.PMSBuilGraPeriInMons ? val.PMSBuilGraPeriInMons : null
               ,"p28": val && val.PMSBuilLeasDateTime ? val.PMSBuilLeasDateTime : null
               ,"p29": val && val.PMSBuilLeasDateTimeType ? val.PMSBuilLeasDateTimeType : null
               ,"p30": val && val.PMSBuilLeasDateTimeBetween ? val.PMSBuilLeasDateTimeBetween : null
               ,"p31": val && val.PMSBuilDescription ? val.PMSBuilDescription : null
               ,"p32": val && val.BuildingKey ? val.BuildingKey : null
               ,"p33": IsDraft ? "1" : "0"
               ,"p34": null
               ,"p35": val && val.LocalityID ? val.LocalityID : null
               ,"p36": val && val.OrganisationID ? val.OrganisationID : null
               ,"p37": val && val.CountryID ? val.CountryID : null
               ,"p38": val && val.RegionID ? val.RegionID : null
               ,"p39": val && val.PMSBuildingComID ? val.PMSBuildingComID : null
               ,"p40": val && val.AssBuildingTypeID ? val.AssBuildingTypeID : null
               ,"p41": val && val.PMSLandLordID ? val.PMSLandLordID : null
               ,"p42": val && val.EmployeeID ? val.EmployeeID : null
               ,"p43": val && val.EmployeeID1 ? val.EmployeeID1 : null
               ,"p44": props.Dialogview ? "1" : null
               ,"p45": null
               ,"p46": val && val.CreatedUserID_varchar ? val.CreatedUserID_varchar : null
               ,"p47": val && val.CreatedTtm ? val.CreatedTtm : null
               ,"p48": val && val.CreatedTtmType ? val.CreatedTtmType : null
               ,"p49": val && val.CreatedTtmBetween ? val.CreatedTtmBetween : null
               ,"p50": null
               ,"p51": val && val.LocalityGroupID ? val.LocalityGroupID : null
               ,"p52": val && val.LocalityGroupCode ? val.LocalityGroupCode : null
               ,"p53": val && val.LocalityGroupName ? val.LocalityGroupName : null
               ,"p54": val && val.CityID ? val.CityID : null
               ,"p55": val && val.CityCode ? val.CityCode : null
               ,"p56": val && val.CityName ? val.CityName : null
               ,"p57": val && val.AdminLocalityTypeID ? val.AdminLocalityTypeID : null
               ,"p58": val && val.AdminLocalityTypeCode ? val.AdminLocalityTypeCode : null
               ,"p59": val && val.AdminLocalityTypeName ? val.AdminLocalityTypeName : null
               ,"p60": val && val.LocalityCode ? val.LocalityCode : null
               ,"p61": val && val.LocalityName ? val.LocalityName : null
               ,"p62": val && val.OrganisationCode ? val.OrganisationCode : null
               ,"p63": val && val.OrganisationName ? val.OrganisationName : null
               ,"p64": val && val.CountryCode ? val.CountryCode : null
               ,"p65": val && val.CountryName ? val.CountryName : null
               ,"p66": val && val.RegionCode ? val.RegionCode : null
               ,"p67": val && val.RegionName ? val.RegionName : null
               ,"p68": val && val.PMSBuildingComCode ? val.PMSBuildingComCode : null
               ,"p69": val && val.PMSBuildingComName ? val.PMSBuildingComName : null
               ,"p70": val && val.AssBuildingTypeCode ? val.AssBuildingTypeCode : null
               ,"p71": val && val.AssBuildingTypeName ? val.AssBuildingTypeName : null
               ,"p72": val && val.ShiftID ? val.ShiftID : null
               ,"p73": val && val.ShiftCode ? val.ShiftCode : null
               ,"p74": val && val.ShiftName ? val.ShiftName : null
               ,"p75": val && val.ClassificationID ? val.ClassificationID : null
               ,"p76": val && val.ClassificationCode ? val.ClassificationCode : null
               ,"p77": val && val.ClassificationName ? val.ClassificationName : null
               ,"p78": val && val.DepartmentID ? val.DepartmentID : null
               ,"p79": val && val.DepartmentCode ? val.DepartmentCode : null
               ,"p80": val && val.DepartmentName ? val.DepartmentName : null
               ,"p81": val && val.DesignationID ? val.DesignationID : null
               ,"p82": val && val.DesignationCode ? val.DesignationCode : null
               ,"p83": val && val.DesignationName ? val.DesignationName : null
               ,"p84": val && val.NationalityID ? val.NationalityID : null
               ,"p85": val && val.NationalityCode ? val.NationalityCode : null
               ,"p86": val && val.NationalityName ? val.NationalityName : null
               ,"p87": val && val.EmpWorkNatureID ? val.EmpWorkNatureID : null
               ,"p88": val && val.NatureOfWorkCode ? val.NatureOfWorkCode : null
               ,"p89": val && val.NatureOfWorkName ? val.NatureOfWorkName : null
               ,"p90": val && val.EmployeeTypeID ? val.EmployeeTypeID : null
               ,"p91": val && val.EmployeeTypeCode ? val.EmployeeTypeCode : null
               ,"p92": val && val.EmployeeTypeName ? val.EmployeeTypeName : null
               ,"p93": val && val.EmploymentTypeID ? val.EmploymentTypeID : null
               ,"p94": val && val.EmploymentTypCode ? val.EmploymentTypCode : null
               ,"p95": val && val.EmploymentTypeName ? val.EmploymentTypeName : null
               ,"p96": val && val.EmployeeGroupID ? val.EmployeeGroupID : null
               ,"p97": val && val.EmployeeGroupCode ? val.EmployeeGroupCode : null
               ,"p98": val && val.EmployeeGroupName ? val.EmployeeGroupName : null
               ,"p99": val && val.EmpGradeID ? val.EmpGradeID : null
               ,"p100": val && val.EmpGradeCode ? val.EmpGradeCode : null
               ,"p101": val && val.EmpGradeName ? val.EmpGradeName : null
               ,"p102": val && val.EmpGenderID ? val.EmpGenderID : null
               ,"p103": val && val.EmpGenderName ? val.EmpGenderName : null
               ,"p104": val && val.EmpTitleID ? val.EmpTitleID : null
               ,"p105": val && val.EmpTitleName ? val.EmpTitleName : null
               ,"p106": val && val.EmployeeCode ? val.EmployeeCode : null
               ,"p107": val && val.FirstName ? val.FirstName : null
               ,"p108": val && val.EmpContactNo1 ? val.EmpContactNo1 : null
               ,"p109": val && val.EmpEmailOfficial ? val.EmpEmailOfficial : null
             ,"p110":  GridPagination.current
             ,"p111": TableTotalCount
             ,"p112": IsDraft ? "DraftPMSBuildingID" : "PMSBuildingID"
               ,"p113": null
               ,"p114": null
               ,"p115": localStorage.getItem('UserGroupID')
               ,"p116": localStorage.getItem('userid')
             }
           }
           context.loading(false);
           context.alert({ open: true, color: 'success', message: [`${tf(1394)} - Exports In Process, Once you have downloaded the file, you will be notified.`] }); 
               CommonAPISelect(url,params,cstate.token[0],file)
               .then(res => {
                PDF_Excel_Generate(res, context, Items, setExportData, refPrint,file)
           });
           }


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// CommonSearchFunction 
  function CommonSearchFunction(e,param){
  context.loading(true);
  const url = config.Api +"FP1394S4/";
  const params = {
    "data":
    {
    "p1": "%"+e+"%",
"p2": '0',
    "p3": IsDraft ? "1" : "0",
    "p4": param.current,
    "p5": param.pageSize,
    "p6": localStorage.getItem('UserGroupID'),
    "p7": localStorage.getItem('userid')
    }
  }
  CommonAPISelect(url,params,cstate.token[0])
  .then((res)=>{ 
      if(res.Output.status.code == "200"){
          if(res.Output.data.length > 0){
              let result = res.Output.data.length;
              let totalRow = 0;
              if(result > 0){
                totalRow = parseFloat(res.Output.data[0].TotalCount , 10)/10;
                setTableTotalCount(res.Output.data[0].TotalCount) 
                setDraftCount(res.Output.data[0].DraftCnt);
                }else{
                       totalRow = 0;
                       setTableTotalCount(0)
                       setDraftCount(0)
               }
             if(param.pageSize == 10){
                       setTableTotal(Math.ceil(totalRow));
             }else if(param.pageSize == 20){
                       setTableTotal(Math.ceil(totalRow/2));
             }else if(param.pageSize == 50){
                       setTableTotal(Math.ceil(totalRow/5));
             }else if(param.pageSize == 100){
                       setTableTotal(Math.ceil(totalRow/10));
             }
              setPMSBuildingRegistryData(res.Output.data);
                           var cells = document.querySelectorAll("#PMSBuildingRegistryTable td");
                           for(var i = 0; i < cells.length; ++i){
                               cells.forEach(function(elem,i){
                                   if(elem.textContent.toLowerCase().includes(CommonSearchValue.toLowerCase()) && (CommonSearchValue.length > 0)){
                                     elem.style.color = "#ffa502";
                           }
                   }); 
               }
               context.loading(false);
               }else{
                           setPMSBuildingRegistryData([]);
                           setGridPagination({current: 1, pageSize: 10});
                           setTableTotal(0);
                           setTableTotalCount(0);
                           setDraftCount(0);
                           context.loading(false);
                           context.alert({open: true,color:"warning",message: ['There is no Record Found']});
                           context.loading(false);
          }
      }
    else{
           context.alert({open: true,color:'warning',message: [res.Output.status.message]});
           context.loading(false);
     }
  });
}


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// Grid View & List View Function 
       function TableView(type){
    if(type == "Table"){ 
        document.getElementById("PMSBuildingRegistry-TabView").classList.add("ViewBtnAct");
        document.getElementById("PMSBuildingRegistry-ShowView").classList.remove("ViewBtnAct");

        setGridView(false);
        setBubbleView(false);
        setShareView(false);
    }else if(type =="Grid"){ 
      //  document.getElementById("PMSBuildingRegistry-TabView").classList.remove("ViewBtnAct");

        document.getElementById("PMSBuildingRegistryFilterDiv").style.width = '0%';
        document.getElementById("PMSBuildingRegistryTabDiv").style.width = '100%';
        document.getElementById("PMSBuildingRegistryFilterDiv").style.display = 'none';
        document.getElementById("PMSBuildingRegistryfildiv").style.width = '35px';
        document.getElementById("PMSBuildingRegistryfildiv").getElementsByTagName('svg')[0].style.padding = '15%';
        setGridView(true);
        setBubbleView(false);
        setShareView(false);
        setShowSearch(false);
        setShowColumn(false);
        setCardTableView(true);
        document.querySelector('[data-bid="List"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Card"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Grid"]').classList.add("buttonGrpActive");
        document.querySelector('[data-bid="Tile"]').classList.remove("buttonGrpActive");
    }else if(type =="Bubble"){ 
        document.getElementById("PMSBuildingRegistry-TabView").classList.remove("ViewBtnAct");

        document.getElementById("PMSBuildingRegistryFilterDiv").style.width = '0%';
        document.getElementById("PMSBuildingRegistryTabDiv").style.width = '100%';
        document.getElementById("PMSBuildingRegistryFilterDiv").style.display = 'none';
        setBubbleView(true);
        setGridView(false);
        setShareView(false);
        setShowSearch(false);
        setShowColumn(false);
        setCardTableView(true);
    }else if(type =="Share"){ 
        document.getElementById("PMSBuildingRegistry-TabView").classList.remove("ViewBtnAct");
        document.querySelector('[data-bid="List"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Card"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Grid"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Share"]').classList.add("buttonGrpActive");
        document.querySelector('[data-bid="Tile"]').classList.remove("buttonGrpActive");

        setBubbleView(false);
        setGridView(false);
        setShareView(true);
        setShowSearch(false);
        setShowColumn(false);
        setCardTableView(true);
    }else if (type == "List"){ //#3873bb
        setGridView(false);
        setShareView(false);
        //setShowSearch(true);
        setCardTableView(true);
        setCardModelView(false);
        document.querySelector('[data-bid="List"]').classList.add("buttonGrpActive");
        document.querySelector('[data-bid="Card"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Show"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Tile"]').classList.remove("buttonGrpActive");
    }else if (type == "Card"){
        setCardTableView(false);
        setCardModelView(false);
        document.querySelector('[data-bid="List"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Card"]').classList.add("buttonGrpActive");
        document.querySelector('[data-bid="Show"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Tile"]').classList.remove("buttonGrpActive");
    }else if (type == "Tile"){
        setCardModelView(true);
        setCardTableView(false);
        document.querySelector('[data-bid="List"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Card"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Show"]').classList.remove("buttonGrpActive");
        document.querySelector('[data-bid="Tile"]').classList.add("buttonGrpActive");
    }else if(type == "Show"){
        document.querySelector('[data-bid="List"]').classList.remove('buttonGrpActive');
        document.querySelector('[data-bid="Card"]').classList.remove('buttonGrpActive');
        document.querySelector('[data-bid="Tile"]').classList.remove('buttonGrpActive');
        document.querySelector('[data-bid="Show"]').classList.add('buttonGrpActive');
        setBubbleView(false);
        setGridView(false);
        setShareView(true);
        setShowSearch(false);
        setShowColumn(false);
        setCardTableView(true);
    }
}

function VisibleItemSelect(data){
       let arr = [];
       let bodyArr = []; 
       let ItemArr =[];
       let language =[];
       data.map((val) => {
           if(val.IsVisible == "1"){
                   arr.push({id:val.FieldDisplay ,name:val.FieldDescription, type:val.FieldDataType});
                   if(!val.FieldDisplay !== "IsDraft"){
                   bodyArr.push(val.FieldDisplay);
                   ItemArr.push(val.FieldDescription);
           }
        }
           let lang = localStorage.getItem('Language')
           const item = { English: 'FieldDescription',Arabic: 'ArabicLang',Other: 'OtherLang'}
           language.push({[val.FieldName] : val[item[lang]]})
           setGridViewShow(val.IsShow == true ? true :false)
           context.IsInboxApproval(val.IsInboxApp ? true :false)
   }); 
       cdispatch({ type: 'language', payload: Object.assign({}, ...language) })
       setTableSearchParams(bodyArr.reduce((acc,curr)=>(acc[curr]='',acc),{}))
       setTableVisibleData(data);
       setTableVisibleItem(arr);
       setTableBodyItem(bodyArr);
       setColumnIndex(ItemArr);
       setItems(bodyArr);
}

function GridViewClick(val,data){
context.edit(val);
// setExpandTable(false);
setShowSearch(false);
document.getElementById("PMSBuildingRegistry-Detail").style.width = "64%";
document.getElementById("PMSBuildingRegistry-Detail").style.display = "block";
document.getElementById("PMSBuildingRegistry-Table").style.width = "35%";
document.getElementById("PMSBuildingRegistry-TabView").classList.add("ViewButtonAct");
document.getElementById("PMSBuildingRegistry-GridView").classList.remove("ViewButtonAct");
document.getElementById("PMSBuildingRegistry-BubbleView").classList.remove("ViewButtonAct");
setGridView(false);
setBubbleView(false);
setShareView(false);
let json ={
PMSBuilCode:"",
PMSBuilName:"",
PMSBuilNo:"",
PMSBuilArInSqFet:"",
LocalityID:"",
CountryID:"",
RegionID:"",
PMSBuilLatitude:"",
PMSBuilLongitude:"",
OrganisationID:"",
AssBuildingTypeID:"",
PMSBuildingComID:"",
PMSLandLordID:"",
PMSBuilCostGroup:"",
PMSBuilPermitNo:"",
EmployeeID:"",
EmployeeID1:"",
PMSBuilConfig:"",
PMSBuilMakaniNo:"",
PMSBuilDMNo:"",
PMSBuilNoOfFlor:"",
PMSBuilNoOfPark:"",
PMSBuilNoOfUnit:"",
PMSBuilBUPArea:"",
PMSBuilLeasArea:"",
PMSBuilConsDateTime:"",
PMSBuilHODateTime:"",
PMSBuilTenanDateTime:"",
PMSBuilLeasDateTime:"",
PMSBuilGraPeriInMons:"",
PMSBuilDescription:"",
BuildingKey:"",

}
setJsonWithValue(json);
searchData({current:1,pageSize:10},json,"PMSBuildingID");
}


function BubbleClick(val,data){
context.edit(val);    
// setExpandTable(false);
setShowSearch(false); 
document.getElementById("PMSBuildingRegistry-Detail").style.width = "64%";
document.getElementById("PMSBuildingRegistry-Table").style.width = "35%";
document.getElementById("PMSBuildingRegistry-TabView").classList.add("ViewButtonAct");
document.getElementById("PMSBuildingRegistry-GridView").classList.remove("ViewButtonAct");
document.getElementById("PMSBuildingRegistry-BubbleView").classList.remove("ViewButtonAct");
setGridView(false);
setBubbleView(false);
setShareView(false);
let json ={
PMSBuilCode:"",
PMSBuilName:"",
PMSBuilNo:"",
PMSBuilArInSqFet:"",
LocalityID:"",
CountryID:"",
RegionID:"",
PMSBuilLatitude:"",
PMSBuilLongitude:"",
OrganisationID:"",
AssBuildingTypeID:"",
PMSBuildingComID:"",
PMSLandLordID:"",
PMSBuilCostGroup:"",
PMSBuilPermitNo:"",
EmployeeID:"",
EmployeeID1:"",
PMSBuilConfig:"",
PMSBuilMakaniNo:"",
PMSBuilDMNo:"",
PMSBuilNoOfFlor:"",
PMSBuilNoOfPark:"",
PMSBuilNoOfUnit:"",
PMSBuilBUPArea:"",
PMSBuilLeasArea:"",
PMSBuilConsDateTime:"",
PMSBuilHODateTime:"",
PMSBuilTenanDateTime:"",
PMSBuilLeasDateTime:"",
PMSBuilGraPeriInMons:"",
PMSBuilDescription:"",
BuildingKey:"",

}
setJsonWithValue(json);
searchData({current:1,pageSize:10},json,"PMSBuildingID");
}





    function PMSBuildingRegistry_Share(val,type,idpk,show){
    let url = config.Api + "FP1394S6/";
    let params = {
        "data":
        {
            "p1": idpk ? idpk : val && val.PMSBuildingIDPK ? val.PMSBuildingIDPK : null
               ,"p2": val && val.PMSBuilCode ? val.PMSBuilCode : null
               ,"p3": val && val.PMSBuilName ? val.PMSBuilName : null
               ,"p4": val && val.PMSBuilNo ? val.PMSBuilNo : null
               ,"p5": val && val.PMSBuilArInSqFet ? val.PMSBuilArInSqFet : null
               ,"p6": val && val.PMSBuilLatitude ? val.PMSBuilLatitude : null
               ,"p7": val && val.PMSBuilLongitude ? val.PMSBuilLongitude : null
               ,"p8": val && val.PMSBuilCostGroup ? val.PMSBuilCostGroup : null
               ,"p9": val && val.PMSBuilPermitNo ? val.PMSBuilPermitNo : null
               ,"p10": val && val.PMSBuilConfig ? val.PMSBuilConfig : null
               ,"p11": val && val.PMSBuilMakaniNo ? val.PMSBuilMakaniNo : null
               ,"p12": val && val.PMSBuilDMNo ? val.PMSBuilDMNo : null
               ,"p13": val && val.PMSBuilNoOfFlor ? val.PMSBuilNoOfFlor : null
               ,"p14": val && val.PMSBuilNoOfPark ? val.PMSBuilNoOfPark : null
               ,"p15": val && val.PMSBuilNoOfUnit ? val.PMSBuilNoOfUnit : null
               ,"p16": val && val.PMSBuilBUPArea ? val.PMSBuilBUPArea : null
               ,"p17": val && val.PMSBuilLeasArea ? val.PMSBuilLeasArea : null
               ,"p18": val && val.PMSBuilConsDateTime ? val.PMSBuilConsDateTime : null
               ,"p19": val && val.PMSBuilConsDateTimeType ? val.PMSBuilConsDateTimeType : null
               ,"p20": val && val.PMSBuilConsDateTimeBetween ? val.PMSBuilConsDateTimeBetween : null
               ,"p21": val && val.PMSBuilHODateTime ? val.PMSBuilHODateTime : null
               ,"p22": val && val.PMSBuilHODateTimeType ? val.PMSBuilHODateTimeType : null
               ,"p23": val && val.PMSBuilHODateTimeBetween ? val.PMSBuilHODateTimeBetween : null
               ,"p24": val && val.PMSBuilTenanDateTime ? val.PMSBuilTenanDateTime : null
               ,"p25": val && val.PMSBuilTenanDateTimeType ? val.PMSBuilTenanDateTimeType : null
               ,"p26": val && val.PMSBuilTenanDateTimeBetween ? val.PMSBuilTenanDateTimeBetween : null
               ,"p27": val && val.PMSBuilGraPeriInMons ? val.PMSBuilGraPeriInMons : null
               ,"p28": val && val.PMSBuilLeasDateTime ? val.PMSBuilLeasDateTime : null
               ,"p29": val && val.PMSBuilLeasDateTimeType ? val.PMSBuilLeasDateTimeType : null
               ,"p30": val && val.PMSBuilLeasDateTimeBetween ? val.PMSBuilLeasDateTimeBetween : null
               ,"p31": val && val.PMSBuilDescription ? val.PMSBuilDescription : null
               ,"p32": val && val.BuildingKey ? val.BuildingKey : null
               ,"p33": IsDraft ? "1" : "0"
               ,"p34": null
               ,"p35": val && val.LocalityID ? val.LocalityID : null
               ,"p36": val && val.OrganisationID ? val.OrganisationID : null
               ,"p37": val && val.CountryID ? val.CountryID : null
               ,"p38": val && val.RegionID ? val.RegionID : null
               ,"p39": val && val.PMSBuildingComID ? val.PMSBuildingComID : null
               ,"p40": val && val.AssBuildingTypeID ? val.AssBuildingTypeID : null
               ,"p41": val && val.PMSLandLordID ? val.PMSLandLordID : null
               ,"p42": val && val.EmployeeID ? val.EmployeeID : null
               ,"p43": val && val.EmployeeID1 ? val.EmployeeID1 : null
               ,"p44": props.Dialogview ? "1" : null
               ,"p45": null
               ,"p46": val && val.CreatedUserID_varchar ? val.CreatedUserID_varchar : null
               ,"p47": val && val.CreatedTtm ? val.CreatedTtm : null
               ,"p48": val && val.CreatedTtmType ? val.CreatedTtmType : null
               ,"p49": val && val.CreatedTtmBetween ? val.CreatedTtmBetween : null
               ,"p50": null
               ,"p51": val && val.LocalityGroupID ? val.LocalityGroupID : null
               ,"p52": val && val.LocalityGroupCode ? val.LocalityGroupCode : null
               ,"p53": val && val.LocalityGroupName ? val.LocalityGroupName : null
               ,"p54": val && val.CityID ? val.CityID : null
               ,"p55": val && val.CityCode ? val.CityCode : null
               ,"p56": val && val.CityName ? val.CityName : null
               ,"p57": val && val.AdminLocalityTypeID ? val.AdminLocalityTypeID : null
               ,"p58": val && val.AdminLocalityTypeCode ? val.AdminLocalityTypeCode : null
               ,"p59": val && val.AdminLocalityTypeName ? val.AdminLocalityTypeName : null
               ,"p60": val && val.LocalityCode ? val.LocalityCode : null
               ,"p61": val && val.LocalityName ? val.LocalityName : null
               ,"p62": val && val.OrganisationCode ? val.OrganisationCode : null
               ,"p63": val && val.OrganisationName ? val.OrganisationName : null
               ,"p64": val && val.CountryCode ? val.CountryCode : null
               ,"p65": val && val.CountryName ? val.CountryName : null
               ,"p66": val && val.RegionCode ? val.RegionCode : null
               ,"p67": val && val.RegionName ? val.RegionName : null
               ,"p68": val && val.PMSBuildingComCode ? val.PMSBuildingComCode : null
               ,"p69": val && val.PMSBuildingComName ? val.PMSBuildingComName : null
               ,"p70": val && val.AssBuildingTypeCode ? val.AssBuildingTypeCode : null
               ,"p71": val && val.AssBuildingTypeName ? val.AssBuildingTypeName : null
               ,"p72": val && val.ShiftID ? val.ShiftID : null
               ,"p73": val && val.ShiftCode ? val.ShiftCode : null
               ,"p74": val && val.ShiftName ? val.ShiftName : null
               ,"p75": val && val.ClassificationID ? val.ClassificationID : null
               ,"p76": val && val.ClassificationCode ? val.ClassificationCode : null
               ,"p77": val && val.ClassificationName ? val.ClassificationName : null
               ,"p78": val && val.DepartmentID ? val.DepartmentID : null
               ,"p79": val && val.DepartmentCode ? val.DepartmentCode : null
               ,"p80": val && val.DepartmentName ? val.DepartmentName : null
               ,"p81": val && val.DesignationID ? val.DesignationID : null
               ,"p82": val && val.DesignationCode ? val.DesignationCode : null
               ,"p83": val && val.DesignationName ? val.DesignationName : null
               ,"p84": val && val.NationalityID ? val.NationalityID : null
               ,"p85": val && val.NationalityCode ? val.NationalityCode : null
               ,"p86": val && val.NationalityName ? val.NationalityName : null
               ,"p87": val && val.EmpWorkNatureID ? val.EmpWorkNatureID : null
               ,"p88": val && val.NatureOfWorkCode ? val.NatureOfWorkCode : null
               ,"p89": val && val.NatureOfWorkName ? val.NatureOfWorkName : null
               ,"p90": val && val.EmployeeTypeID ? val.EmployeeTypeID : null
               ,"p91": val && val.EmployeeTypeCode ? val.EmployeeTypeCode : null
               ,"p92": val && val.EmployeeTypeName ? val.EmployeeTypeName : null
               ,"p93": val && val.EmploymentTypeID ? val.EmploymentTypeID : null
               ,"p94": val && val.EmploymentTypCode ? val.EmploymentTypCode : null
               ,"p95": val && val.EmploymentTypeName ? val.EmploymentTypeName : null
               ,"p96": val && val.EmployeeGroupID ? val.EmployeeGroupID : null
               ,"p97": val && val.EmployeeGroupCode ? val.EmployeeGroupCode : null
               ,"p98": val && val.EmployeeGroupName ? val.EmployeeGroupName : null
               ,"p99": val && val.EmpGradeID ? val.EmpGradeID : null
               ,"p100": val && val.EmpGradeCode ? val.EmpGradeCode : null
               ,"p101": val && val.EmpGradeName ? val.EmpGradeName : null
               ,"p102": val && val.EmpGenderID ? val.EmpGenderID : null
               ,"p103": val && val.EmpGenderName ? val.EmpGenderName : null
               ,"p104": val && val.EmpTitleID ? val.EmpTitleID : null
               ,"p105": val && val.EmpTitleName ? val.EmpTitleName : null
               ,"p106": val && val.EmployeeCode ? val.EmployeeCode : null
               ,"p107": val && val.FirstName ? val.FirstName : null
               ,"p108": val && val.EmpContactNo1 ? val.EmpContactNo1 : null
               ,"p109": val && val.EmpEmailOfficial ? val.EmpEmailOfficial : null
             ,"p110":  idpk ? 1 : param.current
             ,"p111": 10
             ,"p112": type
               ,"p113": null
               ,"p114": null
               ,"p115": localStorage.getItem('UserGroupID')
               ,"p116": localStorage.getItem('userid')
        }
    }
    CommonAPISelect(url,params,cstate.token[0])
    .then(res => {
        if(res.Output.status.code == "200"){
            if(res.Output.data.length > 0){
                let result = res.Output.data.length;
                let data = res.Output.data;
                if(result > 0){       
                    let arr= new Array();
                    data.map(val => {
                        arr.push({"name":val.Name,"value":val.Total == "0" ? "NaN" :val.Total})
                    });
                    const dataset ={"children":[
                        {"name":"PMSBuildingRegistry","children":arr
                    }],"FullData":data}; 
                    setShareData(dataset);  
                }
            }
        }
    });
}

 const handleRequestSort = (event, property) => { 
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
}; 
function descendingComparator(a, b, orderBy) { 
    if (b[orderBy] < a[orderBy]) {
      return -1;
    }
    if (b[orderBy] > a[orderBy]) {
      return 1;
    }
    return 0;
  }

  function getComparator(order, orderBy) {
    return order === 'desc'
      ? (a, b) => descendingComparator(a, b, orderBy)
      : (a, b) => -descendingComparator(a, b, orderBy);
  }

function stableSort(array, comparator) {    
    const stabilizedThis = array.map((el, index) => [el, index]);
    stabilizedThis.sort((a, b) => {
        const order = comparator(a[0], b[0]);
        if (order !== 0) return order;
        return a[1] - b[1];
    });
    return stabilizedThis.map((el) => el[0]);
}


   function TableCellValue(val,pass){
    if(pass.toLowerCase().indexOf('password') > -1){
        var password =  ""; 
      for(let i=0;i<val.length;i++){ 
          password+=  "*" ;
         } 
   return password;
    }else{ 
        return val; 
    } 
} 

    function tabledataScroll(param){
    context.loading(true);
    let url = config.Api + "FP1394S7/";
           let params = {
           "data": {
                "p1": "%%",
                "p2": "0",
                "p3": "0",
                "p4": param.current,
                "p5": param.pageSize,
                "p6": localStorage.getItem('UserGroupID'),
                "p7": localStorage.getItem('userid')
        }
   }
   CommonAPISelect(url,params,cstate.token[0])
   .then(res => {
       if(res.Output.status.code == 200){ 
        let totalRow = 0;
        let result = res.Output.data.length;
               if(result > 0){
                   totalRow = parseFloat(res.Output.data[0].TotalCount , 10)/10;
                   setTableScrollTotalCount(res.Output.data[0].TotalCount);
               }else{
                       totalRow = 0;
                       setTableScrollTotalCount(0);
               }
        if(param.pageSize == 10){
             setTableScrollTotal(Math.ceil(totalRow));
         }else if(param.pageSize == 20){
             setTableScrollTotal(Math.ceil(totalRow/2));
         }else if(param.pageSize == 50){
             setTableScrollTotal(Math.ceil(totalRow/5));
         }else if(param.pageSize == 100){
             setTableScrollTotal(Math.ceil(totalRow/10));
         }
         setPMSBuildingRegistryScrollData(res.Output.data);
        context.loading(false);
         }else{
             context.alert({open: true,color:'warning',message: ['There is no Record Found']});
             context.loading(false);
         }
   });
}

const ExpandPanel = () => () => {
              setExpanded(ExpandView);
        };
        useEffect(() => {
               setExpandView(props.ExpandTableValue);
        },[props.ExpandTableValue])

   const MigrationSlide = () => {
   setTimeout(() => migRef.current.getRefresh([]), 2000); //wait 2 seconds
   context.openNav();
   context.SlideComponentType(
           <ExportMigration 
           ref ={migRef}
           Messages={(e)=>context.alert({open: true,color:'error', message: ['There is no Record Found']}) }
           data = {(v) => console.log(v)}
           SheetCount = {1}
           importSave = {(data,type) => dataSyncSave(data,type)}
           TableVisibleItem = {MigTableVisibleItem}
           frmctrlid ='fld1394L4TCExpMig'
           TableBodyItem = {MigTableBodyItem}
           clear={(e)=> migRef.current.getRefresh([])}
           excelfile = {config.excel+'PMSBuildingRegistry.xlsx'}
           filename={'PMSBuildingRegistry.xlsx'}
           />
    );
}

function MigVisibleItemSelect(val){
    const data = val.filter(e => e.FormID == userGridViewMigFormID);
    let arr = [];
    let bodyArr = []; 
    data.map((val) => {
        if(val.IsVisible == '1'){ 
                arr.push({id:val.FieldName ,name:val.FieldDescription, type:val.FieldDataType});
                bodyArr.push(val.FieldName);
        }
    }); 
    setMigTableVisibleItem(arr);
    setMigTableBodyItem(bodyArr);
}

 function qreplace(val) {
         if(val){
             return val.replace(/["'’]/g, '').trim();
         }else{
             return val;
         }
 }
 //   Record Migration Function from Excel Sheet
const dataSyncSave = (data,type) => {
if(data.length > 0){
context.loading(true);
var param = []
const url = config.Api + "FP1394S8/";
data.map((val,key)=>{
   var UpdatedUserKey = 0;
    if(data.length == 1){
        UpdatedUserKey = 3;
    }else if(data.length == key+1){
        UpdatedUserKey = 2;
    }else if(key == 0){
        UpdatedUserKey = 1;
    }
    param.push({

    })
  })
  Token(0).then(token=>{  
    CommonAPISave(url,{ "data" : param,...type},token)
    .then((res)=>{
         const status = res[0].status;
         if(status.code == 200){
            context.alert({ open:true,color:'success',message: [status.message]});
            context.loading(false);
            migrationSelect();
         } 
     })
 })
}
}
 //   Select Data from the Migrated Table to Check the Confict
const migrationSelect = () => {
           context.loading(true);
           let url = config.Api + "MIG_FP1394S3/";
           let params = {
           "data": {
               "p1": localStorage.getItem('UserGroupID')
               ,"p2": localStorage.getItem('userid')
        }
   }
   CommonAPISelect(url,params,cstate.token[0])
   .then(res => {
   context.loading(false);
   if(res.Output.status.code == "200"){
     if(res.Output.data.length > 0){
          migRef.current.getRefresh(res.Output.data);
      }
    }
   }); 
}


//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        return(
   <div>
    <Accordion expanded={expanded} onChange={() => ExpandPanel()}>

<AccordionSummary> 
        <div className="padding displayFlex backgroundDark borderRadiusTop width100 L3Header"> 
                <div>
                    <div className="displayFlex">
                            {IsDraft ? 
                            <div className="ListHeader displayFlex">
                               <div id='fld1394L4TCKeyboardBackspaceRounded' onClick={() => {searchData(GridPagination,EmptyJson,"PMSBuildingID");setIsDraft(false);}}>
                                    <Tooltip 
                                       title = "List"
                                       placement = "top"
                                    >
                                        <MdOutlineArrowBackIosNew className="BackBtnIcon"/>
                                    </Tooltip>
                               </div> 

                               <div id ='fld1394L4TCDraftP' onClick={() => searchData(GridPagination,EmptyJson,"DraftPMSBuildingID")}>
                                    <Tooltip title = "Draft" placement = "top">
                                        <p  className="DraftP">
                                           Drafts({TableTotalCount})
                                        </p>
                                    </Tooltip>
                                </div> 
                            </div> 
                            :
                                <div className="ListHeader displayFlex">
                                              {props.ExpandTableValue ? 
                                                expanded ?
                                                    <ExpandLessIcon className="ArrowIconsLight" onClick={() => {
                                                        setExpanded(false);
                                                    }}/>
                                                :
                                                    <ExpandMoreIcon className="ArrowIconsLight" onClick={() => {
                                                        setExpanded(true);
                                                    }}/>
                                               : null
                                            }
                                            <p className="ListP" title='8.0.0.46-12:46:59-21-3' onClick={() => props.ExpandTableValue && setExpanded(expanded?false:true)}>
                                            {`${tf('1394')} (${TableTotalCount})`}
                                        </p>
                                </div> 
                            }

                    </div>
                </div>
                <div>
                {GridView || BubbleView || ShareView || IsDraft ? null
                    :
                        <div className="displayFlex">
                        <div id='fld1394L4TCSearchBar' className="searchbar" style={{marginRight: "2%"}}>
                        <InputSearch className="search_input" type="text" id='PMSBuildingRegistrygridsearch' placeholder="Search" value={CommonSearchValue}
                        onChange={(e) => {setCommonSearchValue(e);
                        if(e.length == '0'){
                               searchData(GridPagination,EmptyJson,IsDraft ? "DraftPMSBuildingID":"PMSBuildingID",IsDraft && "DraftPage");
                               return false;
                       }else{
                               CommonSearchFunction(e,{current:1,pageSize:10})
                           }
                       }}
                       />
                        <div className="search_icon">
                            {CommonSearchValue ?
                         <div id='fld1394L4TCInputCloseIcon'onClick={() => {setCommonSearchValue("");searchData(GridPagination,EmptyJson,IsDraft ? "DraftPMSBuildingID":"PMSBuildingID",IsDraft && "DraftPage");}}>
                                <CloseIcon className="InputSearchIcon"/>
                         </div>
                            :
                         <div id='fld1394L4TCInputSearchIcon' onClick={() => {setCommonSearchValue("");tableRefresh()}}>
                                <SearchIcon className="InputSearchIcon"/>
                         </div>
                            }
                        </div>
                    </div> 
                    {cstate.AccessRights.IsAdd && 
                    <AddBtn disabled={false} className='SaveBtnCommon'
                            name = {"Add"}
                            frmctrlid='fld1394L4ECAddBtnIsAdd'
                            onClick={()=> {context.edit(false);context.add() }}
                    />  
                    } 
                    </div> 
                }
                </div>
        </div> 
        </AccordionSummary>
  <AccordionDetails className="AccDetails">
                <div className="tableCard"> 
                   <div id="PMSBuildingRegistry-HeaderItems" className="displayFlex padding">
                        <div className="tableHeaderItems displayFlex">
                           {!IsDraft &&
                                <div frmctrlid='fld1394L4TCFilterDataIsDraft' id ="PMSBuildingRegistryfildiv" className = "buttoncard"
                                     onClick={() => {ToggleFilterView()}}>
                                <Tooltip 
                                title = {t("Filter Data")}
                                placement = "top"
                                >
                                    <span><BiFilterAlt className="tableFilterColumnIcon"/></span>
                                </Tooltip>
                               <span className="iconinfo">{t("Filter Data")}</span>
                             </div> 
                            }
                            <Export_Print 
                                    formctrlidprint='fld1394L4TCExportPrint'
                                    formctrlidexport = 'fld1394L4TCExportTable'
                                    formctrlidrefresh='fld1394L4TCExportRefresh'
                                    title={'Building Registry'}
                                    data = {PrintData}
                                    exportData = {exportData}
                                    Items = {Items}
                                    columnIndex={columnIndex}
                                    TableVisibleItem = {TableVisibleItem}
                                    userGridViewFormID = {userGridViewFormID}
                                    TableTotalCount ={TableTotalCount}
                                    triggerApi={(file) => {getAllDataPrint(searchParams,Filter.column,null,null,file)}}
                                    Refresh={() => {setCommonSearchValue("");
                                    if(props.draftval){ 
                                          searchData({current:1,pageSize:10},EmptyJson,'DraftPMSBuildingID'); 
                                          setGridPagination({current:1,pageSize:10}); 
                                     }else{ 
                                          searchData({current:1,pageSize:10},EmptyJson,'PMSBuildingID'); 
                                          setGridPagination({current:1,pageSize:10}); 
                                          setSearchParams({}); 
                                     } 
                                    }}
                                    disabledPrint = {!cstate.AccessRights.IsPrint}
                                    disabledExport = {!cstate.AccessRights.IsExport}
                                    ref = {refPrint}
                                   /> 
                                   {!IsDraft &&
                                    <div className="buttoncard" onClick={() => setMore(!More)} >
                                        <span>
                                           {More ?
                                                <Tooltip disableFocusListener title="Less" placement="top">
                                                    <span id="fld1394L4TCLess"><HiChevronDoubleLeft className="tableFilterColumnIcon" /></span>
                                                </Tooltip>
                                                :
                                                <Tooltip disableFocusListener title="More" placement="top">
                                                    <span id="fld1394L4TCMore"><HiChevronDoubleRight className="tableFilterColumnIcon" /></span>
                                                </Tooltip>
                                            }
                                        </span>
                                    </div>
                                   }
                   {!IsDraft && More ?
                            <div className='EntryHeaderMore'> 
                            {(GridView || BubbleView  || ShareView || IsDraft ) ? null
                            : 
                            !IsDraft && <div>
                                <div frmctrlid='fld1394L4TCFilterDataIsAdd' id={"PMSBuildingRegistrycoldiv" + (props.Dialogview ? 'dialog':'')} className="buttoncard"
                                     onClick={() => {ToggleFilterDataIsAdd()}}>
                                <Tooltip 
                                title={t("Manage Columns")}
                                placement="top"
                                >
                               <div>
                                   <TiMediaPauseOutline className="tableFilterColumnIcon"/>
                               </div>
                                </Tooltip>
                           <span className="iconinfo">{t('Manage Columns')}</span>
                            </div> 
                            </div>
                            }
                            {!IsDraft && IsMig && !GridView &&  !ShareView && !Dialogview && 
                               <div frmctrlid ='fld1394L4TCExpMigSlide' className="buttoncard" onClick={() => MigrationSlide()}>
                                       <Tooltip 
                                           title = {t("Migration")}
                                           placement = "top"
                                       >
                                           <div>
                                                   <RiArrowLeftRightFill className="tableFilterColumnIcon" />
                                           </div>
                                   </Tooltip>
                                           <span className="iconinfo">{t("Migration")}</span>
                               </div> 
                               }
                            {(localStorage.getItem('UserType') == 1 || localStorage.getItem('UserType') == 2) &&<div> 
                               <div frmctrlid ='fld1394L4TCTableScrollData' id="PMSBuildingRegistrycoldiv" className="buttoncard"
                                   onClick={()=> {if(showTableScroll){ setShowTableScroll(false) }else {setShowTableScroll(true);tabledataScroll({current:1,pageSize:10}); }  }} >
                                   <Tooltip
                                           title = {t("Table Scroll Data")}
                                           placement = "top"
                                    >
                                    <div>
                                           <GridOnIcon className="tableFilterColumnIcon"/>
                                    </div>
                                    </Tooltip>
                                          <span className="iconinfo">{t("Table Scroll Data")}</span>
                               </div>
                                   </div>}
                               { cstate.AccessRights.IsAdd &&
                                <div>
                                 <Badge color="secondary" className="badge" max={999} badgeContent={DraftCount} showZero>
                                  <div id='fld1394L4TCDraftsIcon'className="buttoncard" style={{ marginLeft: "-10px" }}
                                      onClick={() => {searchData({current: 1, pageSize: 10},EmptyJson,"DraftPMSBuildingID");
                                      setIsDraft(true);
                                      setShowColumn(false);
                                      cdispatch({ type:'IsDraft', payload : true}) 
                                      document.getElementById('PMSBuildingRegistryTabDiv').style.width = '100%'
                                    }}
                                    >
                                     <Tooltip
                                         title="Drafts"
                                         placement="top"
                                     >
                                     <div>
                                         <TbFilePencil className="DraftIcon" />
                                     </div>
                                     </Tooltip>
                                     <span className="iconinfoDraft" style={{ fontSize: "0.815rem", fontWeight: "500", color: "#14181F" }}>{t("Drafts")}</span>
                                    </div>
                                  </Badge> 
                                   </div> 
                                     } 
                                   </div> : ""}
                                   </div>
                                {!IsDraft && !Dialogview &&
                            <div className="tableHeaderItems displayFlex" style={{ width: '20%', display: "flex", justifyContent: "right", paddingRight: "2px" }}>
                                   {/*  {(ShareView || IsDraft) ? null
                                       :*/}
                                    <div>
                                        <div style={{ display: 'flex', alignItem: 'center', marginLeft: "8px" }}>
                                            <div className="b2" id="button-11">
                                             {GridViewShow == true ?
                                                <div className="buttonGrpUnActive" data-bid="Show"
                                                    id ="fld1394L4TCShowView"
                                                    onClick={() => { 
                                                    setShareView(true),
                                                    TableView('Show'),
                                                    <ShowComponent onload={ShareView} 
                                                     showSearch={false} 
                                                     data={(val,data) => {GridViewClick(val,data)}} 
                                                     json={ShareSearchJson}/>
                                                    }}
                                                    >
                                                    <span style={{ fontSize: "14px", color: "#14181F" }}><FiGrid /></span>
                                                    <span>{t('Show')}</span>
                                                 </div> : ''}
                                                <div className="buttonGrpUnActive buttonGrpActive" data-bid="List"
                                                    id="fld1394L4TCListView"
                                                    onClick={() => { TableView('List')}} style={{ borderTopLeftRadius: "4px", borderBottomLeftRadius: "4px" }}>
                                                    <span style={{ fontSize: "14px", color: "#14181F" }}><HiMenuAlt2 /></span>
                                                    <span>{t('List')}</span>
                                                </div>
                                                <div className="buttonGrpUnActive" data-bid="Card"
                                                    id="fld1394L4TCCardView"
                                                    onClick={() => {TableView('Card')}}>
                                                    <span style={{ fontSize: "14px", color: "#14181F" }}><FiGrid /></span>
                                                    <span>{t('Card')}</span>
                                                </div>
                                                {/*<div className="buttonGrpUnActive" data-bid="Grid"
                                                    id="fld1394L4TCGridView"
                                                    onClick={() => { 
                                                        TableView("Grid")
                                                    }}
                                                        >
                                                    <span style={{ fontSize: "14px", color: "#14181F" }}><FiGrid /></span>
                                                    <span>{t('Grid')}</span>
                                                </div>
                                                <div className="buttonGrpUnActive" data-bid="Share"
                                                    id="fld1394L4TCGridView"
                                                    onClick={() => { 
                                                        TableView("Share")
                                                    }}
                                                        >
                                                    <span style={{ fontSize: "14px", color: "#14181F" }}><FiGrid /></span>
                                                    <span>{t('Share')}</span>
                                                </div>*/}
                                                <div className="buttonGrpUnActive" data-bid="Tile"
                                                    id="fld1394L4TCTileView"
                                                    onClick={() => { TableView("Tile")}}
                                                    style={{ borderTopRightRadius: "4px", borderBottomRightRadius: "4px" }}>
                                                    <span style={{ fontSize: "14px", color: "#14181F" }}><MdFormatListBulleted /></span>
                                                    <span>{t('Tile')}</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                   {/*}*/}
                                   </div>
                                   }

{(GridView || BubbleView || ShareView) ? null
                            :
                            (showTableScroll ? 
                        <div className="tableTopPagination displayFlex floatOrder">
                        <MUIPagination count={TableScrollTotal} color="primary" page={ScrollGridPagination.current} onChange={(e,val)=>{
                            setScrollGridPagination({current:val,pageSize:ScrollGridPagination.pageSize});
                            setTableScrollTotal(val); 
                            tabledataScroll({current:val,pageSize:ScrollGridPagination.pageSize});
                            }}
                        /> 
                       <div>
                        <MUISelect 
                        value = {ScrollGridPagination.pageSize}
                        frmctrlid="fld1394L4TCSelectPagination"
                        onChange={(val)=>{
                            setScrollGridPagination({current:1,pageSize:val.target.value});
                            tabledataScroll({current:1,pageSize:val.target.value});
                        }}

                      className ='BootstrapInputStyle'

                        >
                        <option value={10}>10</option>
                        <option value={20}>20</option>
                        <option value={50}>50</option>
                        <option value={100}>100</option>
                        </MUISelect>
                       </div>
                       {ExpandView && <p className="per-page">/ per page Of ({TableScrollTotalCount})</p> } 
                       </div>
                       :
                            <div className="tableTopPagination displayFlex floatOrder">
                                <MUIPagination count={TableTotal} siblingCount={0} color="primary" page={GridPagination.current} onChange={(e,val)=>{
                                    setGridPagination({current:val,pageSize:GridPagination.pageSize});
                                        if(CommonSearchValue.length > 0){
                                            CommonSearchFunction(CommonSearchValue,{current:val,pageSize:GridPagination.pageSize});
                                        }else{
                                            searchData({current:val,pageSize:GridPagination.pageSize},searchParams,IsDraft ? "DraftPMSBuildingID":"PMSBuildingID");
                                        }
                                    }}
                                   /> 
                                   <div>
                                    <MUISelect 
                                    value={GridPagination.pageSize}
                                    frmctrlid="fld1394L4TCSelectPagination"
                                    onChange={(val)=>{
                                        setGridPagination({current:1,pageSize:val.target.value});
                                        if(CommonSearchValue.length > 0){
                                                CommonSearchFunction(CommonSearchValue,{current:1,pageSize:val.target.value});
                                        }else{
                                                searchData({current:1,pageSize:val.target.value},JsonWithValue, IsDraft ? "DraftPMSBuildingID":"PMSBuildingID");
                                        }
                                    }}

                      className ='BootstrapInputStyle'

                                    >
                                    <option value={10}>10</option>
                                    <option value={20}>20</option>
                                    <option value={50}>50</option>
                                    <option value={100}>100</option>
                                    </MUISelect>
                                   </div>
                                   {ExpandView && <p className="per-page">/ per page of ({TableTotalCount}) </p> } 
                                               </div>    
                                               )
                                               }
                                           </div>
                                <div id="PMSBuildingRegistry-TableBody" className="displayFlex padding0" style={{height:'66vh',overflow: 'auto'}}>
                             {!IsDraft &&
                                <div id="PMSBuildingRegistryFilterDiv" style={{width:'0%',display:'none',border: '1px solid #e3e4e9',marginRight: '1%'}}>
                                {showSearch  && 
                                    <PMSBuildingRegistryDropDownComponent CloseBtnClk={() => ToggleFilterView()} searchData={(val)=>setSearchParams(val)} formID={userGridViewFormID} data={() => {}} visibleData={() => {}} token={cstate.token[0]} msg={(e,color)=>context.alert({open: true,color:color, message: [e]})}/>
                                }
                                {(showColumn && (!GridView && !BubbleView))  &&
                               <TableColumnOrder 
                                 frmctrlid='fld1394L4TCTableColumnOrder'
                                 loading={(e) => context.loading(e)}
                                 AltMsg={(e,color)=>context.alert({open: true,color:color, message: [e]})}
                                 select={showColumn} userID={userID}
                                 userGridViewFormID={userGridViewFormID} 
                                 saved={(val, data) => {val && VisibleItemSelect(data)}} 
                                 Token={cstate.token[0]}/>
                                }
                               </div>
                             }
                            <div id="PMSBuildingRegistryTabDiv" style={{width:'100%',position: 'relative',height: '66vh'}}>
                                        {CardTableView ?
       <div>
       {GridView  &&   <SchemaComponent onLoad={GridView} showSearch={showSearch} data={(val,data) => {GridViewClick(val,data)}} json={GridViewSearchJson}/>}
       {ShareView  &&  <ShowComponent onload={ShareView} showSearch={false} data={(val,data) => {GridViewClick(val,data)}} json={ShareSearchJson}/>}
       {(!GridView && !ShareView)  &&    <div>
                   {showTableScroll ? 
                   <TableScroll data={PMSBuildingRegistryScrollData}
                                   expanded = {() => {}}
                                   edit = {context.edit}
                    />
                   :
                       <MUITable 
                                   ref={MuiRef}
                                   frmctrlid ='tblcs_1394_L4_'
                                   id = "PMSBuildingRegistryTable"
                                   headerdata = {TableVisibleItem}
                                   tablesearchparams = {TableSearchParams} 
                                   searchvalue={(e) => {
                                       setTableSearchParams(e);
                                       setSearchParams(e);
                                       searchData(GridPagination,e,IsDraft ? "DraftPMSBuildingID" : "PMSBuildingID",IsDraft && "DraftPage");
                                   }}
                                   bodydata = {PMSBuildingRegistryData}
                                   ondrag = {(e,row) => {context.edit(row,IsDraft,true)}}
                                   bodyitem = {TableBodyItem}
                                   visibleitem = {TableVisibleItem}
                                   isdraft = {IsDraft}
                                   action='none'
                                   tableID={userGridViewFormID}
                                   accessrights = {cstate.AccessRights}
                                   expanded = {() => {}}
                                   edit = {context.edit}
                                   viewtoggle = {()=>cstate.viewtoggle}
                                   tf={tf}
                                   isexpanded={Dialogview ? ExpandView : true}
                         />
                                }
                                </div>}
                                </div>
                                :
                                       <ExpandedCardDual
                                           frmctrlid ='fld1394L4TCExpandedCardDual'
                                           data={PMSBuildingRegistryData}
                                           id={'PMSBuildingRegistry'}
                                           title={'PMSBuilName'}
                                           cardTile={CardModelView ? true : false}
                                           visibleitem={TableVisibleItem}
                                           gridCountmdlg={4}
                                           gridCountxssm={6}
                                           onDoubleClick={(row,type) =>{
                                            if (Dialogview){
                                               context.select(row)
                                            }else{
                                                if (type == 'edit') {
                                                    context.edit(row,type);
                                                } else {
                                                    context.edit(row,false,true);
                                                }
                                                if(ExpandView){
                                                    setShowSearch(false);
                                                    setShowColumn(false);
                                                }
                                            }}}
                                       />
                                  }
                            </div>
                        </div>
                   </div> 
           </AccordionDetails>
    </Accordion> 
    </div>
    );
});

export default PMSBuildingRegistry;



// Main Rendering  Function Of Table

export const PMSBuildingRegistryPopUpTable= forwardRef((props,ref) =>{
const refPrint = useRef(null);
const MuiRef = useRef(null);
const content = useSelector(state => state.form);
const [userID] = useState(localStorage.getItem('userid'));
const [userGrid, setUserGrid] = UserGridView('1394')
const [Dialogview, setDialogview] = useState(false)

const [TableTotal, setTableTotal] = useState(0);
const [TableTotalCount, setTableTotalCount] = useState(0);
const [GridPagination, setGridPagination] = useState({current: 1, pageSize: 10}); // State for table Pagination
const [ExportData,setExportData] = useState('');
const [PrintData ,setPrintData] = useState([]);
const [Filter, setFilter] = useState({ val:'', column:'' })
const [PMSBuildingRegistryData,setPMSBuildingRegistryData]=useState([]);
const [showSearch,setShowSearch]=useState(false);  
const [searchParams,setSearchParams]=useState("");
const [TableVisibleData,setTableVisibleData]=useState([]);
const [TableVisibleItem,setTableVisibleItem]=useState([]);
const [TableBodyItem,setTableBodyItem]=useState([]);
const context = useContext(PMSBuildingRegistryContext);
const {cstate , cdispatch} = ContextApi();
let EmptyJson = {
PMSBuildingIDPK: "",
PMSBuilCode: "",
PMSBuilName: "",
PMSBuilNo: "",
PMSBuilArInSqFet: "",
PMSBuilLatitude: "",
PMSBuilLongitude: "",
PMSBuilCostGroup: "",
PMSBuilPermitNo: "",
PMSBuilConfig: "",
PMSBuilMakaniNo: "",
PMSBuilDMNo: "",
PMSBuilNoOfFlor: "",
PMSBuilNoOfPark: "",
PMSBuilNoOfUnit: "",
PMSBuilBUPArea: "",
PMSBuilLeasArea: "",
PMSBuilConsDateTime: "",
PMSBuilConsDateTimeType: "",
PMSBuilConsDateTimeBetween: "",
PMSBuilHODateTime: "",
PMSBuilHODateTimeType: "",
PMSBuilHODateTimeBetween: "",
PMSBuilTenanDateTime: "",
PMSBuilTenanDateTimeType: "",
PMSBuilTenanDateTimeBetween: "",
PMSBuilGraPeriInMons: "",
PMSBuilLeasDateTime: "",
PMSBuilLeasDateTimeType: "",
PMSBuilLeasDateTimeBetween: "",
PMSBuilDescription: "",
BuildingKey: "",
IsDraft: "",
Remarks: "",
LocalityID: "",
OrganisationID: "",
CountryID: "",
RegionID: "",
PMSBuildingComID: "",
AssBuildingTypeID: "",
PMSLandLordID: "",
EmployeeID: "",
EmployeeID1: "",
IsActive: "",
DeleStat: "",
CreatedUserID: "",
CreatedTtm: "",
CreatedTtmType: "",
CreatedTtmBetween: "",
UpdatedTtm: "",
LocalityGroupID: "",
LocalityGroupCode: "",
LocalityGroupName: "",
CityID: "",
CityCode: "",
CityName: "",
AdminLocalityTypeID: "",
AdminLocalityTypeCode: "",
AdminLocalityTypeName: "",
LocalityCode: "",
LocalityName: "",
OrganisationCode: "",
OrganisationName: "",
CountryCode: "",
CountryName: "",
RegionCode: "",
RegionName: "",
PMSBuildingComCode: "",
PMSBuildingComName: "",
AssBuildingTypeCode: "",
AssBuildingTypeName: "",
ShiftID: "",
ShiftCode: "",
ShiftName: "",
ClassificationID: "",
ClassificationCode: "",
ClassificationName: "",
DepartmentID: "",
DepartmentCode: "",
DepartmentName: "",
DesignationID: "",
DesignationCode: "",
DesignationName: "",
NationalityID: "",
NationalityCode: "",
NationalityName: "",
EmpWorkNatureID: "",
NatureOfWorkCode: "",
NatureOfWorkName: "",
EmployeeTypeID: "",
EmployeeTypeCode: "",
EmployeeTypeName: "",
EmploymentTypeID: "",
EmploymentTypCode: "",
EmploymentTypeName: "",
EmployeeGroupID: "",
EmployeeGroupCode: "",
EmployeeGroupName: "",
EmpGradeID: "",
EmpGradeCode: "",
EmpGradeName: "",
EmpGenderID: "",
EmpGenderName: "",
EmpTitleID: "",
EmpTitleName: "",
EmployeeCode: "",
FirstName: "",
EmpContactNo1: "",
EmpEmailOfficial: "",
PageIndex: "",
PageSize: "",
Type: "",
OrderByType: "",
SortOrder: "",
UserGroupKey: "",
UserAccessKey: "",
}
const [IsDraft,setIsDraft] = useState(false);
const [expanded, setExpanded] = useState(true);
const [ExpandView,setExpandView]=useState(false);
const [CardTableView,setCardTableView]=useState(true);
const [page, setPage] = useState(0);
const [TableSearchParams,setTableSearchParams]=useState({"PMSBuilCode":"","PMSBuilName":"","PMSBuilNo":"","PMSBuilArInSqFet":"","LocalityName":"","CountryName":"","RegionName":"","PMSBuilLatitude":"","PMSBuilLongitude":"","OrganisationName":"","AssBuildingTypeName":"","PMSBuildingComName":"","PMSLLdName":"","PMSBuilCostGroup":"","PMSBuilPermitNo":"","FirstName":"","FirstName1":"","PMSBuilConfig":"","PMSBuilMakaniNo":"","PMSBuilDMNo":"","PMSBuilNoOfFlor":"","PMSBuilNoOfPark":"","PMSBuilNoOfUnit":"","PMSBuilBUPArea":"","PMSBuilLeasArea":"","PMSBuilConsDateTime":"","PMSBuilHODateTime":"","PMSBuilTenanDateTime":"","PMSBuilLeasDateTime":"","PMSBuilGraPeriInMons":"","PMSBuilDescription":"","BuildingKey":"",});
const [columnIndex,setColumnIndex] = useState([]);
const [Items,setItems] = useState([]);
const [Data,setData] = useState([]);
const [loading,setLoading] = useState(false);
const [showType,setShowType] = useState('');

let lang = multilingual();
const t = (e) =>  lang?.[e] ? lang[e] : e ;
const tf = (e) =>  cstate.language?.[e] ? cstate.language[e] : e ;
// Excel Export
const exportData = [
     {
         columns: columnIndex ,
         data:   ExportData
     }
     ];

useEffect(() => {
   VisibleItemSelect(userGrid);
}, [userGrid]);

useImperativeHandle(ref,() => ({
       tableRefresh : () => {
           tableRefresh();
           ShowRefresh();
   },
viewrecord: (data) => { 
PMSBuildingRegistryData.map((val,index) => {
let id = val.PMSBuildingIDPK;
           if(id == data){
               cdispatch({type: 'editData',payload: [PMSBuildingRegistryData[index]] })
           }
   })
   },
       DialogTableProps : (e) => {
           setDialogview(e)
       },
          searchData: (val,param,type) => { 
          setShowType(type) 
          context.loading(true) 
          setGridPagination({current: 1, pageSize: 10}); 
          EmptyJson = props.ApiParamType.params; 
          setGridPagination({current:1,pageSize:10}) 
          searchData({current:1,pageSize:10},val,param,type); 
          if (props.CardType != 'MultiSelect') { 
              MuiRef.current.clearItem(); 
          } 
      } 
}));
useEffect(() => {
    if(props.cardview === false){
        setCardTableView(props.cardview);
    }
    if(props.Dialogview){
                setDialogview(props.Dialogview)
    }
},[props.cardview, props.Dialogview]);

const tableRefresh = () => {
   if (cstate.IsDraft){
        searchData(GridPagination, EmptyJson,"DraftPMSBuildingID");
    } else {
        searchData(GridPagination, EmptyJson,"PMSBuildingID");
     }
}

// Fetch Data for Table
   const searchData = async (param, val,type,draftpage) => {
               context.loading(true);
               if(draftpage !== 'DraftPage'){
                   setIsDraft(cstate.IsDraft);
               }
               await setShowType((prv) => { 
                  type = prv; 
                  return prv; 
               }) 
               if(val && Object.keys(val).length > 0 ){
                   let arrParam = Object.keys(val);
                   let obj = {};let keys = [];let values = Object.values(val);
                   arrParam.map((e) => {
                       keys.push(e.split('_')[0]);
               });
               for (let i = 0; i < keys.length; i++) {
                   obj[keys[i]] = values[i];
               }
                   val = obj;
               }
           let url = config.Api + `${props.ApiType}/`;
           let params = {
           "data": {
                       "p1":  val && val.PMSBuildingIDPK ? val.PMSBuildingIDPK : null
               ,"p2": val && val.PMSBuilCode ? val.PMSBuilCode : null
               ,"p3": val && val.PMSBuilName ? val.PMSBuilName : null
               ,"p4": val && val.PMSBuilNo ? val.PMSBuilNo : null
               ,"p5": val && val.PMSBuilArInSqFet ? val.PMSBuilArInSqFet : null
               ,"p6": val && val.PMSBuilLatitude ? val.PMSBuilLatitude : null
               ,"p7": val && val.PMSBuilLongitude ? val.PMSBuilLongitude : null
               ,"p8": val && val.PMSBuilCostGroup ? val.PMSBuilCostGroup : null
               ,"p9": val && val.PMSBuilPermitNo ? val.PMSBuilPermitNo : null
               ,"p10": val && val.PMSBuilConfig ? val.PMSBuilConfig : null
               ,"p11": val && val.PMSBuilMakaniNo ? val.PMSBuilMakaniNo : null
               ,"p12": val && val.PMSBuilDMNo ? val.PMSBuilDMNo : null
               ,"p13": val && val.PMSBuilNoOfFlor ? val.PMSBuilNoOfFlor : null
               ,"p14": val && val.PMSBuilNoOfPark ? val.PMSBuilNoOfPark : null
               ,"p15": val && val.PMSBuilNoOfUnit ? val.PMSBuilNoOfUnit : null
               ,"p16": val && val.PMSBuilBUPArea ? val.PMSBuilBUPArea : null
               ,"p17": val && val.PMSBuilLeasArea ? val.PMSBuilLeasArea : null
               ,"p18": val && val.PMSBuilConsDateTime ? val.PMSBuilConsDateTime : null
               ,"p19": val && val.PMSBuilConsDateTimeType ? val.PMSBuilConsDateTimeType : null
               ,"p20": val && val.PMSBuilConsDateTimeBetween ? val.PMSBuilConsDateTimeBetween : null
               ,"p21": val && val.PMSBuilHODateTime ? val.PMSBuilHODateTime : null
               ,"p22": val && val.PMSBuilHODateTimeType ? val.PMSBuilHODateTimeType : null
               ,"p23": val && val.PMSBuilHODateTimeBetween ? val.PMSBuilHODateTimeBetween : null
               ,"p24": val && val.PMSBuilTenanDateTime ? val.PMSBuilTenanDateTime : null
               ,"p25": val && val.PMSBuilTenanDateTimeType ? val.PMSBuilTenanDateTimeType : null
               ,"p26": val && val.PMSBuilTenanDateTimeBetween ? val.PMSBuilTenanDateTimeBetween : null
               ,"p27": val && val.PMSBuilGraPeriInMons ? val.PMSBuilGraPeriInMons : null
               ,"p28": val && val.PMSBuilLeasDateTime ? val.PMSBuilLeasDateTime : null
               ,"p29": val && val.PMSBuilLeasDateTimeType ? val.PMSBuilLeasDateTimeType : null
               ,"p30": val && val.PMSBuilLeasDateTimeBetween ? val.PMSBuilLeasDateTimeBetween : null
               ,"p31": val && val.PMSBuilDescription ? val.PMSBuilDescription : null
               ,"p32": val && val.BuildingKey ? val.BuildingKey : null
               ,"p33": type == "DraftPMSBuildingID" ? "1" : "0"
               ,"p34": null
               ,"p35": val && val.LocalityID ? val.LocalityID : null
               ,"p36": val && val.OrganisationID ? val.OrganisationID : null
               ,"p37": val && val.CountryID ? val.CountryID : null
               ,"p38": val && val.RegionID ? val.RegionID : null
               ,"p39": val && val.PMSBuildingComID ? val.PMSBuildingComID : null
               ,"p40": val && val.AssBuildingTypeID ? val.AssBuildingTypeID : null
               ,"p41": val && val.PMSLandLordID ? val.PMSLandLordID : null
               ,"p42": val && val.EmployeeID ? val.EmployeeID : null
               ,"p43": val && val.EmployeeID1 ? val.EmployeeID1 : null
               ,"p44": props.Dialogview ? "1" : null
               ,"p45": null
               ,"p46": val && val.CreatedUserID_varchar ? val.CreatedUserID_varchar : null
               ,"p47": val && val.CreatedTtm ? val.CreatedTtm : null
               ,"p48": val && val.CreatedTtmType ? val.CreatedTtmType : null
               ,"p49": val && val.CreatedTtmBetween ? val.CreatedTtmBetween : null
               ,"p50": null
               ,"p51": val && val.LocalityGroupID ? val.LocalityGroupID : null
               ,"p52": val && val.LocalityGroupCode ? val.LocalityGroupCode : null
               ,"p53": val && val.LocalityGroupName ? val.LocalityGroupName : null
               ,"p54": val && val.CityID ? val.CityID : null
               ,"p55": val && val.CityCode ? val.CityCode : null
               ,"p56": val && val.CityName ? val.CityName : null
               ,"p57": val && val.AdminLocalityTypeID ? val.AdminLocalityTypeID : null
               ,"p58": val && val.AdminLocalityTypeCode ? val.AdminLocalityTypeCode : null
               ,"p59": val && val.AdminLocalityTypeName ? val.AdminLocalityTypeName : null
               ,"p60": val && val.LocalityCode ? val.LocalityCode : null
               ,"p61": val && val.LocalityName ? val.LocalityName : null
               ,"p62": val && val.OrganisationCode ? val.OrganisationCode : null
               ,"p63": val && val.OrganisationName ? val.OrganisationName : null
               ,"p64": val && val.CountryCode ? val.CountryCode : null
               ,"p65": val && val.CountryName ? val.CountryName : null
               ,"p66": val && val.RegionCode ? val.RegionCode : null
               ,"p67": val && val.RegionName ? val.RegionName : null
               ,"p68": val && val.PMSBuildingComCode ? val.PMSBuildingComCode : null
               ,"p69": val && val.PMSBuildingComName ? val.PMSBuildingComName : null
               ,"p70": val && val.AssBuildingTypeCode ? val.AssBuildingTypeCode : null
               ,"p71": val && val.AssBuildingTypeName ? val.AssBuildingTypeName : null
               ,"p72": val && val.ShiftID ? val.ShiftID : null
               ,"p73": val && val.ShiftCode ? val.ShiftCode : null
               ,"p74": val && val.ShiftName ? val.ShiftName : null
               ,"p75": val && val.ClassificationID ? val.ClassificationID : null
               ,"p76": val && val.ClassificationCode ? val.ClassificationCode : null
               ,"p77": val && val.ClassificationName ? val.ClassificationName : null
               ,"p78": val && val.DepartmentID ? val.DepartmentID : null
               ,"p79": val && val.DepartmentCode ? val.DepartmentCode : null
               ,"p80": val && val.DepartmentName ? val.DepartmentName : null
               ,"p81": val && val.DesignationID ? val.DesignationID : null
               ,"p82": val && val.DesignationCode ? val.DesignationCode : null
               ,"p83": val && val.DesignationName ? val.DesignationName : null
               ,"p84": val && val.NationalityID ? val.NationalityID : null
               ,"p85": val && val.NationalityCode ? val.NationalityCode : null
               ,"p86": val && val.NationalityName ? val.NationalityName : null
               ,"p87": val && val.EmpWorkNatureID ? val.EmpWorkNatureID : null
               ,"p88": val && val.NatureOfWorkCode ? val.NatureOfWorkCode : null
               ,"p89": val && val.NatureOfWorkName ? val.NatureOfWorkName : null
               ,"p90": val && val.EmployeeTypeID ? val.EmployeeTypeID : null
               ,"p91": val && val.EmployeeTypeCode ? val.EmployeeTypeCode : null
               ,"p92": val && val.EmployeeTypeName ? val.EmployeeTypeName : null
               ,"p93": val && val.EmploymentTypeID ? val.EmploymentTypeID : null
               ,"p94": val && val.EmploymentTypCode ? val.EmploymentTypCode : null
               ,"p95": val && val.EmploymentTypeName ? val.EmploymentTypeName : null
               ,"p96": val && val.EmployeeGroupID ? val.EmployeeGroupID : null
               ,"p97": val && val.EmployeeGroupCode ? val.EmployeeGroupCode : null
               ,"p98": val && val.EmployeeGroupName ? val.EmployeeGroupName : null
               ,"p99": val && val.EmpGradeID ? val.EmpGradeID : null
               ,"p100": val && val.EmpGradeCode ? val.EmpGradeCode : null
               ,"p101": val && val.EmpGradeName ? val.EmpGradeName : null
               ,"p102": val && val.EmpGenderID ? val.EmpGenderID : null
               ,"p103": val && val.EmpGenderName ? val.EmpGenderName : null
               ,"p104": val && val.EmpTitleID ? val.EmpTitleID : null
               ,"p105": val && val.EmpTitleName ? val.EmpTitleName : null
               ,"p106": val && val.EmployeeCode ? val.EmployeeCode : null
               ,"p107": val && val.FirstName ? val.FirstName : null
               ,"p108": val && val.EmpContactNo1 ? val.EmpContactNo1 : null
               ,"p109": val && val.EmpEmailOfficial ? val.EmpEmailOfficial : null
             ,"p110":   param.current
             ,"p111": param.pageSize
             ,"p112": type
               ,"p113": null
               ,"p114": null
               ,"p115": localStorage.getItem('UserGroupID')
               ,"p116": localStorage.getItem('userid')
        }
   }

   CommonAPISelect(url,params,cstate.token[0])
   .then(res => {
   context.loading(false);
   if(res.Output.status.code == "200"){
     if(res.Output.data.length > 0){
           if(res.Output.data){
               let result = res.Output.data.length;
               let totalRow = 0;
               if(result > 0){
                   totalRow = parseFloat(res.Output.data[0].TotalCount , 10)/10;  
                   setTableTotalCount(res.Output.data[0].TotalCount ? res.Output.data[0].TotalCount : res.Output.data.length) 
                   props.countfromTable(res.Output.data[0].TotalCount ? res.Output.data[0].TotalCount : res.Output.data.length) 
                   cdispatch({type: 'count', payload: res.Output.data[0].TotalCount})
               }else{
                       totalRow = 0;
               }
        if(param.pageSize == 10){
             setTableTotal(Math.ceil(totalRow));
         }else if(param.pageSize == 20){
             setTableTotal(Math.ceil(totalRow/2));
         }else if(param.pageSize == 50){
             setTableTotal(Math.ceil(totalRow/5));
         }else if(param.pageSize == 100){
             setTableTotal(Math.ceil(totalRow/10));
         }
         setPMSBuildingRegistryData(res.Output.data);
    }
    }else{
               setPMSBuildingRegistryData([]);
               setTableTotal(0);
               setTableTotalCount(0);
               props.countfromTable(0);
               cdispatch({type: 'count', payload: 0 })
        }
      }
   });
  }
// get All data for Print and Excel export functions
       const getAllDataPrint = (val, column,file) =>{
           if(TableTotalCount === 0){
               context.alert({open: true,color:'warning', message: ['There is no Record Found']});
               return false
           }
           context.loading(true);
           let url = config.Api + `${props.ApiType}/`;
           let params = {
           "data": {
            "p1": val ? val : val && val.PMSBuildingIDPK ? val.PMSBuildingIDPK : null
               ,"p2": val && val.PMSBuilCode ? val.PMSBuilCode : null
               ,"p3": val && val.PMSBuilName ? val.PMSBuilName : null
               ,"p4": val && val.PMSBuilNo ? val.PMSBuilNo : null
               ,"p5": val && val.PMSBuilArInSqFet ? val.PMSBuilArInSqFet : null
               ,"p6": val && val.PMSBuilLatitude ? val.PMSBuilLatitude : null
               ,"p7": val && val.PMSBuilLongitude ? val.PMSBuilLongitude : null
               ,"p8": val && val.PMSBuilCostGroup ? val.PMSBuilCostGroup : null
               ,"p9": val && val.PMSBuilPermitNo ? val.PMSBuilPermitNo : null
               ,"p10": val && val.PMSBuilConfig ? val.PMSBuilConfig : null
               ,"p11": val && val.PMSBuilMakaniNo ? val.PMSBuilMakaniNo : null
               ,"p12": val && val.PMSBuilDMNo ? val.PMSBuilDMNo : null
               ,"p13": val && val.PMSBuilNoOfFlor ? val.PMSBuilNoOfFlor : null
               ,"p14": val && val.PMSBuilNoOfPark ? val.PMSBuilNoOfPark : null
               ,"p15": val && val.PMSBuilNoOfUnit ? val.PMSBuilNoOfUnit : null
               ,"p16": val && val.PMSBuilBUPArea ? val.PMSBuilBUPArea : null
               ,"p17": val && val.PMSBuilLeasArea ? val.PMSBuilLeasArea : null
               ,"p18": val && val.PMSBuilConsDateTime ? val.PMSBuilConsDateTime : null
               ,"p19": val && val.PMSBuilConsDateTimeType ? val.PMSBuilConsDateTimeType : null
               ,"p20": val && val.PMSBuilConsDateTimeBetween ? val.PMSBuilConsDateTimeBetween : null
               ,"p21": val && val.PMSBuilHODateTime ? val.PMSBuilHODateTime : null
               ,"p22": val && val.PMSBuilHODateTimeType ? val.PMSBuilHODateTimeType : null
               ,"p23": val && val.PMSBuilHODateTimeBetween ? val.PMSBuilHODateTimeBetween : null
               ,"p24": val && val.PMSBuilTenanDateTime ? val.PMSBuilTenanDateTime : null
               ,"p25": val && val.PMSBuilTenanDateTimeType ? val.PMSBuilTenanDateTimeType : null
               ,"p26": val && val.PMSBuilTenanDateTimeBetween ? val.PMSBuilTenanDateTimeBetween : null
               ,"p27": val && val.PMSBuilGraPeriInMons ? val.PMSBuilGraPeriInMons : null
               ,"p28": val && val.PMSBuilLeasDateTime ? val.PMSBuilLeasDateTime : null
               ,"p29": val && val.PMSBuilLeasDateTimeType ? val.PMSBuilLeasDateTimeType : null
               ,"p30": val && val.PMSBuilLeasDateTimeBetween ? val.PMSBuilLeasDateTimeBetween : null
               ,"p31": val && val.PMSBuilDescription ? val.PMSBuilDescription : null
               ,"p32": val && val.BuildingKey ? val.BuildingKey : null
               ,"p33": IsDraft ? "1" : "0"
               ,"p34": null
               ,"p35": val && val.LocalityID ? val.LocalityID : null
               ,"p36": val && val.OrganisationID ? val.OrganisationID : null
               ,"p37": val && val.CountryID ? val.CountryID : null
               ,"p38": val && val.RegionID ? val.RegionID : null
               ,"p39": val && val.PMSBuildingComID ? val.PMSBuildingComID : null
               ,"p40": val && val.AssBuildingTypeID ? val.AssBuildingTypeID : null
               ,"p41": val && val.PMSLandLordID ? val.PMSLandLordID : null
               ,"p42": val && val.EmployeeID ? val.EmployeeID : null
               ,"p43": val && val.EmployeeID1 ? val.EmployeeID1 : null
               ,"p44": props.Dialogview ? "1" : null
               ,"p45": null
               ,"p46": val && val.CreatedUserID_varchar ? val.CreatedUserID_varchar : null
               ,"p47": val && val.CreatedTtm ? val.CreatedTtm : null
               ,"p48": val && val.CreatedTtmType ? val.CreatedTtmType : null
               ,"p49": val && val.CreatedTtmBetween ? val.CreatedTtmBetween : null
               ,"p50": null
               ,"p51": val && val.LocalityGroupID ? val.LocalityGroupID : null
               ,"p52": val && val.LocalityGroupCode ? val.LocalityGroupCode : null
               ,"p53": val && val.LocalityGroupName ? val.LocalityGroupName : null
               ,"p54": val && val.CityID ? val.CityID : null
               ,"p55": val && val.CityCode ? val.CityCode : null
               ,"p56": val && val.CityName ? val.CityName : null
               ,"p57": val && val.AdminLocalityTypeID ? val.AdminLocalityTypeID : null
               ,"p58": val && val.AdminLocalityTypeCode ? val.AdminLocalityTypeCode : null
               ,"p59": val && val.AdminLocalityTypeName ? val.AdminLocalityTypeName : null
               ,"p60": val && val.LocalityCode ? val.LocalityCode : null
               ,"p61": val && val.LocalityName ? val.LocalityName : null
               ,"p62": val && val.OrganisationCode ? val.OrganisationCode : null
               ,"p63": val && val.OrganisationName ? val.OrganisationName : null
               ,"p64": val && val.CountryCode ? val.CountryCode : null
               ,"p65": val && val.CountryName ? val.CountryName : null
               ,"p66": val && val.RegionCode ? val.RegionCode : null
               ,"p67": val && val.RegionName ? val.RegionName : null
               ,"p68": val && val.PMSBuildingComCode ? val.PMSBuildingComCode : null
               ,"p69": val && val.PMSBuildingComName ? val.PMSBuildingComName : null
               ,"p70": val && val.AssBuildingTypeCode ? val.AssBuildingTypeCode : null
               ,"p71": val && val.AssBuildingTypeName ? val.AssBuildingTypeName : null
               ,"p72": val && val.ShiftID ? val.ShiftID : null
               ,"p73": val && val.ShiftCode ? val.ShiftCode : null
               ,"p74": val && val.ShiftName ? val.ShiftName : null
               ,"p75": val && val.ClassificationID ? val.ClassificationID : null
               ,"p76": val && val.ClassificationCode ? val.ClassificationCode : null
               ,"p77": val && val.ClassificationName ? val.ClassificationName : null
               ,"p78": val && val.DepartmentID ? val.DepartmentID : null
               ,"p79": val && val.DepartmentCode ? val.DepartmentCode : null
               ,"p80": val && val.DepartmentName ? val.DepartmentName : null
               ,"p81": val && val.DesignationID ? val.DesignationID : null
               ,"p82": val && val.DesignationCode ? val.DesignationCode : null
               ,"p83": val && val.DesignationName ? val.DesignationName : null
               ,"p84": val && val.NationalityID ? val.NationalityID : null
               ,"p85": val && val.NationalityCode ? val.NationalityCode : null
               ,"p86": val && val.NationalityName ? val.NationalityName : null
               ,"p87": val && val.EmpWorkNatureID ? val.EmpWorkNatureID : null
               ,"p88": val && val.NatureOfWorkCode ? val.NatureOfWorkCode : null
               ,"p89": val && val.NatureOfWorkName ? val.NatureOfWorkName : null
               ,"p90": val && val.EmployeeTypeID ? val.EmployeeTypeID : null
               ,"p91": val && val.EmployeeTypeCode ? val.EmployeeTypeCode : null
               ,"p92": val && val.EmployeeTypeName ? val.EmployeeTypeName : null
               ,"p93": val && val.EmploymentTypeID ? val.EmploymentTypeID : null
               ,"p94": val && val.EmploymentTypCode ? val.EmploymentTypCode : null
               ,"p95": val && val.EmploymentTypeName ? val.EmploymentTypeName : null
               ,"p96": val && val.EmployeeGroupID ? val.EmployeeGroupID : null
               ,"p97": val && val.EmployeeGroupCode ? val.EmployeeGroupCode : null
               ,"p98": val && val.EmployeeGroupName ? val.EmployeeGroupName : null
               ,"p99": val && val.EmpGradeID ? val.EmpGradeID : null
               ,"p100": val && val.EmpGradeCode ? val.EmpGradeCode : null
               ,"p101": val && val.EmpGradeName ? val.EmpGradeName : null
               ,"p102": val && val.EmpGenderID ? val.EmpGenderID : null
               ,"p103": val && val.EmpGenderName ? val.EmpGenderName : null
               ,"p104": val && val.EmpTitleID ? val.EmpTitleID : null
               ,"p105": val && val.EmpTitleName ? val.EmpTitleName : null
               ,"p106": val && val.EmployeeCode ? val.EmployeeCode : null
               ,"p107": val && val.FirstName ? val.FirstName : null
               ,"p108": val && val.EmpContactNo1 ? val.EmpContactNo1 : null
               ,"p109": val && val.EmpEmailOfficial ? val.EmpEmailOfficial : null
             ,"p110":  GridPagination.current
             ,"p111": TableTotalCount
             ,"p112": props.ApiParamType.type
               ,"p113": null
               ,"p114": null
               ,"p115": localStorage.getItem('UserGroupID')
               ,"p116": localStorage.getItem('userid')
             }
           }
           context.loading(false);
           context.alert({ open: true, color: 'success', message: [`${tf('1394')} - Exports In Process, Once you have downloaded the file, you will be notified`] });
           CommonAPISelect(url,params,cstate.token[0],file)
           .then(res => {
           PDF_Excel_Generate(res, context, Items, setExportData, refPrint,file)
       });
    }



function VisibleItemSelect(data){
       let arr = [];
       let bodyArr = []; 
       let ItemArr =[];
       let language =[];
       data.map((val) => {
           if(val.IsVisible == "1"){
                   arr.push({id:val.FieldDisplay ,name:val.FieldDescription, type:val.FieldDataType});
                   if(!val.FieldDisplay !== "IsDraft"){
                   bodyArr.push(val.FieldDisplay);
                   ItemArr.push(val.FieldDescription);
           }
        }
           let lang = localStorage.getItem('Language')
           const item = { English: 'FieldDescription',Arabic: 'ArabicLang',Other: 'OtherLang'}
           language.push({[val.FieldName] : val[item[lang]]})
   }); 
       cdispatch({ type: 'language', payload: Object.assign({}, ...language) })
       setTableSearchParams(bodyArr.reduce((acc,curr)=>(acc[curr]='',acc),{}))
       setTableVisibleData(data);
       setTableVisibleItem(arr);
       setTableBodyItem(bodyArr);
       setColumnIndex(ItemArr);
       setItems(bodyArr);
}

const ExpandPanel = () => () => {
       setExpanded(ExpandView);
};

   useEffect(() => {
           setExpandView(cstate.ExpandTableValue);
   },[cstate.ExpandTableValue])
       const handleChangePage = (event, newPage) => {
           setPage(newPage);
           searchData({current:newPage+1,pageSize:GridPagination.pageSize},EmptyJson,IsDraft ? "DraftPMSBuildingID":"PMSBuildingID", IsDraft && "DraftPage");
       };
       const handleChangeRowsPerPage = (event) => {
           setPage(0);
       };

        return(
   <div>
    <Accordion expanded={expanded} onChange={() => ExpandPanel()}>
        <AccordionSummary>
        </AccordionSummary>

 <AccordionDetails className="AccDetails">
                <div className="tableCard"> 
                <div id="PMSBuildingRegistry-HeaderItems" className="displayFlex padding">
                       {props.cardview === false ? null :
                        <div className="tableHeaderItems displayFlex">
                      <Export_Print 
                                    formctrlidprint='fld1394L4TCExportPrint'
                                    formctrlidexport = 'fld1394L4TCExportTable'
                                    formctrlidrefresh='fld1394L4TCExportRefresh'
                                    title={'Building Registry'}
                                    data = {PrintData}
                                    exportData = {exportData}
                                    Items = {Items}
                                    columnIndex={columnIndex}
                                    triggerApi={(file) => {getAllDataPrint(searchParams,Filter.column,file)}}
                                    TableVisibleItem ={TableVisibleItem}
                                    userGridViewFormId={'1394'}
                                    TableTotalCount ={TableTotalCount}
                                    Refresh={() => { 
                                       MuiRef.current.clearItem()
                                       searchData({current:1,pageSize:10},props.ApiParamType.params ? props.ApiParamType.params : {},'PMSBuildingID');
                                       setGridPagination({current:1,pageSize:10})
                                    }}
                                    disabledPrint = {!cstate.AccessRights.IsPrint}
                                    disabledExport = {!cstate.AccessRights.IsExport}
                                    ref = {refPrint}
                                    /> 
                        </div> 
}

                            <div className="tableTopPagination displayFlex floatOrder">
                                <MUIPagination count={TableTotal} siblingCount={0} color="primary" page={GridPagination.current} onChange={(e,val)=>{
                                    setGridPagination({current:val,pageSize:GridPagination.pageSize});
                                        if(IsDraft){
                                               searchData({current:val,pageSize:GridPagination.pageSize},searchParams,"DraftPMSBuildingID","DraftPage");
                                         }else{
                                            var cardcls= document.querySelectorAll('.CardViewMain');
                                                for(let i=0; i< cardcls.length;i++){
                                                   cardcls[i].style.background = "#FFF"
                                                }
                                                   searchData({current:val,pageSize:GridPagination.pageSize},props.ApiParamType.params ? (searchParams ? searchParams : props.ApiParamType.params) : {},'PMSBuildingID');
                                        }
                                    }}
                                   /> 
                                   <div>
                                   <MUISelect 
                                    value={GridPagination.pageSize}
                                    onChange={(val)=>{
                                        setGridPagination({current:1,pageSize:val.target.value});
                                        searchData({current:1,pageSize:val.target.value},props.ApiParamType.params ? props.ApiParamType.params : {},'PMSBuildingID');
                                   }}

                      className ='BootstrapInputStyle2'

                                    >
                                    <option value={10}>10</option>
                                    <option value={20}>20</option>
                                    <option value={50}>50</option>
                                    <option value={100}>100</option>
                                    </MUISelect>
                                  </div>
                                   {ExpandView && <p className="per-page">/ per page Of ({TableTotalCount})</p> } 
                                   </div> 
                                   </div> 
                                <div id="PMSBuildingRegistry-TableBodyPopUp" className="displayFlex padding0" style={{height:'61vh',overflow: 'auto'}}>
                                <div id="PMSBuildingRegistryTabDivPopUp" style={{width:'100%',position: 'relative' ,height: '61vh'}}>
        {(props.Cardtype== 'MultiSelect') ? 
             <MUITableMulti  
                    type={props.viewtype} 
                    id = 'PMSBuildingRegistry'
                    headerdata = {TableVisibleItem} 
                    tablesearchparams = {TableSearchParams} 
                    searchvalue={(e) => { 
                    setTableSearchParams(e); 
                    setGridPagination({current:1,pageSize:10}) 
                    searchData({current:1,pageSize:10},e,IsDraft ? 'DraftPMSBuildingID' : 'PMSBuildingID',IsDraft && 'DraftPage'); 
                    }} 
                    bodydata = {PMSBuildingRegistryData} 
                    ondrag = {(e,row) => { cdispatch({type:'editData',payload: [row]});cdispatch({type:'IsDraft',payload: IsDraft}); 
                    cdispatch({type:'ShowDetail',payload: true}); }} 
                    bodyitem = {TableBodyItem } 
                    visibleitem = {TableVisibleItem} 
                    isdraft = {IsDraft} 
                    accessrights = {cstate.AccessRights} 
                    expanded = {() => {}} 
                    edit = {(row, IsDraft, show) =>{ 
                     if(!Dialogview){ 
                         props.editdata(row,'view');  
                         if(props.viewtype == 'viewonly'){ 
                             context.edit(row,IsDraft,show); 
                         }else { 
                             context.edit(row,IsDraft,false); 
                         } 
                    } else { 
                            context.select(row) 
                        } 
                    }} 
                    viewtoggle = {() => {}} 
                    IsSub={props.IsSub} 
                    multi={true} 
                    showData={true} 
                    multiselect={(val)=>{setPMSBuildingRegistryData(val)}} 
                    color={true} 
                    isexpanded={false} 
                    /> 
             : 
            <MUITable 
                   frmctrlid ='tblcs_1394_L4_'
                   ref={MuiRef}
                   id = "PMSBuildingRegistryTable"
                   type={props.viewtype}
                   headerdata = {TableVisibleItem}
                   tablesearchparams = {TableSearchParams}
                   searchvalue={(e) => {
                   setTableSearchParams(e);
                   setSearchParams(e);
                     setGridPagination({current:1,pageSize:10}) 
                     searchData({current:1,pageSize:10},e,'',IsDraft && 'DraftPage'); 
                   }}
                   bodydata = {PMSBuildingRegistryData}
                   ondrag = {(e,row) => { cdispatch({type:'editData',payload: [row]});cdispatch({type:'IsDraft',payload: IsDraft});
                   cdispatch({type:'ShowDetail',payload: true}); }}
                   bodyitem = {TableBodyItem }
                   visibleitem = {TableVisibleItem}
                   isdraft = {IsDraft}
                   accessrights = {cstate.AccessRights}
                   expanded = {() => {}}
                   edit = {(row, IsDraft, show) =>{
                       if(!Dialogview){
                           props.editdata(row,'view');
                              if(props.viewtype == 'viewonly'){ 
                                  context.edit(row,IsDraft,show); 
                              }else { 
                                  context.edit(row,IsDraft,false); 
                              } 
                       } else {
                                  context.select(row)
                       }
                   }}
                   viewtoggle = {context.viewtoggle}
                   IsSub={props.IsSub}
                   isexpanded={Dialogview ? ExpandView : true}
                   />}
                            </div>
                        </div>
                   </div> 
           </AccordionDetails>
    </Accordion> 
    </div>
    );
});



// Version No >: Release:8.0.0.46 , VersionDate >: 21.03.2023/12.30 pm , CreatedDtm >:21-03-2023




