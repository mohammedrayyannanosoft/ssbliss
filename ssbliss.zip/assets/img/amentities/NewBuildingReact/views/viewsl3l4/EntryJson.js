﻿export const json = {
EnterKeyValues: {
PMSBuildingRegistry:[
"PMSBuilCode"
,"PMSBuilName"
,"PMSBuilNo"
,"PMSBuilArInSqFet"
,"LocalityName"
,"CountryName"
,"RegionName"
,"PMSBuilLatitude"
,"PMSBuilLongitude"
,"OrganisationName"
,"AssBuildingTypeName"
,"PMSBuildingComName"
,"PMSLLdName"
,"PMSBuilCostGroup"
,"PMSBuilPermitNo"
,"FirstName"
,"FirstName1"
,"PMSBuilConfig"
,"PMSBuilMakaniNo"
,"PMSBuilDMNo"
,"PMSBuilNoOfFlor"
,"PMSBuilNoOfPark"
,"PMSBuilNoOfUnit"
,"PMSBuilBUPArea"
,"PMSBuilLeasArea"
,"PMSBuilConsDateTime"
,"PMSBuilHODateTime"
,"PMSBuilTenanDateTime"
,"PMSBuilLeasDateTime"
,"PMSBuilGraPeriInMons"
,"PMSBuilDescription"
,"BuildingKey"
],

},
Label:{
PMSBuildingRegistry:{


PMSBuilCode:["PMSBuilCode","PMSBuilName"],

PMSBuilName:["PMSBuilCode","PMSBuilName"],

PMSBuilNo:["PMSBuilCode","PMSBuilName"],

PMSBuilArInSqFet:["PMSBuilCode","PMSBuilName"],

LocalityID:["LocalityCode","LocalityName"],


CountryID:["CountryCode","CountryName"],


RegionID:["RegionCode","RegionName"],


PMSBuilLatitude:["PMSBuilCode","PMSBuilName"],

PMSBuilLongitude:["PMSBuilCode","PMSBuilName"],

OrganisationID:["OrganisationCode","OrganisationName"],


AssBuildingTypeID:["AssBuildingTypeCode","AssBuildingTypeName"],


PMSBuildingComID:["PMSBuildingComCode","PMSBuildingComName"],


PMSLandLordID:["PMSLLdCode","PMSLLdName"],


PMSBuilCostGroup:["PMSBuilCostGroup"],

PMSBuilPermitNo:["PMSBuilCode","PMSBuilName"],

EmployeeID:["EmployeeCode","FirstName"],


EmployeeID1:["PMSBuilCode","PMSBuilName"],


PMSBuilConfig:["PMSBuilCode","PMSBuilName"],

PMSBuilMakaniNo:["PMSBuilCode","PMSBuilName"],

PMSBuilDMNo:["PMSBuilCode","PMSBuilName"],

PMSBuilNoOfFlor:["PMSBuilCode","PMSBuilName"],

PMSBuilNoOfPark:["PMSBuilCode","PMSBuilName"],

PMSBuilNoOfUnit:["PMSBuilCode","PMSBuilName"],

PMSBuilBUPArea:["PMSBuilCode","PMSBuilName"],

PMSBuilLeasArea:["PMSBuilCode","PMSBuilName"],

PMSBuilConsDateTime:["PMSBuilCode","PMSBuilName"],

PMSBuilHODateTime:["PMSBuilCode","PMSBuilName"],

PMSBuilTenanDateTime:["PMSBuilCode","PMSBuilName"],

PMSBuilLeasDateTime:["PMSBuilCode","PMSBuilName"],

PMSBuilGraPeriInMons:["PMSBuilCode","PMSBuilName"],

PMSBuilDescription:["PMSBuilCode","PMSBuilName"],

BuildingKey:["PMSBuilCode","PMSBuilName"],

},


},
LabelHeader: {
PMSBuildingRegistry:{


PMSBuilCode:["Building Code","Building Name"],

PMSBuilName:["Building Code","Building Name"],

PMSBuilNo:["Building Code","Building Name"],

PMSBuilArInSqFet:["Building Code","Building Name"],

LocalityID:["Location Code","Location Name"],


CountryID:["Country Code","Country Name"],


RegionID:["Region Code","Region Name"],


PMSBuilLatitude:["Building Code","Building Name"],

PMSBuilLongitude:["Building Code","Building Name"],

OrganisationID:["Organisation Code","Organisation Name"],


AssBuildingTypeID:["Code","Building Category "],


PMSBuildingComID:["Code","Building Complex "],


PMSLandLordID:["Landlord code","Landlord Name"],


PMSBuilCostGroup:["Cost group"],

PMSBuilPermitNo:["Building Code","Building Name"],

EmployeeID:["Employee Code","First Name"],


EmployeeID1:["PMSBuilCode","PMSBuilName"],


PMSBuilConfig:["Building Code","Building Name"],

PMSBuilMakaniNo:["Building Code","Building Name"],

PMSBuilDMNo:["Building Code","Building Name"],

PMSBuilNoOfFlor:["Building Code","Building Name"],

PMSBuilNoOfPark:["Building Code","Building Name"],

PMSBuilNoOfUnit:["Building Code","Building Name"],

PMSBuilBUPArea:["Building Code","Building Name"],

PMSBuilLeasArea:["Building Code","Building Name"],

PMSBuilConsDateTime:["Building Code","Building Name"],

PMSBuilHODateTime:["Building Code","Building Name"],

PMSBuilTenanDateTime:["Building Code","Building Name"],

PMSBuilLeasDateTime:["Building Code","Building Name"],

PMSBuilGraPeriInMons:["Building Code","Building Name"],

PMSBuilDescription:["Building Code","Building Name"],

BuildingKey:["Building Code","Building Name"],

},


},
Property: {
PMSBuildingRegistry:{


PMSBuilCode :{
          id               :"fld1394_36548",
          labelID:"PMSBuilCode",
          maxLength : "50",
          labelname:"Building Code",
          frmctrlid:"fld1394_36548",
          frmctrlidname:"PMSBuilCode",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilName :{
          id               :"fld1394_36549",
          labelID:"PMSBuilName",
          maxLength : "200",
          labelname:"Building Name",
          frmctrlid:"fld1394_36549",
          frmctrlidname:"PMSBuilName",


                           type :"text",

                           mandatory:true,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilNo :{
          id               :"fld1394_36550",
          labelID:"PMSBuilNo",
          maxLength : "20",
          labelname:"Building No.",
          frmctrlid:"fld1394_36550",
          frmctrlidname:"PMSBuilNo",


                           type :"text",

                           mandatory:true,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilArInSqFet :{
          id               :"fld1394_36551",
          labelID:"PMSBuilArInSqFet",
          maxLength : "50",
          labelname:"Area in Square feet",
          frmctrlid:"fld1394_36551",
          frmctrlidname:"PMSBuilArInSqFet",


                           type :"number",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

LocalityID :{
                     id:"fld1394_36571",
                     clearID :"PMSBuildingRegistryLocalityNameClear",
                     type :"select",
                     labelID:"LocalityIDPK",
                     labelname :"Location (Site)",
                     fielddisplayname:"LocalityName",
                     fieldOrder : "1",
                     frmctrlid:"fld1394_36571",
                     frmctrlidname:"LocalityID",


                     foreignName:[],

                       createEasy:false,

                       advanceSearch:false,

                           disabled:false ,


                           mandatory:true,
},


CountryID :{
                     id:"fld1394_36573",
                     clearID :"PMSBuildingRegistryCountryNameClear",
                     type :"select",
                     labelID:"CountryIDPK",
                     labelname :"Country",
                     fielddisplayname:"CountryName",
                     fieldOrder : "2",
                     frmctrlid:"fld1394_36573",
                     frmctrlidname:"CountryID",


                     foreignName:[],

                       createEasy:false,

                       advanceSearch:false,

                           disabled:false ,


                           mandatory:false,
},


RegionID :{
                     id:"fld1394_36574",
                     clearID :"PMSBuildingRegistryRegionNameClear",
                     type :"select",
                     labelID:"RegionIDPK",
                     labelname :"Region",
                     fielddisplayname:"RegionName",
                     fieldOrder : "3",
                     frmctrlid:"fld1394_36574",
                     frmctrlidname:"RegionID",


                     foreignName:[],

                       createEasy:false,

                       advanceSearch:false,

                           disabled:false ,


                           mandatory:false,
},


PMSBuilLatitude :{
          id               :"fld1394_36552",
          labelID:"PMSBuilLatitude",
          maxLength : "50",
          labelname:"Latitude",
          frmctrlid:"fld1394_36552",
          frmctrlidname:"PMSBuilLatitude",


                           type :"number",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:true ,


                           autogen:false ,
},

PMSBuilLongitude :{
          id               :"fld1394_36553",
          labelID:"PMSBuilLongitude",
          maxLength : "50",
          labelname:"Longitude",
          frmctrlid:"fld1394_36553",
          frmctrlidname:"PMSBuilLongitude",


                           type :"number",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:true ,


                           autogen:false ,
},

OrganisationID :{
                     id:"fld1394_36572",
                     clearID :"PMSBuildingRegistryOrganisationNameClear",
                     type :"select",
                     labelID:"OrganisationIDPK",
                     labelname :"organization",
                     fielddisplayname:"OrganisationName",
                     fieldOrder : "2",
                     frmctrlid:"fld1394_36572",
                     frmctrlidname:"OrganisationID",


                     foreignName:[],

                       createEasy:false,

                       advanceSearch:false,

                           disabled:false ,


                           mandatory:true,
},


AssBuildingTypeID :{
                     id:"fld1394_36576",
                     clearID :"PMSBuildingRegistryAssBuildingTypeNameClear",
                     type :"select",
                     labelID:"AssBuildingTypeIDPK",
                     labelname :"Building category",
                     fielddisplayname:"AssBuildingTypeName",
                     fieldOrder : "3",
                     frmctrlid:"fld1394_36576",
                     frmctrlidname:"AssBuildingTypeID",


                     foreignName:[],

                       createEasy:false,

                       advanceSearch:false,

                           disabled:false ,


                           mandatory:true,
},


PMSBuildingComID :{
                     id:"fld1394_36575",
                     clearID :"PMSBuildingRegistryPMSBuildingComNameClear",
                     type :"select",
                     labelID:"PMSBuildingComIDPK",
                     labelname :"Building Complex",
                     fielddisplayname:"PMSBuildingComName",
                     fieldOrder : "4",
                     frmctrlid:"fld1394_36575",
                     frmctrlidname:"PMSBuildingComID",


                     foreignName:[],

                       createEasy:false,

                       advanceSearch:false,

                           disabled:false ,


                           mandatory:false,
},


PMSLandLordID :{
                     id:"fld1394_36577",
                     clearID :"PMSBuildingRegistryPMSLLdNameClear",
                     type :"select",
                     labelID:"PMSLandLordIDPK",
                     labelname :"Landlord",
                     fielddisplayname:"PMSLLdName",
                     fieldOrder : "1",
                     frmctrlid:"fld1394_36577",
                     frmctrlidname:"PMSLandLordID",


                     foreignName:[],

                       createEasy:false,

                       advanceSearch:false,

                           disabled:false ,


                           mandatory:true,
},


PMSBuilCostGroup :{
          id               :"fld1394_36554",
          labelID:"PMSBuilCostGroup",
          maxLength : "50",
          labelname:"Cost group",
          frmctrlid:"fld1394_36554",
          frmctrlidname:"PMSBuilCostGroup",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilPermitNo :{
          id               :"fld1394_36555",
          labelID:"PMSBuilPermitNo",
          maxLength : "50",
          labelname:"Permit number",
          frmctrlid:"fld1394_36555",
          frmctrlidname:"PMSBuilPermitNo",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

EmployeeID :{
                     id:"fld1394_36578",
                     clearID :"PMSBuildingRegistryFirstNameClear",
                     type :"select",
                     labelID:"EmployeeIDPK",
                     labelname :"Salesman",
                     fielddisplayname:"FirstName",
                     fieldOrder : "4",
                     frmctrlid:"fld1394_36578",
                     frmctrlidname:"EmployeeID",


                     foreignName:[],

                       createEasy:false,

                       advanceSearch:false,

                           disabled:false ,


                           mandatory:false,
},


EmployeeID1 :{
                     id:"fld1394_36579",
                     clearID :"PMSBuildingRegistryFirstName1Clear",
                     type :"select",
                     labelID:"EmployeeID1PK",
                     labelname :"Renewal executive",
                     fielddisplayname:"FirstName1",
                     fieldOrder : "1",
                     frmctrlid:"fld1394_36579",
                     frmctrlidname:"EmployeeID1",


                     foreignName:[],

                       createEasy:false,

                       advanceSearch:false,

                           disabled:false ,


                           mandatory:false,
},


PMSBuilConfig :{
          id               :"fld1394_36556",
          labelID:"PMSBuilConfig",
          maxLength : "200",
          labelname:"Configuration",
          frmctrlid:"fld1394_36556",
          frmctrlidname:"PMSBuilConfig",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilMakaniNo :{
          id               :"fld1394_36557",
          labelID:"PMSBuilMakaniNo",
          maxLength : "100",
          labelname:"Makani No",
          frmctrlid:"fld1394_36557",
          frmctrlidname:"PMSBuilMakaniNo",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilDMNo :{
          id               :"fld1394_36558",
          labelID:"PMSBuilDMNo",
          maxLength : "100",
          labelname:"DM Number",
          frmctrlid:"fld1394_36558",
          frmctrlidname:"PMSBuilDMNo",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilNoOfFlor :{
          id               :"fld1394_36559",
          labelID:"PMSBuilNoOfFlor",
          maxLength : "100",
          labelname:"No. of Floors",
          frmctrlid:"fld1394_36559",
          frmctrlidname:"PMSBuilNoOfFlor",


                           type :"number",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilNoOfPark :{
          id               :"fld1394_36560",
          labelID:"PMSBuilNoOfPark",
          maxLength : "100",
          labelname:"No. of parking",
          frmctrlid:"fld1394_36560",
          frmctrlidname:"PMSBuilNoOfPark",


                           type :"number",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilNoOfUnit :{
          id               :"fld1394_36561",
          labelID:"PMSBuilNoOfUnit",
          maxLength : "20",
          labelname:"No. of Unit",
          frmctrlid:"fld1394_36561",
          frmctrlidname:"PMSBuilNoOfUnit",


                           type :"number",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilBUPArea :{
          id               :"fld1394_36562",
          labelID:"PMSBuilBUPArea",
          maxLength : "30",
          labelname:"BUP Area",
          frmctrlid:"fld1394_36562",
          frmctrlidname:"PMSBuilBUPArea",


                           type :"number",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilLeasArea :{
          id               :"fld1394_36563",
          labelID:"PMSBuilLeasArea",
          maxLength : "50",
          labelname:"Leasable Area",
          frmctrlid:"fld1394_36563",
          frmctrlidname:"PMSBuilLeasArea",


                           type :"number",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilConsDateTime :{
          id               :"fld1394_36564",
          labelID:"PMSBuilConsDateTime",
          maxLength : "",
          labelname:"Construct Date",
          frmctrlid:"fld1394_36564",
          frmctrlidname:"PMSBuilConsDateTime",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilHODateTime :{
          id               :"fld1394_36565",
          labelID:"PMSBuilHODateTime",
          maxLength : "",
          labelname:"Handover Date",
          frmctrlid:"fld1394_36565",
          frmctrlidname:"PMSBuilHODateTime",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilTenanDateTime :{
          id               :"fld1394_36566",
          labelID:"PMSBuilTenanDateTime",
          maxLength : "",
          labelname:"Tenancy Date",
          frmctrlid:"fld1394_36566",
          frmctrlidname:"PMSBuilTenanDateTime",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilLeasDateTime :{
          id               :"fld1394_36568",
          labelID:"PMSBuilLeasDateTime",
          maxLength : "31",
          labelname:"Lease Date",
          frmctrlid:"fld1394_36568",
          frmctrlidname:"PMSBuilLeasDateTime",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilGraPeriInMons :{
          id               :"fld1394_36567",
          labelID:"PMSBuilGraPeriInMons",
          maxLength : "50",
          labelname:"Grace period in Months",
          frmctrlid:"fld1394_36567",
          frmctrlidname:"PMSBuilGraPeriInMons",


                           type :"number",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

PMSBuilDescription :{
          id               :"fld1394_37061",
          labelID:"PMSBuilDescription",
          maxLength : "200",
          labelname:"Remarks",
          frmctrlid:"fld1394_37061",
          frmctrlidname:"PMSBuilDescription",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

BuildingKey :{
          id               :"fld1394_37060",
          labelID:"BuildingKey",
          maxLength : "",
          labelname:"",
          frmctrlid:"fld1394_37060",
          frmctrlidname:"BuildingKey",


                           type :"text",

                           mandatory:false,

                           masked:false,

                           masktype:'',

                           disabled:false ,


                           autogen:false ,
},

},


}
}

